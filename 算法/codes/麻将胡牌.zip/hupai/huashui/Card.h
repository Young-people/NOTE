#ifndef _CARD_H_
#define _CARD_H_

#include "LSingleton.h"
#include "GameDefine.h"


//特殊牌的NC值
static const Lint NC1Wan = 11;    //一万
static const Lint NC1Tong = 21;   //一筒
static const Lint NC1Tiao = 31;   //幺鸡（一条）

static const Lint NC9Wan = 19;    //九万
static const Lint NC9Tong = 29;   //九筒
static const Lint NC9Tiao = 39;   //九条

static const Lint NCDong = 41;  //东
static const Lint NCNan = 42;   //南
static const Lint NCXi = 43;    //西
static const Lint NCBei = 44;   //北

static const Lint NCZhong = 45;   //中
static const Lint NCFa = 46;      //发
static const Lint NCBai = 47;     //白


//“万00筒00条00东00南00西00北00中00发00白”数组
//	万：  0--8
//	筒： 11--19
//	条： 22--30
//每一个元素表示一种牌在某手牌中的数量
//不包括（不需要包括）碰杠吃的牌
//用于判断是否可以组成顺刻将胡牌或听牌

//“万00筒00条00东00南00西00北00中00发00白”数组的元素个数
static const Lint NumCards = 52;

//“万00筒00条00东00南00西00北00中00发00白”中特殊牌的下标序号
static const Lint Index1Wan = 0;    //一万
static const Lint Index1Tong = 11;   //一筒
static const Lint Index1Tiao = 22;   //幺鸡（一条）

static const Lint Index2Wan = 1;     //二万
static const Lint Index2Tong = 12;   //二筒
static const Lint Index2Tiao = 23;   //二条

static const Lint Index5Wan = 4;     //五万
static const Lint Index5Tong = 15;   //五筒
static const Lint Index5Tiao = 26;   //五条

static const Lint Index8Wan = 7;    //八万
static const Lint Index8Tong = 18;   //八筒
static const Lint Index8Tiao = 29;   //八条

static const Lint Index9Wan = 8;    //九万
static const Lint Index9Tong = 19;   //九筒
static const Lint Index9Tiao = 30;   //九条

static const Lint IndexDong = 33;  //东
static const Lint IndexNan = 36;  //南
static const Lint IndexXi = 39;  //西
static const Lint IndexBei = 42;  //北

static const Lint IndexZhong = 45;   //中
static const Lint IndexFa = 48;   //发
static const Lint IndexBai = 51;   //白


struct Card
{
	Lint m_number;	//牌的号码1-9
	Lint m_color;   //牌的花色1-3 1-万，2-筒，3-条

	//-----------------------------------------------
	const static  Lint m_aYaoIndex[3];       //幺牌   一万   一筒    一条
	const static  Lint m_a13YaoNC[13];       //十三幺的13张牌的NC值   

	Card()
	{
		m_number = 0;
		m_color = 0;
	}

	Card(Lint clr, Lint num)
	{
		m_number = num;
		m_color = clr;
	}

	void setCard(Lint clr, Lint num)
	{
		m_number = num;
		m_color = clr;
	}

	Lint GetNCIndex() const
	{
		return (m_color * 10 + m_number);
	}

	bool operator< (const Card& other) const
	{
		return this->GetNCIndex() < other.GetNCIndex();
	}

	bool operator> (const Card& other) const
	{
		return this->GetNCIndex() > other.GetNCIndex();
	}

	bool operator== (const Card& other) const
	{
		return m_color == other.m_color && m_number == other.m_number;
	}
	bool operator!= (const Card& other) const
	{
		return m_color != other.m_color || m_number != other.m_number;
	}


	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Lint GetNCIndex(Lint Index)
	{
		Lint NCIndex = 0;

		switch(Index)
		{
		case IndexDong:  //东
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 1;
				break;
			}
		case IndexNan:  //南
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 2;
				break;
			}
		case IndexXi:  //西
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 3;
				break;
			}
		case IndexBei:  //北
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 4;
				break;
			}
		case IndexZhong:  //中
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 5;
				break;
			}
		case IndexFa:  //发
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 6;
				break;
			}
		case IndexBai:  //白
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 7;
				break;
			}
		default:
			{
				if ( Index<=8 && Index>=0 )
				{
					NCIndex = CARD_COLOR_WAN*10 + Index+1;
				}
				else if ( Index<=19 && Index>=11 )
				{
					NCIndex = CARD_COLOR_TUO*10 + Index-10;
				}
				else if ( Index<=30 && Index>=22 )
				{
					NCIndex = CARD_COLOR_SUO*10 + Index-21;
				}
				break;
			}
		}

		return NCIndex;
	}


	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Lint GetColor(Lint Index)
	{
		Lint nColor = 0;

		switch(Index)
		{
		case IndexDong:  //东
		case IndexNan:  //南
		case IndexXi:  //西
		case IndexBei:  //北
		case IndexZhong:  //中
		case IndexFa:  //发
		case IndexBai:  //白
			{
				nColor = CARD_COLOR_FENG_JIAN;
				break;
			}
		default:
			{
				if ( Index<=8 && Index>=0 )
				{
					nColor = CARD_COLOR_WAN;
				}
				else if ( Index<=19 && Index>=11 )
				{
					nColor = CARD_COLOR_TUO;
				}
				else if ( Index<=30 && Index>=22 )
				{
					nColor = CARD_COLOR_SUO;
				}
				break;
			}
		}

		return nColor;
	}


	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Lint GetNumber(Lint Index)
	{
		Lint nNumber = 0;

		switch (Index)
		{
		case IndexDong:  //东
		case IndexNan:  //南
		case IndexXi:  //西
		case IndexBei:  //北
		case IndexZhong:  //中
		case IndexFa:  //发
		case IndexBai:  //白
		{
			nNumber = (Index - 30) / 3;
			break;
		}
		default:
		{
			if (Index <= 8 && Index >= 0)
			{
				nNumber = Index + 1;
			}
			else if (Index <= 19 && Index >= 11)
			{
				nNumber = Index - 10;
			}
			else if (Index <= 30 && Index >= 22)
			{
				nNumber = Index - 21;
			}
			break;
		}
		}

		return nNumber;
	}


	//通过索引号获得card
	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Card GetCardByIndex(Lint index) 
	{
		Card  card;

		if (index <= Index9Tiao)       //“万00筒00条”
		{
			if (index <= Index9Wan && index >= Index1Wan)
			{
				card.m_color = CARD_COLOR_WAN;
				card.m_number = index + 1;
			}
			else if (index <= Index9Tong && index >= Index1Tong)
			{
				card.m_color = CARD_COLOR_TUO;
				card.m_number = index - 10;
			}
			else if (index <= Index9Tiao && index >= Index1Tiao)
			{
				card.m_color = CARD_COLOR_SUO;
				card.m_number = index - 21;
			}
		}
		else
		{
			card.m_color = CARD_COLOR_FENG_JIAN;

			switch (index)
			{
			case IndexDong:  //东
			{
				card.m_number = 1;
				break;
			}
			case IndexNan:  //南
			{
				card.m_number = 2;
				break;
			}
			case IndexXi:  //西
			{
				card.m_number = 3;
				break;
			}
			case IndexBei:  //北
			{
				card.m_number = 4;
				break;
			}
			case IndexZhong:  //中
			{
				card.m_number = 5;
				break;
			}
			case IndexFa:  //发
			{
				card.m_number = 6;
				break;
			}
			case IndexBai:  //白
			{
				card.m_number = 7;
				break;
			}
			}
		}

		return card;
	}

	//通过索引号判断是否是258牌
	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static bool is258ByIndex(Lint index)
	{
		switch (index)
		{
		case Index2Wan:
		case Index2Tong:
		case Index2Tiao:
		case Index5Wan:
		case Index5Tong:
		case Index5Tiao:
		case Index8Wan:
		case Index8Tong:
		case Index8Tiao:
			return true;
		default:
			return false;
		}
	}

};
typedef std::vector<Card*> CardVector;

struct ThinkUnit
{
	ThinkUnit()
	{
		m_type = 0;
	}

	void Clear()
	{
		m_type = 0;
		m_card.clear();
		m_hu.clear();
	}
	Lint m_type;
	std::vector<Card*>	m_card;
	std::vector<Lint>   m_hu;//胡牌的类型
};

typedef std::vector<ThinkUnit> ThinkVec;
class Desk;

struct OperateState
{
	//用于desk 和 card 之前的参数传递 参数太多了, 有扩展请扩展此处
	Lint m_GameType;	// 0 湖南， 3， 长沙
	bool b_canEat;		// 是否可以吃
	bool b_canHu;		// 是否可以胡
	bool b_onlyHu;		// 是否只能操作胡
	bool m_thinkGang;	// 单独处理是不是杠的牌
	Lint m_beforeTurnType;
	Lint m_deskState;	// 当前局牌状态
	Lint m_playerPos;	// 当前一个出牌位置
	Lint m_cardState;	// 当前一个出牌状态
	Lint m_endStartPos;	// 结束位置，即海底位置
	Lint m_MePos;		// 玩家的位置
	Lint m_playMode;		//玩法类型
	Lint m_outCardCounter;		//出牌计数

	CardVector* m_DeskCard;		//桌面剩余的牌
	Desk* m_pDesk;

	bool m_CanHuButFan;		//[bing] 能胡但是因番不够而不能胡 给客户端提示用

	OperateState():m_GameType(0), m_deskState(0), m_playerPos(0), m_cardState(0), m_MePos(0), m_endStartPos(0), m_thinkGang(false), b_canEat(false), b_canHu(true), b_onlyHu(false)
		,m_beforeTurnType(false)
		,m_playMode(1)
		,m_outCardCounter(0)
		,m_DeskCard(NULL)
		,m_pDesk(NULL)
		,m_CanHuButFan(false)
	{

	}

};
struct StartHuCard
{
	StartHuCard()
	{
		m_type = START_HU_NULL;
	}

	void	Clear()
	{
		m_type = START_HU_NULL;
		m_card.clear();
	}
	Lint	m_type;
	std::vector<Card*> m_card;
};
typedef std::vector<StartHuCard> StartHuVector;
class CardManager:public LSingleton<CardManager>
{
public:
	virtual bool		Init();
	virtual bool		Final();
	
	//DEBUG 发牌

	//对牌进行排序，万，筒，条，红中
	void				SortCard(CardVector& vec);
	//把des中的相，从src中删除
	void				EraseCard(CardVector& src,CardVector& des);
	//把pCard从src中删除
	void				EraseCard(CardVector& src,Card* pCard);

	//删除src 与pCard 数据一样的牌 N张
	void				EraseCard(CardVector& src,Card* pCard,Lint n);

	//删除一手牌中，相同的牌字，比如2个三万，删除其中一个
	void				EarseSameCard(CardVector& src);

	bool				CheckStartHu(CardVector& handcard,std::vector<StartHuCard>& vec);

	//检测是否杠 
	bool				CheckCanGang(CardVector& handcard,  Card* outCard, OperateState& os);
	//检测是否碰 
	bool				CheckCanPeng(CardVector& handcard,  Card* outCard, OperateState& os);

	bool				CheckHu(CardVector handcard,Card* curCard,bool needJiang);

	bool				yb_CheckHu(CardVector handcard,Card* curCard,bool needJiang,bool is_out_card);
	
private:
	bool				explorer_zheng_function(std::vector<Lint> cards,Lint index,Lint Lai_num);
	Lint				judge_ke(std::vector<Lint>& targe_vector,Lint index);
	Lint				judge_shun(std::vector<Lint>& targe_vector,Lint index);
		
public:
	//检测大胡
	//检测小七对,是否是豪华，special = 1 
	bool				CheckXiaoqidui(CardVector& handcard ,Lint& special,Card* outCard, bool isGetCard);
	//检测清一色
	bool				CheckQingyise(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, std::vector<Lint>& vec);
	//检测乱将胡
	bool				CheckLuanjianghu(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard);
	//检测碰碰胡
	bool				CheckPengpenghu(CardVector& handcard,CardVector& eatCard,Card* outCard);
	//检测全球人
	bool				CheckQuanqiuren(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard);

	//起手4个红中赖子
	bool				CheckQishouLaizi(CardVector& handcard);

	//枪杠胡
	//bool				CheckQiangganghu(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo);
	//检测杠上开花
	//bool				CheckGangshangkaihua(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo);
	//抢杠胡
	bool				CheckGangshangpao(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo);
	//海底捞
	bool				CheckHaiDiLao(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo);
	//海底炮			
	bool				CheckHaiDiPao(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo);


	//检查吃
	bool				CheckCanChi(CardVector& handcard,Card* outCard,  std::vector<Card*>& vec, OperateState& os);
	//检测暗杠 
	bool				CheckAnGang(CardVector& handcard,  std::vector<Card*>& vec, OperateState& os);

	bool				CheckCanTing(CardVector& handcard);

	bool				IsContinue(CardVector& result);

	bool				IsSame(CardVector& result);

	bool				IsSame(Card* c1,Card* c2);

	bool				IsNineOne(Card* c);

	bool				GetSpecialOneTwoThreeFour(CardVector& src,CardVector& one,CardVector& two,CardVector& three,CardVector& four);

	Card*				GetCard(Lint color,Lint number);

	//[bing] 获取设置牌Vector
	std::map<Lint, CardVector>& GetSetCardVec() { return m_SetCardVec; }

	void				SwapCardBySpecial(CardVector& cvIn, const Card specialCard[CARD_COUNT]);
private:
	Card		m_card[CARD_COUNT];
	CardVector	m_cardVec;

	//[bing] 设置牌型文件
	std::map<Lint, CardVector> m_SetCardVec;
};

#define gCardMgr CardManager::Instance()

#endif