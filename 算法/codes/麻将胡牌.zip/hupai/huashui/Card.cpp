#include "Card.h"
#include "LTool.h"
#include "LLog.h"
#include "LTabFile.h"
#include "Desk.h"


const  Lint Card::m_aYaoIndex[3] = { Index1Wan , Index1Tong , Index1Tiao };    //幺牌   一万   一筒    一条

//十三幺的13张牌的NC值
const  Lint Card::m_a13YaoNC[13] = { NC1Wan , NC1Tong , NC1Tiao, NC9Wan, NC9Tong, NC9Tiao, NCDong, NCNan, NCXi, NCBei, NCZhong, NCFa, NCBai };

static bool CardSortFun(Card* c1,Card* c2)
{
	if(c2->m_color > c1->m_color)
	{
		return true;
	}
	else if(c2->m_color == c1->m_color)
	{
		return c2->m_number > c1->m_number;
	}
	
	return false;
}

static bool CardSortBackFun(Card* c1,Card* c2)
{
	if(c2->m_color > c1->m_color)
	{
		return true;
	}
	else if(c2->m_color == c1->m_color)
	{
		return c2->m_number < c1->m_number;
	}

	return false;
}

bool CardManager::Init()
{
	Lint index = 0;
	Lint j = 0;
	Lint k = 0;
	Lint i = 0;
	for (j = 0; j < 3; j ++)	//三种色
	{
		for (k = 0; k < 9; k ++)  //9张牌
		{
			for(i = 0; i < 4 ;++i)		//循环加四次
			{
				m_card[index].m_color = j + 1;
				m_card[index].m_number = k + 1;
				index ++ ;
			}
		}
	}

	for(k = 0; k < 7; ++k)
	{
		//风牌4种 东 西 南 北 箭牌3种 中 发 白
		for(i = 0; i < 4 ;++i)
		{
			m_card[index].m_color = CARD_COLOR_FENG_JIAN;
			m_card[index].m_number = k + 1;
			index ++ ;
		}
	}

	/*
	for(k = 0; k < 3; ++k)
	{
		//箭牌3种 中 发 白
		for(i = 0; i < 4 ;++i)
		{
			m_card[index].m_color = CARD_COLOR_JIAN;
			m_card[index].m_number = k + 1;
			index ++ ;
		}
	}
	*/

	for(Lint i = 0 ; i < CARD_COUNT; ++i)
	{
		m_cardVec.push_back(&m_card[i]);
	}
	SortCard(m_cardVec);

	//设置牌型文件
	Lint nSetId = 0;
	Lint nCardClass = 0;
	LTabFile tabFile;
	std::vector< std::string > lineItem;
	if (tabFile.Load("settings/SetCard.txt"))
	{
		LLOG_ERROR("CardManager::Init() SetCard.txt is loaded!");

		//文件中第一行为注释，不处理  tabFile.getTapFileLine() 的第一次调用，取到的是第2行的内容
		lineItem  = tabFile.getTapFileLine();

		while (lineItem.size() > 0 )
		{
			std::vector<Lstring> strCard;

			//lineItem[0]就是一整行的内容
			L_ParseString(lineItem[0], strCard, "|");

			if( lineItem[0].size() < 5 )
			{
				lineItem.clear();
				lineItem  = tabFile.getTapFileLine();
				continue;
			}

			CardVector tmpCardVec;
			Card* pTmpCard = NULL;

			//0位为id行
			for(Lsize i = 0; i < strCard.size(); ++i)
			{
				if( 0 == i )
				{
					nSetId = atoi( strCard[i].c_str() );
					continue;
				}

				std::vector<Lstring> strCardInfo;
				L_ParseString(strCard[i], strCardInfo, ",");

				for(Lsize j = 0; j < strCardInfo.size(); ++j)
				{
					nCardClass = atoi( strCardInfo[j].c_str() );

					pTmpCard = new Card();
					pTmpCard->m_color = nCardClass / 10;
					pTmpCard->m_number = nCardClass % 10;

					tmpCardVec.push_back( pTmpCard );
				}
			}

			if( false == tmpCardVec.empty() )
			{
				m_SetCardVec.insert( std::make_pair(nSetId, tmpCardVec) );
			}

			lineItem.clear();
			lineItem  = tabFile.getTapFileLine();
		}		
	}

	return true;
}

bool CardManager::Final()
{
	std::map<Lint, CardVector>::iterator IT = m_SetCardVec.begin();
	while( IT != m_SetCardVec.end() )
	{
		CardVector& ThisVec = IT->second;		

		for(Lsize i = 0; i < ThisVec.size(); ++i)
		{
			delete ThisVec[i];
		}

		ThisVec.clear();

		IT++;
	}

	return true;
}

void CardManager::SwapCardBySpecial(CardVector& cvIn, const Card specialCard[CARD_COUNT])
{
	Lint nCardCount = cvIn.size();
	for (Lint i = 0; i < nCardCount; i ++)
	{
		if (specialCard[i].m_color == 0 || specialCard[i].m_number == 0)
		{
			break;
		}
		for (Lint j = i + 1; j < nCardCount; j ++)
		{
			if (cvIn[j]->m_color == specialCard[i].m_color && cvIn[j]->m_number == specialCard[i].m_number)
			{
				Card* tmp = cvIn[j];
				cvIn[j] = cvIn[i];
				cvIn[i] = tmp;	
				break;
			}
		}
	}
}

void CardManager::SortCard(CardVector& vec)
{
	std::sort(vec.begin(),vec.end(),CardSortFun);
	//[bing] debug
	//std::sort(vec.begin(),vec.end(),CardSortBackFun);
}

void CardManager::EraseCard(CardVector& src,CardVector& des)
{
	//这里直接比较地址是否相等
	CardVector::iterator it2 = des.begin();
	for(; it2 != des.end(); ++it2)
	{
		CardVector::iterator it1 = src.begin();
		for(; it1 != src.end();)
		{
			if((*it1) == (*it2))
			{
				it1 = src.erase(it1);
				break; //Tianzb 否则会多删
			}
			else
			{
				++it1;
			}
		}
	}
}

void CardManager::EraseCard(CardVector& src,Card* pCard)
{
	//这里直接比较地址是否相等
	for(Lsize i = 0 ; i  < src.size(); ++i)
	{
		if(src[i] == pCard)
		{
			src.erase(src.begin()+i);
			break;
		}
	}
}

//删除src 与pCard 数据一样的牌 N张
void CardManager::EraseCard(CardVector& src,Card* pCard,Lint n)
{
	Lint cnt = 0;
	CardVector::iterator it2 = src.begin();
	for(; it2 != src.end();)
	{
		if(cnt >= n)
			break;

		if(IsSame(pCard,*it2))
		{
			cnt ++;
			it2 = src.erase(it2);
		}
		else
		{
			++it2;
		}
	}
}

void CardManager::EarseSameCard(CardVector& src)
{
	if(src.empty())
	{
		return;
	}

	Lint color = src.front()->m_color;
	Lint number = src.front()->m_number;
	CardVector::iterator it = src.begin()+1;
	for(; it != src.end();)
	{
		if(color == (*it)->m_color && number == (*it)->m_number)
		{
			it = src.erase(it);
		}
		else
		{
			color = (*it)->m_color;
			number= (*it)->m_number;
			++it;
		}
	}
}

bool CardManager::CheckStartHu(CardVector& handcard,std::vector<StartHuCard>& vec)
{
	/*
	vec.clear();

	//缺一色
	std::set<Lint> color_num;
	for(Lsize i = 0; i < handcard.size(); ++i)
		color_num.insert(handcard[i]->m_color);

	if(color_num.size() < 3)
	{
		StartHuCard info;
		info.m_type = START_HU_QUEYISE;
		vec.push_back(info);
	}

	//大四喜
	std::vector<Card*>angang;
	CheckAnGang(handcard,angang);
	if(angang.size())
	{
		StartHuCard info;
		info.m_type = START_HU_DASIXI;
		for(Lint i = 0 ; i < angang.size(); i += 1)
		{
			info.m_card.push_back(angang[i]);
		}
		vec.push_back(info);
	}

	//板板胡
	bool banban = true;
	for(Lsize i = 0 ; i < handcard.size(); ++i)
	{
		if(handcard[i]->m_number == 2 || handcard[i]->m_number == 5 ||
			handcard[i]->m_number == 8)
		{
			banban = false;
			break;
		}
	}

	if(banban)
	{
		StartHuCard info;
		info.m_type = START_HU_BANBANHU;
		vec.push_back(info);
	}

	//六六顺
	CardVector oneh, twoh, fourh, threeh;
	GetSpecialOneTwoThreeFour(handcard, oneh, twoh, threeh, fourh);
	if(threeh.size()/3 + fourh.size()/4 >= 2)
	{
		StartHuCard info;
		info.m_type = START_HU_LIULIUSHUN;
		for(Lint i = 0 ; i < threeh.size(); i += 3)
		{
			info.m_card.push_back(threeh[i]);
		}
		for(Lint i = 0 ; i < fourh.size(); i += 4)
		{
			info.m_card.push_back(fourh[i]);
		}
		vec.push_back(info);
	}
	*/

	return false;
}

//////////////////////////////////////////////////////////////////////////
//TEST 测试胡牌算法，加上赖子
// bool  CardManager::CheckHu(CardVector handcard,Card* curCard,bool needJiang, bool isGetCard)
// {
// 	CardVector all = handcard;
// 	Lint nLaiZiCount = 0;
// 	if (isGetCard)
// 	{
// 		if(curCard)
// 		{
// 			all.push_back(curCard);
// 		}
// 		for (Lint i = 0; i < all.size(); )
// 		{
// 			if (all[i]->m_color == 4)
// 			{
// 				gCardMgr.EraseCard(all,all[i]);
// 				nLaiZiCount ++;
// 			}
// 			else
// 			{
// 				++i;
// 			}
// 		}
// 	}
// 	else
// 	{
// 		for (Lint i = 0; i < all.size(); )
// 		{
// 			if (all[i]->m_color == 4)
// 			{
// 				gCardMgr.EraseCard(all,all[i]);
// 				nLaiZiCount ++;
// 			}
// 			else
// 			{
// 				++i;
// 			}
// 		}
// 		if(curCard)
// 		{
// 			all.push_back(curCard);
// 		}
// 	}
// 	gCardMgr.SortCard(all);
// 	if (nLaiZiCount > 0)
// 	{
// 		//正向一遍
// 		//有赖子 先移除所有能组成三个的牌
// 		CardVector des = all;
// 		CardVector continueh, checkh;
// 		bool bFind = true;
// 		do 
// 		{
// 			bFind = false;
// 			continueh.clear();
// 			checkh.clear();
// 			for (Lint nCurrent = 0; nCurrent < des.size(); nCurrent ++)
// 			{
// 				if (continueh.empty() && checkh.empty())
// 				{
// 					continueh.push_back(des.front());
// 					checkh.push_back(des.front());
// 					continue;
// 				}
// 				if (des[nCurrent]->m_color != continueh.back()->m_color ||
// 					des[nCurrent]->m_number != continueh.back()->m_number)
// 				{
// 					continueh.push_back(des[nCurrent]);
// 				}
// 
// 				checkh.push_back(des[nCurrent]);
// 				Lint nHSize = checkh.size();
// 				Lint nCSize = continueh.size();
// 				if (nHSize >= 2 && (checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 1]->m_number == checkh[nHSize - 2]->m_number))
// 				{
// 					if (des.size() - nCurrent > 1)
// 					{
// 						//下一个能凑成刻子
// 						Card* nCard1 = des[nCurrent + 1];
// 						if ((checkh[nHSize - 1]->m_color == nCard1->m_color) && (checkh[nHSize - 1]->m_number == nCard1->m_number))
// 						{
// 							bFind = true;
// 							gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 							gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 							gCardMgr.EraseCard(des,nCard1, 1);
// 							checkh.clear();
// 							continueh.clear();
// 							nCurrent = -1;
// 							continue;
// 						}
// 					}
// 				}
// 				if (nCSize >= 2 && continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color )
// 				{
// 					if ( (continueh[nCSize - 2]->m_number + 1) == (continueh[nCSize - 1]->m_number))
// 					{
// 						//如果两个连着的
// 						if (des.size() - nCurrent > 1)
// 						{
// 							Card* nCard1 = des[nCurrent + 1];
// 							if ((continueh[nCSize - 1]->m_color == nCard1->m_color) && (continueh[nCSize - 1]->m_number + 1== nCard1->m_number))
// 							{
// 								bFind = true;
// 								gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 								gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 								gCardMgr.EraseCard(des,nCard1, 1);
// 								checkh.clear();
// 								continueh.clear();
// 								nCurrent = -1;
// 								continue;
// 							}
// 						}
// 					}
// 					else if (continueh[nCSize - 1]->m_number - continueh[nCSize - 2]->m_number <= 2)
// 					{
// 						//两个中间隔一个
// 						if (des.size() - nCurrent > 3)
// 						{
// 							Card* nCard1 = des[nCurrent + 1];
// 							Card* nCard2 = des[nCurrent + 2];
// 							Card* nCard3 = des[nCurrent + 3];	
// 							if ((nCard1->m_color == nCard2->m_color) && (nCard2->m_color == nCard3->m_color))
// 							{							
// 								if ((nCard1->m_number == nCard2->m_number ) && (nCard2->m_number  == nCard3->m_number ))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,nCard1, 1);
// 									gCardMgr.EraseCard(des,nCard2, 1);
// 									gCardMgr.EraseCard(des,nCard3, 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent = -1;
// 									continue;
// 								}
// 								else if ((nCard1->m_number + 1 == nCard2->m_number) && (nCard2->m_number + 1 == nCard3->m_number))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,nCard1, 1);
// 									gCardMgr.EraseCard(des,nCard2, 1);
// 									gCardMgr.EraseCard(des,nCard3, 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent = -1;
// 									continue;
// 								}
// 							}
// 						}
// 					}
// 				}
// 				if (nHSize >= 3)
// 				{
// 					if ((checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 2]->m_color == checkh[nHSize - 3]->m_color))
// 					{
// 						if (checkh[nHSize - 1]->m_number == (checkh[nHSize - 2]->m_number ) && (checkh[nHSize - 2]->m_number ) == (checkh[nHSize - 3]->m_number ))
// 						{
// 							bFind = true;
// 							gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 							gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 							gCardMgr.EraseCard(des,checkh[nHSize - 3], 1);
// 							checkh.clear();
// 							continueh.clear();
// 							nCurrent = -1;
// 							continue;
// 						}
// 					}
// 				}
// 				if (nCSize >= 3)
// 				{
// 					if ((continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color) && (continueh[nCSize - 2]->m_color== continueh[nCSize - 3]->m_color))
// 					{
// 						if ((continueh[nCSize - 1]->m_number == continueh[nCSize - 2]->m_number + 1) && (continueh[nCSize - 2]->m_number == continueh[nCSize - 3]->m_number + 1))
// 						{
// 							bFind = true;
// 							gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 							gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 							gCardMgr.EraseCard(des,continueh[nCSize - 3], 1);
// 							checkh.clear();
// 							continueh.clear();
// 							nCurrent = -1;
// 							continue;
// 						}
// 					}
// 				}
// 			}
// 
// 		} while (bFind);
// 
// 		//只剩一张手牌，一定胡牌  因为有赖子
// 		if (des.size() <= 1)
// 		{
// 			return true;
// 		}
// 
// 		//再把剩余的归到一个和两个中去，只记数量
// 		bool bTwo = false;
// 		Lint nTwo = 0;
// 		Lint nOne = 0;
// 		CardVector temp;
// 		for (Lint i  = 0;i < des.size(); i ++)
// 		{
// 			if (temp.size() == 0)
// 			{
// 				temp.push_back(des[i]);
// 				continue;
// 			}
// 			if ((des[i]->m_color == temp[0]->m_color) && (des[i]->m_number - temp[0]->m_number <= 2))
// 			{
// 				nTwo ++;
// 				if ( des[i]->m_number == temp[0]->m_number)
// 				{
// 					bTwo = true;
// 				}
// 				temp.clear();
// 			}
// 			else
// 			{
// 				nOne ++;
// 				temp.clear();
// 				temp.push_back(des[i]);
// 			}
// 		}
// 		if (temp.size() > 0)
// 		{
// 			nOne ++;
// 		}
// 		if (bTwo)
// 		{
// 			if (nTwo + nOne * 2  -1 <= nLaiZiCount)
// 			{
// 				return true;
// 			}
// 		}
// 		else
// 		{
// 			if (nOne > 0)
// 			{
// 				if (nTwo + nOne * 2  -1 <= nLaiZiCount)
// 				{
// 					return true;
// 				}
// 			}
// 			else
// 			{
// 				if (nTwo + 2 <= nLaiZiCount)
// 				{
// 					return true;
// 				}
// 			}
// 		}
// 		//反向一遍
// 		//有赖子 先移除所有能组成三个的牌
// 		des = all;
// 		bFind = true;
// 		do 
// 		{
// 			bFind = false;
// 			continueh.clear();
// 			checkh.clear();
// 			for (Lint nCurrent = des.size() - 1; nCurrent >= 0; nCurrent --)
// 			{
// 				if (continueh.empty() && checkh.empty())
// 				{
// 					continueh.push_back(des.back());
// 					checkh.push_back(des.back());
// 					continue;
// 				}
// 				if (des[nCurrent]->m_color != continueh.back()->m_color ||
// 					des[nCurrent]->m_number != continueh.back()->m_number)
// 				{
// 					continueh.push_back(des[nCurrent]);
// 				}
// 
// 				checkh.push_back(des[nCurrent]);
// 				Lint nHSize = checkh.size();
// 				Lint nCSize = continueh.size();
// 				if (nHSize >= 2 && (checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 1]->m_number == checkh[nHSize - 2]->m_number))
// 				{
// 					if ( nCurrent >= 1)
// 					{
// 						//下一个能凑成刻子
// 						Card* nCard1 = des[nCurrent - 1];
// 						if ((checkh[nHSize - 1]->m_color == nCard1->m_color) && (checkh[nHSize - 1]->m_number == nCard1->m_number))
// 						{
// 							bFind = true;
// 							gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 							gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 							gCardMgr.EraseCard(des,nCard1, 1);
// 							checkh.clear();
// 							continueh.clear();
// 							nCurrent =  des.size();
// 							continue;
// 						}
// 					}
// 				}
// 				if (nCSize >= 2 && continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color )
// 				{
// 					if ( (continueh[nCSize - 2]->m_number - 1) == (continueh[nCSize - 1]->m_number))
// 					{
// 						//如果两个连着的
// 						if ( nCurrent >= 1)
// 						{
// 							Card* nCard1 = des[nCurrent - 1];
// 							if ((continueh[nCSize - 1]->m_color == nCard1->m_color) && (continueh[nCSize - 1]->m_number - 1== nCard1->m_number))
// 							{
// 								bFind = true;
// 								gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 								gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 								gCardMgr.EraseCard(des,nCard1, 1);
// 								checkh.clear();
// 								continueh.clear();
// 								nCurrent =  des.size();
// 								continue;
// 							}
// 						}
// 					}
// 					else if (continueh[nCSize - 2]->m_number - continueh[nCSize - 1]->m_number <= 2)
// 					{
// 						//两个中间隔一个
// 						if (nCurrent >= 3)
// 						{
// 							Card* nCard1 = des[nCurrent - 1];
// 							Card* nCard2 = des[nCurrent - 2];
// 							Card* nCard3 = des[nCurrent - 3];	
// 							if ((nCard1->m_color == nCard2->m_color) && (nCard2->m_color == nCard3->m_color))
// 							{							
// 								if ((nCard1->m_number == nCard2->m_number ) && (nCard2->m_number  == nCard3->m_number ))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,nCard1, 1);
// 									gCardMgr.EraseCard(des,nCard2, 1);
// 									gCardMgr.EraseCard(des,nCard3, 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent = des.size();
// 									continue;
// 								}
// 								else if ((nCard1->m_number - 1 == nCard2->m_number) && (nCard2->m_number - 1 == nCard3->m_number))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,nCard1, 1);
// 									gCardMgr.EraseCard(des,nCard2, 1);
// 									gCardMgr.EraseCard(des,nCard3, 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent =  des.size();
// 									continue;
// 								}
// 							}
// 						}
// 					}
// 				}
// 				if (nHSize >= 3)
// 				{
// 					if ((checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 2]->m_color == checkh[nHSize - 3]->m_color))
// 					{
// 						if (checkh[nHSize - 1]->m_number == (checkh[nHSize - 2]->m_number ) && (checkh[nHSize - 2]->m_number ) == (checkh[nHSize - 3]->m_number ))
// 						{
// 							bFind = true;
// 							gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 							gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 							gCardMgr.EraseCard(des,checkh[nHSize - 3], 1);
// 							checkh.clear();
// 							continueh.clear();
// 							nCurrent =  des.size() ;
// 							continue;
// 						}
// 					}
// 				}
// 				if (nCSize >= 3)
// 				{
// 					if ((continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color) && (continueh[nCSize - 2]->m_color== continueh[nCSize - 3]->m_color))
// 					{
// 						if ((continueh[nCSize - 1]->m_number == continueh[nCSize - 2]->m_number - 1) && (continueh[nCSize - 2]->m_number == continueh[nCSize - 3]->m_number - 1))
// 						{
// 							bFind = true;
// 							gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 							gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 							gCardMgr.EraseCard(des,continueh[nCSize - 3], 1);
// 							checkh.clear();
// 							continueh.clear();
// 							nCurrent =  des.size() ;
// 							continue;
// 						}
// 					}
// 				}
// 			}
// 
// 		} while (bFind);
// 
// 		//只剩一张手牌，一定胡牌  因为有赖子
// 		if (des.size() <= 1)
// 		{
// 			return true;
// 		}
// 
// 		//再把剩余的归到一个和两个中去，只记数量
// 		bTwo = false;
// 		nTwo = 0;
// 		nOne = 0;
// 		temp.clear();
// 		for (Lint i  = 0;i < des.size(); i ++)
// 		{
// 			if (temp.size() == 0)
// 			{
// 				temp.push_back(des[i]);
// 				continue;
// 			}
// 			if ((des[i]->m_color == temp[0]->m_color) && (des[i]->m_number - temp[0]->m_number <= 2))
// 			{
// 				nTwo ++;
// 				if ( des[i]->m_number == temp[0]->m_number)
// 				{
// 					bTwo = true;
// 				}
// 				temp.clear();
// 			}
// 			else
// 			{
// 				nOne ++;
// 				temp.clear();
// 				temp.push_back(des[i]);
// 			}
// 		}
// 		if (temp.size() > 0)
// 		{
// 			nOne ++;
// 		}
// 		if (bTwo)
// 		{
// 			if (nTwo + nOne * 2  -1 <= nLaiZiCount)
// 			{
// 				return true;
// 			}
// 		}
// 		else
// 		{
// 			if (nOne > 0)
// 			{
// 				if (nTwo + nOne * 2  -1 <= nLaiZiCount)
// 				{
// 					return true;
// 				}
// 			}
// 			else
// 			{
// 				if (nTwo + 2 <= nLaiZiCount)
// 				{
// 					return true;
// 				}
// 			}
// 		}
// 		//检测没胡牌再处理特殊情况 （1，1，2，3，4，5，5）
// 		if (true)
// 		{
// 			CardVector ttow;
// 			for(Lsize i = 0 ; i+1 < all.size(); )
// 			{
// 				if(all[i]->m_color == all[i+1]->m_color &&
// 					all[i]->m_number == all[i+1]->m_number )
// 				{
// 					if(needJiang)
// 					{
// 						if(all[i]->m_number==2 || all[i]->m_number == 5 || all[i]->m_number == 8 )
// 						{
// 							ttow.push_back(all[i]);
// 							ttow.push_back(all[i+1]);
// 						}	
// 					}
// 					else
// 					{
// 						ttow.push_back(all[i]);
// 						ttow.push_back(all[i+1]);
// 					}
// 					i += 2;
// 				}
// 				else
// 				{
// 					i += 1;
// 				}
// 			}
// 			//移除某个对， 剩下都能组成三个的，就是胡了
// 			for(Lsize i = 0 ; i < ttow.size(); i +=2)
// 			{
// 				des = all;
// 				gCardMgr.EraseCard(des,ttow[i]);
// 				gCardMgr.EraseCard(des,ttow[i+1]);
// 				//正向检测一遍
// 				bFind = true;
// 				do 
// 				{
// 					bFind = false;
// 					continueh.clear();
// 					checkh.clear();
// 					for (Lint nCurrent = 0; nCurrent < des.size(); nCurrent ++)
// 					{
// 						if (continueh.empty() && checkh.empty())
// 						{
// 							continueh.push_back(des.front());
// 							checkh.push_back(des.front());
// 							continue;
// 						}
// 						if (des[nCurrent]->m_color != continueh.back()->m_color ||
// 							des[nCurrent]->m_number != continueh.back()->m_number)
// 						{
// 							continueh.push_back(des[nCurrent]);
// 						}
// 
// 						checkh.push_back(des[nCurrent]);
// 						Lint nHSize = checkh.size();
// 						Lint nCSize = continueh.size();
// 						if (nHSize >= 2 && (checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 1]->m_number == checkh[nHSize - 2]->m_number))
// 						{
// 							if (des.size() - nCurrent > 1)
// 							{
// 								//下一个能凑成刻子
// 								Card* nCard1 = des[nCurrent + 1];
// 								if ((checkh[nHSize - 1]->m_color == nCard1->m_color) && (checkh[nHSize - 1]->m_number == nCard1->m_number))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 									gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 									gCardMgr.EraseCard(des,nCard1, 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent = -1;
// 									continue;
// 								}
// 							}
// 						}
// 						if (nCSize >= 2 && continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color )
// 						{
// 							if ( (continueh[nCSize - 2]->m_number + 1) == (continueh[nCSize - 1]->m_number))
// 							{
// 								//如果两个连着的
// 								if (des.size() - nCurrent > 1)
// 								{
// 									Card* nCard1 = des[nCurrent + 1];
// 									if ((continueh[nCSize - 1]->m_color == nCard1->m_color) && (continueh[nCSize - 1]->m_number + 1== nCard1->m_number))
// 									{
// 										bFind = true;
// 										gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 										gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 										gCardMgr.EraseCard(des,nCard1, 1);
// 										checkh.clear();
// 										continueh.clear();
// 										nCurrent = -1;
// 										continue;
// 									}
// 								}
// 							}
// 							else if (continueh[nCSize - 1]->m_number - continueh[nCSize - 2]->m_number <= 2)
// 							{
// 								//两个中间隔一个
// 								if (des.size() - nCurrent > 3)
// 								{
// 									Card* nCard1 = des[nCurrent + 1];
// 									Card* nCard2 = des[nCurrent + 2];
// 									Card* nCard3 = des[nCurrent + 3];	
// 									if ((nCard1->m_color == nCard2->m_color) && (nCard2->m_color == nCard3->m_color))
// 									{							
// 										if ((nCard1->m_number == nCard2->m_number ) && (nCard2->m_number  == nCard3->m_number ))
// 										{
// 											bFind = true;
// 											gCardMgr.EraseCard(des,nCard1, 1);
// 											gCardMgr.EraseCard(des,nCard2, 1);
// 											gCardMgr.EraseCard(des,nCard3, 1);
// 											checkh.clear();
// 											continueh.clear();
// 											nCurrent = -1;
// 											continue;
// 										}
// 										else if ((nCard1->m_number + 1 == nCard2->m_number) && (nCard2->m_number + 1 == nCard3->m_number))
// 										{
// 											bFind = true;
// 											gCardMgr.EraseCard(des,nCard1, 1);
// 											gCardMgr.EraseCard(des,nCard2, 1);
// 											gCardMgr.EraseCard(des,nCard3, 1);
// 											checkh.clear();
// 											continueh.clear();
// 											nCurrent = -1;
// 											continue;
// 										}
// 									}
// 								}
// 							}
// 						}
// 						if (nHSize >= 3)
// 						{
// 							if ((checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 2]->m_color == checkh[nHSize - 3]->m_color))
// 							{
// 								if (checkh[nHSize - 1]->m_number == (checkh[nHSize - 2]->m_number ) && (checkh[nHSize - 2]->m_number ) == (checkh[nHSize - 3]->m_number ))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 									gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 									gCardMgr.EraseCard(des,checkh[nHSize - 3], 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent = -1;
// 									continue;
// 								}
// 							}
// 						}
// 						if (nCSize >= 3)
// 						{
// 							if ((continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color) && (continueh[nCSize - 2]->m_color== continueh[nCSize - 3]->m_color))
// 							{
// 								if ((continueh[nCSize - 1]->m_number == continueh[nCSize - 2]->m_number + 1) && (continueh[nCSize - 2]->m_number == continueh[nCSize - 3]->m_number + 1))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 									gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 									gCardMgr.EraseCard(des,continueh[nCSize - 3], 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent = -1;
// 									continue;
// 								}
// 							}
// 						}
// 					}
// 				} while (bFind);
// 
// 				//查看结果
// 				if (des.size() <= 1)
// 				{
// 					return true;
// 				}
// 
// 				//再把剩余的归到一个和两个中去，只记数量
// 				nTwo = 0;
// 				nOne = 0;
// 				CardVector temp;
// 				for (Lint i  = 0;i < des.size(); i ++)
// 				{
// 					if (temp.size() == 0)
// 					{
// 						temp.push_back(des[i]);
// 						continue;
// 					}
// 					if ((des[i]->m_color == temp[0]->m_color) && (des[i]->m_number - temp[0]->m_number <= 2))
// 					{
// 						nTwo ++;
// 						temp.clear();
// 					}
// 					else
// 					{
// 						nOne ++;
// 						temp.clear();
// 						temp.push_back(des[i]);
// 					}
// 				}
// 				if (temp.size() > 0)
// 				{
// 					nOne ++;
// 				}
// 
// 				if (nTwo + nOne * 2 <= nLaiZiCount)
// 				{
// 					return true;
// 				}
// 
// 				//反向检测一遍
// 				des = all;
// 				gCardMgr.EraseCard(des,ttow[i]);
// 				gCardMgr.EraseCard(des,ttow[i+1]);
// 
// 				bFind = true;
// 				do 
// 				{
// 					bFind = false;
// 					continueh.clear();
// 					checkh.clear();
// 					for (Lint nCurrent = des.size() - 1; nCurrent >= 0; nCurrent --)
// 					{
// 						if (continueh.empty() && checkh.empty())
// 						{
// 							continueh.push_back(des.back());
// 							checkh.push_back(des.back());
// 							continue;
// 						}
// 						if (des[nCurrent]->m_color != continueh.back()->m_color ||
// 							des[nCurrent]->m_number != continueh.back()->m_number)
// 						{
// 							continueh.push_back(des[nCurrent]);
// 						}
// 
// 						checkh.push_back(des[nCurrent]);
// 						Lint nHSize = checkh.size();
// 						Lint nCSize = continueh.size();
// 						if (nHSize >= 2 && (checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 1]->m_number == checkh[nHSize - 2]->m_number))
// 						{
// 							if ( nCurrent >= 1)
// 							{
// 								//下一个能凑成刻子
// 								Card* nCard1 = des[nCurrent - 1];
// 								if ((checkh[nHSize - 1]->m_color == nCard1->m_color) && (checkh[nHSize - 1]->m_number == nCard1->m_number))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 									gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 									gCardMgr.EraseCard(des,nCard1, 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent =  des.size() ;
// 									continue;
// 								}
// 							}
// 						}
// 						if (nCSize >= 2 && continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color )
// 						{
// 							if ( (continueh[nCSize - 2]->m_number - 1) == (continueh[nCSize - 1]->m_number))
// 							{
// 								//如果两个连着的
// 								if ( nCurrent >= 1)
// 								{
// 									Card* nCard1 = des[nCurrent - 1];
// 									if ((continueh[nCSize - 1]->m_color == nCard1->m_color) && (continueh[nCSize - 1]->m_number - 1== nCard1->m_number))
// 									{
// 										bFind = true;
// 										gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 										gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 										gCardMgr.EraseCard(des,nCard1, 1);
// 										checkh.clear();
// 										continueh.clear();
// 										nCurrent =  des.size();
// 										continue;
// 									}
// 								}
// 							}
// 							else if (continueh[nCSize - 2]->m_number - continueh[nCSize - 1]->m_number <= 2)
// 							{
// 								//两个中间隔一个
// 								if (nCurrent >= 3)
// 								{
// 									Card* nCard1 = des[nCurrent - 1];
// 									Card* nCard2 = des[nCurrent - 2];
// 									Card* nCard3 = des[nCurrent - 3];	
// 									if ((nCard1->m_color == nCard2->m_color) && (nCard2->m_color == nCard3->m_color))
// 									{							
// 										if ((nCard1->m_number == nCard2->m_number ) && (nCard2->m_number  == nCard3->m_number ))
// 										{
// 											bFind = true;
// 											gCardMgr.EraseCard(des,nCard1, 1);
// 											gCardMgr.EraseCard(des,nCard2, 1);
// 											gCardMgr.EraseCard(des,nCard3, 1);
// 											checkh.clear();
// 											continueh.clear();
// 											nCurrent = des.size();
// 											continue;
// 										}
// 										else if ((nCard1->m_number - 1 == nCard2->m_number) && (nCard2->m_number - 1 == nCard3->m_number))
// 										{
// 											bFind = true;
// 											gCardMgr.EraseCard(des,nCard1, 1);
// 											gCardMgr.EraseCard(des,nCard2, 1);
// 											gCardMgr.EraseCard(des,nCard3, 1);
// 											checkh.clear();
// 											continueh.clear();
// 											nCurrent =  des.size();
// 											continue;
// 										}
// 									}
// 								}
// 							}
// 						}
// 						if (nHSize >= 3)
// 						{
// 							if ((checkh[nHSize - 1]->m_color == checkh[nHSize - 2]->m_color) && (checkh[nHSize - 2]->m_color == checkh[nHSize - 3]->m_color))
// 							{
// 								if (checkh[nHSize - 1]->m_number == (checkh[nHSize - 2]->m_number ) && (checkh[nHSize - 2]->m_number ) == (checkh[nHSize - 3]->m_number ))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,checkh[nHSize - 1], 1);
// 									gCardMgr.EraseCard(des,checkh[nHSize - 2], 1);
// 									gCardMgr.EraseCard(des,checkh[nHSize - 3], 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent =  des.size() ;
// 									continue;
// 								}
// 							}
// 						}
// 						if (nCSize >= 3)
// 						{
// 							if ((continueh[nCSize - 1]->m_color == continueh[nCSize - 2]->m_color) && (continueh[nCSize - 2]->m_color== continueh[nCSize - 3]->m_color))
// 							{
// 								if ((continueh[nCSize - 1]->m_number == continueh[nCSize - 2]->m_number - 1) && (continueh[nCSize - 2]->m_number == continueh[nCSize - 3]->m_number - 1))
// 								{
// 									bFind = true;
// 									gCardMgr.EraseCard(des,continueh[nCSize - 1], 1);
// 									gCardMgr.EraseCard(des,continueh[nCSize - 2], 1);
// 									gCardMgr.EraseCard(des,continueh[nCSize - 3], 1);
// 									checkh.clear();
// 									continueh.clear();
// 									nCurrent =  des.size() ;
// 									continue;
// 								}
// 							}
// 						}
// 					}
// 				} while (bFind);
// 
// 				//查看结果
// 				if (des.size() <= 1)
// 				{
// 					return true;
// 				}
// 
// 				//再把剩余的归到一个和两个中去，只记数量
// 				nTwo = 0;
// 				nOne = 0;
// 				temp.clear();
// 				for (Lint i  = 0;i < des.size(); i ++)
// 				{
// 					if (temp.size() == 0)
// 					{
// 						temp.push_back(des[i]);
// 						continue;
// 					}
// 					if ((des[i]->m_color == temp[0]->m_color) && (des[i]->m_number - temp[0]->m_number <= 2))
// 					{
// 						nTwo ++;
// 						temp.clear();
// 					}
// 					else
// 					{
// 						nOne ++;
// 						temp.clear();
// 						temp.push_back(des[i]);
// 					}
// 				}
// 				if (temp.size() > 0)
// 				{
// 					nOne ++;
// 				}
// 
// 				if (nTwo + nOne * 2 <= nLaiZiCount)
// 				{
// 					return true;
// 				}
// 			}
// 		}
// 		return false;		
// 	}
// 	else
// 	{
// 		//没有赖子
// 		gCardMgr.SortCard(all);
// 		//提出所有成对的牌
// 		CardVector ttow;
// 		for(Lsize i = 0 ; i+1 < all.size(); )
// 		{
// 			if(all[i]->m_color == all[i+1]->m_color &&
// 				all[i]->m_number == all[i+1]->m_number )
// 			{
// 				if(needJiang)
// 				{
// 					if(all[i]->m_number==2 || all[i]->m_number == 5 || all[i]->m_number == 8 )
// 					{
// 						ttow.push_back(all[i]);
// 						ttow.push_back(all[i+1]);
// 					}	
// 				}
// 				else
// 				{
// 					ttow.push_back(all[i]);
// 					ttow.push_back(all[i+1]);
// 				}
// 				i += 2;
// 			}
// 			else
// 			{
// 				i += 1;
// 			}
// 		}
// 
// 		//移除某个对， 剩下都能组成三个的，就是胡了
// 		for(Lsize i = 0 ; i < ttow.size(); i +=2)
// 		{
// 			CardVector des = all;
// 			gCardMgr.EraseCard(des,ttow[i]);
// 			gCardMgr.EraseCard(des,ttow[i+1]);
// 
// 			CardVector continueh, checkh;
// 			Lint nCurrent = 0;
// 			while(nCurrent < des.size() && des.size() != 0)
// 			{
// 				if (nCurrent == 0)
// 				{
// 					continueh.push_back(des.front());
// 					checkh.push_back(des.front());
// 					nCurrent ++;
// 					continue;
// 				}
// 				if (des[nCurrent]->m_color == checkh.back()->m_color &&
// 					des[nCurrent]->m_number == checkh.back()->m_number + 1)
// 				{
// 					checkh.push_back(des[nCurrent]);
// 				}
// 				else if (des[nCurrent]->m_color == continueh.back()->m_color &&
// 					des[nCurrent]->m_number == continueh.back()->m_number )
// 				{
// 					continueh.push_back(des[nCurrent]);
// 				}
// 
// 				//检测是否满足三个
// 				if (checkh.size() == 3)
// 				{
// 					for (Lint j = 0; j < checkh.size(); j ++)
// 					{
// 						gCardMgr.EraseCard(des,checkh[j], 1);
// 					}
// 					checkh.clear();
// 					continueh.clear();
// 					nCurrent = 0;
// 				}
// 				else if (continueh.size() == 3)
// 				{
// 					for (Lint j = 0; j < continueh.size(); j ++)
// 					{
// 						gCardMgr.EraseCard(des,continueh[j], 1);
// 					}
// 					checkh.clear();
// 					continueh.clear();
// 					nCurrent = 0;
// 				}
// 				else
// 				{
// 					nCurrent ++;
// 				}
// 			}
// 			//查看结果
// 			if (des.size() == 0)
// 			{
// 				return true;
// 			}
// 		}
// 	}
// 
// 	return false;
// }

bool CardManager::CheckCanGang(CardVector& handcard,Card* outCard, OperateState& os)
{
	CardVector tmpVec;
	for(Lsize i = 0 ;i < handcard.size(); ++i)
	{
		Card* pcard = handcard[i];
		if(pcard->m_color == outCard->m_color && 
			pcard->m_number == outCard->m_number 
			&& pcard->m_color != os.m_pDesk->m_quemen[os.m_MePos])
		{
			tmpVec.push_back(pcard);
		}
	}
	
	/*
	if(tmpVec.size()>0)
	{
		if(tmpVec[0]->m_color==4)
		{
			return false;
		}
	}
	*/

	return tmpVec.size() >= 3;
}

bool CardManager::CheckCanPeng(CardVector& handcard,Card* outCard, OperateState& os)
{
	CardVector tmpVec;

	if(outCard)
	{
		//if(outCard->m_color==4)
			//return false;
	}
	else 
	{
		return false;
	}

	for(Lsize i = 0 ;i < handcard.size(); ++i)
	{
		Card* pcard = handcard[i];
		if(pcard->m_color == outCard->m_color && 
			pcard->m_number == outCard->m_number
			&& pcard->m_color != os.m_pDesk->m_quemen[os.m_MePos])
		{
			tmpVec.push_back(pcard);
		}
	}

	return (tmpVec.size() >= 2);
}

bool CardManager::CheckXiaoqidui(CardVector& handcard,Lint& special,Card* outCard, bool isGetCard)
{
	special = 0;
	CardVector all = handcard;
	Lint nLaiZiCount = 0;
	if (isGetCard)
	{
		if(outCard)
		{
			all.push_back(outCard);
		}
		for (Lsize i = 0; i < all.size(); )
		{
			if (all[i]->m_color == 4)
			{
				gCardMgr.EraseCard(all,all[i]);
				nLaiZiCount ++;
			}
			else
			{
				++i;
			}
		}
	}
	else
	{
		for (Lsize i = 0; i < all.size(); )
		{
			if (all[i]->m_color == 4)
			{
				gCardMgr.EraseCard(all,all[i]);
				nLaiZiCount ++;
			}
			else
			{
				++i;
			}
		}
		if(outCard)
		{
			all.push_back(outCard);
		}
	}
	gCardMgr.SortCard(all);
	if (nLaiZiCount > 0)
	{
		if (nLaiZiCount + all.size() != 14)
		{
			return false;
		}
		CardVector one,tow,three,four;
		GetSpecialOneTwoThreeFour(all,one,tow,three,four);
		if (one.size() + three.size()/3 <= (Lsize)nLaiZiCount)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		if (all.size() != 14)
		{
			return false;
		}
		CardVector one,tow,three,four;
		GetSpecialOneTwoThreeFour(all,one,tow,three,four);
		if(one.empty() && three.empty())
		{
			if(four.size()==4)
			{
				special = 1;
			}
			else if(four.size()>4)
			{
				special = 2;
			}
			return true;
		}
		else
		{
			return false;
		}
	}
}

//检测清一色
bool CardManager::CheckQingyise(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, std::vector<Lint>& vec)
{
	CardVector tmp = handcard;
	tmp.insert(tmp.end(),eatCard.begin(),eatCard.end());
	tmp.insert(tmp.end(),pengCard.begin(),pengCard.end());
	tmp.insert(tmp.end(),gangcard.begin(),gangcard.end());
	tmp.insert(tmp.end(),mgangcard.begin(),mgangcard.end());
	if(outCard)
	{
		tmp.push_back(outCard);
		SortCard(tmp);
	}

	if(tmp.empty())
	{
		return false;
	}

	Lint color = tmp.front()->m_color;
	for(Lsize i = 1 ; i < tmp.size(); ++i)
	{
		if(tmp[i]->m_color != color)
			return false;
	}

	if (yb_CheckHu(handcard,outCard,false,false)|| vec.size() > 0)
	{
		return true;
	}
	return false;
}

//检测乱将胡
bool CardManager::CheckLuanjianghu(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard)
{
	CardVector tmp = handcard;
	if(outCard)
	{
		tmp.push_back(outCard);
	}
	tmp.insert(tmp.end(),eatCard.begin(),eatCard.end());
	tmp.insert(tmp.end(),pengCard.begin(),pengCard.end());
	tmp.insert(tmp.end(),gangcard.begin(),gangcard.end());
	tmp.insert(tmp.end(),mgangcard.begin(),mgangcard.end());
	if(tmp.empty())
	{
		return false;
	}

	for(Lsize i = 0 ; i < tmp.size(); ++i)
	{
		if(!(tmp[i]->m_number == 2 || tmp[i]->m_number == 5 ||
			tmp[i]->m_number == 8))
		{
			return false;
		}
	}
	return true;
}

//检测碰碰胡
bool CardManager::CheckPengpenghu(CardVector& handcard,CardVector& eatCard,Card* outCard)
{
	if(eatCard.size())
	{
		return false;
	}

	CardVector check,one,tow,three,four;
	check = handcard;
	if(outCard)
	{
		check.push_back(outCard);
		SortCard(check);
	}

	GetSpecialOneTwoThreeFour(check,one,tow,three,four);

	if(one.size() || four.size())
		return false;

	if(tow.size() != 2)
		return false;

	return true;
}

//检测抢杠胡
/*
bool CardManager::CheckQiangganghu(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo)
{
	if (gameInfo.m_GameType == ChangShaMaJing)
	{
		if (!gameInfo.m_thinkGang && (gameInfo.m_cardState == THINK_OPERATOR_MGANG && gameInfo.m_deskState != DESK_PLAY_END_CARD))
		{
			return true;
		}
	}
	return false;
}
*/

//检测全球人
bool CardManager::CheckQuanqiuren(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard)
{
	CardVector check;
	check = handcard;
	if(outCard)
	{
		check.push_back(outCard);
	}
	if (check.size() != 2)
	{
		return false;
	}
	return ((CheckLuanjianghu(handcard,eatCard,pengCard,gangcard,mgangcard,outCard) || 
		(check[0]->m_color == check[1]->m_color && check[0]->m_number == check[1]->m_number)));
}

//杠上开花
/*
bool CardManager::CheckGangshangkaihua(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo)
{
	//判断是不是自已杠的
	if (gameInfo.m_MePos == gameInfo.m_playerPos && gameInfo.m_thinkGang)
	{
		return true;
	}

	return false;
}
*/

//杠上炮
bool CardManager::CheckGangshangpao(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo)
{

	//杠上炮，判断是不是别人的杠
	if (gameInfo.m_MePos != gameInfo.m_playerPos && gameInfo.m_thinkGang)
	{
		return true;
	}

	return false;
}
//海底捞
bool CardManager::CheckHaiDiLao(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo)
{
	if (gameInfo.m_MePos == gameInfo.m_playerPos && gameInfo.m_deskState == DESK_PLAY_END_CARD)
	{
		return true;
	}
	return false;
}
//海底炮
bool CardManager::CheckHaiDiPao(CardVector& handcard,CardVector& eatCard,CardVector& pengCard,CardVector& gangcard,CardVector& mgangcard,Card* outCard, OperateState& gameInfo)
{
	if (gameInfo.m_MePos != gameInfo.m_playerPos && gameInfo.m_deskState == DESK_PLAY_END_CARD)
	{
		return true;
	}
	return false;
}

bool CardManager::CheckCanChi(CardVector& handcard, Card* outCard, std::vector<Card*>& vec, OperateState& os)
{
	if(handcard.size() < 2)
		return false;
	if (outCard->m_color == 4)
	{
		return false;
	}
	CardVector one = handcard;
	SortCard(one);
	EarseSameCard(one);
	EraseCard(one, outCard, 4);

	for(Lsize i = 0 ; i+1 < one.size(); ++i)
	{
		CardVector tmp;
		tmp.push_back(one[i]);
		tmp.push_back(one[i+1]);
		tmp.push_back(outCard);
		SortCard(tmp);
		if(IsContinue(tmp))
		{
			vec.push_back(one[i]);
			vec.push_back(one[i+1]);
		}
	}

	return true;
}
bool CardManager::CheckAnGang(CardVector& handcard,  std::vector<Card*>& vec, OperateState& os)
{
	if(handcard.size() < 4)
		return false;

	for(Lsize i = 0 ;i+3 < handcard.size(); ++i)
	{
		Card* pcarda = handcard[i];
		Card* pcardb = handcard[i+3];
		if(pcarda->m_color == pcardb->m_color && 
			pcarda->m_number == pcardb->m_number
			&& pcarda->m_color != os.m_pDesk->m_quemen[os.m_MePos] )
		{
			vec.push_back(pcarda);
		}
	}
	return true;
}

bool CardManager::CheckCanTing(CardVector& handcard)
{
	Card* checkCard[28] = {NULL};
	for(Lsize i = 0 ; i < handcard.size(); ++i)
	{
		for(Lint j = -1; j < 2; ++j)
		{
			if(handcard[i]->m_number+j > 0 && handcard[i]->m_number+j <= 9)
			{
				Card* pc = GetCard(handcard[i]->m_color,handcard[i]->m_number+j);
				checkCard[pc->m_number-1+(pc->m_color-1)*9] = pc;
			}
		}	
	}

	for(Lint i = 0 ; i < 28; ++i)
	{
		//if (checkCard[i] && CheckCanHu(handcard, checkCard[i]))
		{
			return true;
		}
	}
	
	return false;
}

bool CardManager::IsContinue(CardVector& result)
{
	if(result.empty())
	{
		return false;
	}

	Lint number = result.front()->m_number;
	Lint color = result.front()->m_color;
	for(Lsize i = 1; i < result.size(); ++i)
	{
		if(result[i]->m_number != number+i || color != result[i]->m_color)
			return false;
	}

	return true;
}

bool CardManager::IsSame(CardVector& result)
{
	if(result.empty())
	{
		return false;
	}

	Lint number = result.front()->m_number;
	Lint color = result.front()->m_color;
	for(Lsize i = 1; i < result.size(); ++i)
	{
		if(result[i]->m_number != number || color != result[i]->m_color)
			return false;
	}

	return true;
}
bool CardManager::IsSame(Card* c1,Card* c2)
{
	return c1->m_color==c2->m_color&&c1->m_number==c2->m_number;
}

bool CardManager::IsNineOne(Card* c)
{
	return c->m_number == 0 || c->m_number == 9;
}

bool CardManager::GetSpecialOneTwoThreeFour(CardVector& src,CardVector& one,CardVector& two,CardVector& three,CardVector& four)
{
	if(src.empty())
	{
		return false;
	}

	Lsize i = 0 ;
	Lint number = 0,color = 0 ,length = 0 ;
	for(; i < src.size(); ++i)
	{
		Card* pCard = src[i];
		if(number == pCard->m_number && color == pCard->m_color)
		{
			length += 1;
		}
		else
		{
			if(length == 1)
			{
				one.push_back(src[i-1]);
			}
			else if(length == 2)
			{
				two.push_back(src[i-2]);
				two.push_back(src[i-1]);
			}
			else if(length == 3)
			{
				three.push_back(src[i-3]);
				three.push_back(src[i-2]);
				three.push_back(src[i-1]);
			}
			else if(length == 4)
			{
				four.push_back(src[i-4]);
				four.push_back(src[i-3]);
				four.push_back(src[i-2]);
				four.push_back(src[i-1]);
			}
			length = 1;
			number = pCard->m_number;
			color = pCard->m_color;
		}
	}

	if(length == 1)
	{
		one.push_back(src[i-1]);
	}
	else if(length == 2)
	{
		two.push_back(src[i-2]);
		two.push_back(src[i-1]);
	}
	else if(length == 3)
	{
		three.push_back(src[i-3]);
		three.push_back(src[i-2]);
		three.push_back(src[i-1]);
	}
	else if(length == 4)
	{
		four.push_back(src[i-4]);
		four.push_back(src[i-3]);
		four.push_back(src[i-2]);
		four.push_back(src[i-1]);
	}

	return true;
}

Card* CardManager::GetCard(Lint color,Lint number)
{
	return &m_card[((color - 1) * 9 + (number - 1)) * 4];
}

bool CardManager::CheckQishouLaizi(CardVector& handcard)
{
	int lanzi_num=0;
	for(Lsize x=0;x<handcard.size();x++)
	{
		if(handcard[x]!=NULL)
		{
			if(handcard[x]->m_color==4)
			lanzi_num++;
		}
	}
	if(lanzi_num==4)
	{
		return true;
	}
	else{
		return false;
	}
}

bool CardManager::yb_CheckHu(CardVector handcard,Card* curCard,bool needJiang,bool is_out_card)
{
	if(curCard)
	{
		handcard.push_back(curCard);
	}

	std::vector<Lint> card_vector(30,0);
	Lint Lai_num=0;

	//第一步获取癞子,分数量统计
	for(Lsize x=0;x<handcard.size();x++)
	{
		if(handcard[x]->m_color==4)
		{
			Lai_num++;
		}
		else
			card_vector[(handcard[x]->m_color-1)*10+(handcard[x]->m_number)*1]++;
	}

	if(curCard)
	{
		//玩家出了红中癞子
		if(is_out_card&&curCard->m_color==4)
		{
			if(Lai_num>2)
			{
				Lai_num-=3;
			}
			else{
				return false;
			}
		}
	}
	bool juge_lai_jiang = true;
	for(Lsize x=0;x<card_vector.size();x++)
	{
		if(x%10==0)
		{
			x++;
		}
		int index = x%10;
		if(needJiang&&(index!=2&&index!=5&&index!=8))
		{
			if(x==30)
				return false;
			continue;
		}

		if(card_vector[x]>1)
		{
			std::vector<Lint> tmp_cards(card_vector);
			tmp_cards[x]-=2;
			if(explorer_zheng_function(tmp_cards,0,Lai_num))
			{
				return true;
			}
		}
		else if(card_vector[x]==1&&Lai_num>0)
		{
			std::vector<Lint> tmp_cards(card_vector);
			tmp_cards[x]-=1;
			if(explorer_zheng_function(tmp_cards,0,Lai_num-1))
			{
				return true;
			}
		}
		else{
			if(Lai_num>1&&juge_lai_jiang)
			{
				juge_lai_jiang = false;
				if(explorer_zheng_function(card_vector,0,Lai_num-2))
				{
					return true;
				}
			}
		}
	}
	return false;
}

bool CardManager::explorer_zheng_function(std::vector<Lint> cards,Lint index,Lint Lai_num)
{
	if(index<30)
	{
		if(index%10==0)
		{
			index++;
		}

		if(cards[index]>0)
		{
			std::vector<Lint> tmp_cards(cards);
			Lint ke_dif = Lai_num-judge_ke(tmp_cards,index);
			if(ke_dif>=0)
			{
				if(explorer_zheng_function(tmp_cards,index,ke_dif))
					return true;
			}

			if(index%10<8)
			{
				std::vector<Lint> tmp_cards2(cards);
				Lint shun_dif = Lai_num-judge_shun(tmp_cards2,index);
				if(shun_dif>=0)
				{
					if(explorer_zheng_function(tmp_cards2,index,shun_dif))
						return true;
				}
			}
			return false;
		}
		else{
			if(Lai_num>0&&index%10<8)
			{
				std::vector<Lint> tmp_cards(cards);
				Lint shun_dif = Lai_num-judge_shun(tmp_cards,index);
				if(shun_dif>=0)
				{
					if(explorer_zheng_function(tmp_cards,index,shun_dif))
					{
						return true;
					}
				}
			}
			index++;
			if(explorer_zheng_function(cards,index,Lai_num))
			{
				return true;
			}
			return false;
		}
	}
	else{
		return true;
	}
}

Lint CardManager::judge_ke(std::vector<Lint>& targe_vector,Lint index)
{
	Lint Lai_num = 0;
	switch(targe_vector[index])
	{
	case 4:
	case 3:
		{
			targe_vector[index]-=3;
			Lai_num=0;
			break;
		}
	case 2:
		{
			targe_vector[index]-=2;
			Lai_num=1;
			break;
		}
	case 1:
		{
			targe_vector[index]-=1;
			Lai_num=2;
			break;
		}
	case 0:
		{
			Lai_num=3;
			break;
		}
	}
	return Lai_num;
}

Lint CardManager::judge_shun(std::vector<Lint>& targe_vector,Lint index)
{
	Lint Lai_num =3;
	if(targe_vector[index]>0)
	{
		targe_vector[index]--;
		Lai_num--;
	}
	if(targe_vector[index+1]>0)
	{
		targe_vector[index+1]--;
		Lai_num--;
	}
	if(targe_vector[index+2]>0)
	{
		targe_vector[index+2]--;
		Lai_num--;
	}
	return Lai_num;
}

bool CardManager::CheckHu(CardVector handcard,Card* curCard,bool needJiang)
{
	CardVector all = handcard;

	if(curCard)
	{
		all.push_back(curCard);
	}
	gCardMgr.SortCard(all);
	//提出所有成对的牌
	CardVector ttow;
	for(Lsize i = 0 ; i+1 < all.size(); )
	{
		if(all[i]->m_color == all[i+1]->m_color &&
			all[i]->m_number == all[i+1]->m_number )
		{
			if(needJiang)
			{
				if(all[i]->m_number==2 || all[i]->m_number == 5 || all[i]->m_number == 8 )
				{
					ttow.push_back(all[i]);
					ttow.push_back(all[i+1]);
				}	
			}
			else
			{
				ttow.push_back(all[i]);
				ttow.push_back(all[i+1]);
			}
			i += 2;
		}
		else
		{
			i += 1;
		}
	}

	//移除某个对， 剩下都能组成三个的，就是胡了
	for(Lsize i = 0 ; i < ttow.size(); i +=2)
	{
		CardVector des = all;
		gCardMgr.EraseCard(des,ttow[i]);
		gCardMgr.EraseCard(des,ttow[i+1]);

		CardVector continueh, checkh;
		Lsize nCurrent = 0;
		while(nCurrent < des.size() && des.size() != 0)
		{
			if (nCurrent == 0)
			{
				continueh.push_back(des.front());
				checkh.push_back(des.front());
				nCurrent ++;
				continue;
			}
			if (des[nCurrent]->m_color == checkh.back()->m_color &&
				des[nCurrent]->m_number == checkh.back()->m_number + 1)
			{
				checkh.push_back(des[nCurrent]);
			}
			else if (des[nCurrent]->m_color == continueh.back()->m_color &&
				des[nCurrent]->m_number == continueh.back()->m_number )
			{
				continueh.push_back(des[nCurrent]);
			}

			//检测是否满足三个
			if (checkh.size() == 3)
			{
				for (Lsize j = 0; j < checkh.size(); j ++)
				{
					gCardMgr.EraseCard(des,checkh[j], 1);
				}
				checkh.clear();
				continueh.clear();
				nCurrent = 0;
			}
			else if (continueh.size() == 3)
			{
				for (Lsize j = 0; j < continueh.size(); j ++)
				{
					gCardMgr.EraseCard(des,continueh[j], 1);
				}
				checkh.clear();
				continueh.clear();
				nCurrent = 0;
			}
			else
			{
				nCurrent ++;
			}
		}
		//查看结果
		if (des.size() == 0)
		{
			return true;
		}
	}
	return false;
}

