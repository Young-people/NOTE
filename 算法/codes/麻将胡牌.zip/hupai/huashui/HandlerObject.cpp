#include "HandlerObject.h"
#include "Config.h"
#include "Card.h"
#include "Desk.h"
#include "RoomVip.h"
#include "Work.h"
#include <random>

HandlerObject::HandlerObject(void)
{
	m_desk			= NULL;
	m_needGetCard	= false;
	m_bHuaGang      = false;
	m_bGenFengOver  = false;
	m_curGetCard	= NULL;
	m_curOutCard	= NULL;
	m_outCardCounter= 0;
	m_beforePos		= 0;
	m_beforeType	= 0;
	m_before2Pos	= 0;
	m_before2Type	= 0;
	m_curPos		= 0;
	m_zhuangPos		= 0;
	m_nInitHandCardNum = 13;


	for (Lint i = 0; i< DESK_USER_COUNT; i ++)
	{
		m_mingGang[i] = 0;
		m_anGang[i] = 0;
		m_buGang[i] = 0;
		m_dianGang[i] = 0;
		m_fangGang[i] = 0;
		m_gangPos[i] = 0;
		m_playerHuInfo[i] = 0;
		m_playerBombInfo[i] = 0;   
		m_shuaiCount[i] = 0;    
		m_hasShuai[i] = 0;
		m_aCurScore[i] = 0;
		m_nTrusteeshipCount[i] = 0;
		m_bUserInTrusteeship[i] = false;
	}
}


HandlerObject::~HandlerObject(void)
{
}


bool HandlerObject::startup(Desk* desk)
{
	if (m_desk != desk)
	{
		shutdown();
		m_desk = desk;
	}

	return true;
}


void HandlerObject::shutdown()
{
	m_desk = NULL;
	m_curOutCard = NULL;
	m_curGetCard = NULL;

	for (Lint i = 0; i< DESK_USER_COUNT; i ++)
	{
		m_vCardsShuaiPai[i].clear();
		m_thinkInfo[i].Reset();
		m_thinkRet[i].Clear();
		m_handCard[i].clear();
		m_outCard[i].clear();
		m_pengCard[i].clear();
		m_mgangCard[i].clear();
		m_agangCard[i].clear();
		m_eatCard[i].clear();
		m_mingGang[i] = 0;
		m_anGang[i] = 0;
		m_buGang[i] = 0;
		m_dianGang[i] = 0;
		m_fangGang[i] = 0;
		m_gangPos[i] = 0;
		m_playerHuInfo[i] = 0;
		m_playerBombInfo[i] = 0;   
		m_shuaiCount[i] = 0;
		m_aCurScore[i] = 0;
	}

	m_beforePos			= 0;
	m_beforeType		= 0;
	m_before2Pos		= 0;
	m_before2Type		= 0;
	m_zhuangPos			= 0;
	m_curPos			= 0;
	m_needGetCard		= false;
	m_deskCard.clear();
}


//ϴ�ơ�����
void HandlerObject::DeakCard()
{
	if (!m_desk || !m_desk->m_vip)
	{
		return;
	}

	for(Lint i = 0 ; i < DESK_USER_COUNT; ++i)
	{
		m_handCard[i].clear();
		m_outCard[i].clear();
		m_pengCard[i].clear();
		m_mgangCard[i].clear();
		m_agangCard[i].clear();
		m_eatCard[i].clear();
		m_thinkInfo[i].Reset();
		m_thinkRet[i].Clear();
	}

	m_deskCard.clear();
	m_curOutCard = NULL;//��ǰ����������
	m_curGetCard = NULL;
	m_needGetCard = false;
	m_curPos = m_zhuangPos;
	m_beforePos = INVAILD_POS;
	m_beforeType = 0;
	m_before2Pos = INVAILD_POS;
	m_before2Type = 0;

	//���ü�����
	m_outCardCounter = 0;

	memset(m_mingGang, 0, sizeof(m_mingGang));
	memset(m_anGang, 0, sizeof(m_anGang));
	memset(m_buGang, 0, sizeof(m_buGang));
	memset(m_dianGang, 0, sizeof(m_dianGang));
	memset(m_fangGang, 0, sizeof(m_fangGang));
	memset(m_gangPos,0,sizeof(m_gangPos));
	memset(m_playerHuInfo, 0, sizeof(m_playerHuInfo));
	memset(m_playerBombInfo, 0, sizeof(m_playerBombInfo));

    UpdateLastWaitThinkRetTime();
	
	//��ʼ��������
	initCards(m_deskCard);

	//ϴ��
	std::random_device rd;
	std::mt19937 g(rd());
	std::shuffle(m_deskCard.begin(), m_deskCard.end(), g);

	//���ָ������ �ƾ�
	if (gConfig.GetDebugModel() && (0 < m_desk->m_specialCard[0].m_color && 0 < m_desk->m_specialCard[0].m_number))
	{
		gCardMgr.SwapCardBySpecial(m_deskCard, m_desk->m_specialCard);
	}

	//����
	Lint nUserCount = m_desk->GetDeskUserCount();

	if ( nUserCount>4 || nUserCount<1 )
	{
		LLOG_ERROR("HandlerObject::DeakCard player number error nUserCount>4 || nUserCount<1 ");
		nUserCount = 4;
	}

	Lint nIndex = 0;

	for (Lint i = 0; i < nUserCount; ++i)
	{
		m_handCard[i].insert(m_handCard[i].begin(), m_deskCard.begin() + nIndex, m_deskCard.begin() + nIndex + m_nInitHandCardNum);
		nIndex += m_nInitHandCardNum;
	}
	m_deskCard.erase(m_deskCard.begin(), m_deskCard.begin() + nIndex);

	if(gConfig.GetDebugModel())
		std::reverse(m_deskCard.begin(), m_deskCard.end());		//���������� ֻ������ʱ�� ��Ϊ���ƴ�back��

	//���������
	for (Lint i = 0; i < nUserCount; ++i)
	{
		gCardMgr.SortCard(m_handCard[i]);
	}
#ifdef _DEBUG
	LLOG_DEBUG("Desk Match ID %d, Game Round: %d", this->m_desk->GetMatchID(), m_desk->m_vip->m_curCircle);
#endif
	//������Ϣ���ͻ���
	for(Lint indexSendUser = 0 ; indexSendUser < nUserCount; ++indexSendUser)
	{
		if (m_desk->m_user[indexSendUser] != NULL)
		{
#ifdef _DEBUG
			LLOG_DEBUG("Game Round: %d, User pos: %d, User Id: %d",
                m_desk->m_vip->m_curCircle, indexSendUser, m_desk->m_user[indexSendUser]->GetUserDataId());
#endif
			LMsgS2CPlayStart msgStartPlay;
			msgStartPlay.m_zhuang = m_curPos;
			for(Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
			{
				msgStartPlay.m_score.push_back(m_desk->m_vip->m_score[indexUser]);
				msgStartPlay.m_cardCount[indexUser] = m_handCard[indexUser].size();
				msgStartPlay.m_paozi[indexUser] = m_desk->m_paozi[indexUser];
			}

			memset(msgStartPlay.m_cardValue, 0, sizeof(msgStartPlay.m_cardValue));
			for(Lsize indexCard = 0 ; indexCard < m_handCard[indexSendUser].size(); ++indexCard)
			{
				msgStartPlay.m_cardValue[indexCard].m_number = m_handCard[indexSendUser][indexCard]->m_number;
				msgStartPlay.m_cardValue[indexCard].m_color = m_handCard[indexSendUser][indexCard]->m_color;
			}

			msgStartPlay.m_pos = indexSendUser;
			msgStartPlay.m_dCount = (Lint)m_deskCard.size();
			m_desk->m_user[indexSendUser]->Send(msgStartPlay);
		}
	}

	//¼����
	m_video.Clear();
	Lint userId[DESK_USER_COUNT] = {0};
	Lint userScore[DESK_USER_COUNT] = {0};
	std::vector<CardValue> cardVect[DESK_USER_COUNT];
	for (Lint indexVideoUser = 0; indexVideoUser < nUserCount; ++indexVideoUser)
	{
		userId[indexVideoUser] = m_desk->m_user[indexVideoUser]->GetUserDataId();
		userScore[indexVideoUser] = m_desk->m_vip->GetUserScore(m_desk->m_user[indexVideoUser]);
		CardValue cardVal;
		for (Lsize indexCard = 0; indexCard < m_handCard[indexVideoUser].size(); ++indexCard)
		{
			cardVal.m_color = m_handCard[indexVideoUser][indexCard]->m_color;
			cardVal.m_number = m_handCard[indexVideoUser][indexCard]->m_number;
			cardVect[indexVideoUser].push_back(cardVal);
		}
	}
	m_video.DealCard(userId, cardVect,gWork.GetCurTime().Secs(),m_zhuangPos,userScore,m_desk->GetDeskId(),m_desk->m_vip->m_curCircle,m_desk->m_vip->m_maxCircle,m_desk->getGameType(), &m_desk->getPlayType(), m_desk->GetVip()->m_playMode, m_desk->getPlayPara());
}

void HandlerObject::SetDeskPlay()
{
	if (!m_desk || !m_desk->m_vip)
	{
		return;
	}

	m_desk->m_vip->SendInfo();

	//����֮ǰ�����ӵ�״̬��Ϊ DESK_PLAY
	m_desk->setDeskState(DESK_PLAY);

	//ϴ�ƣ�����
	DeakCard();

	CheckStartPlayCard();
}

void HandlerObject::gameStart()
{
	if (checkStartGame())
	{
		SetDeskPlay();
	}
}


//�����Ե���,ÿ�������ˣ�һ��һ��
bool HandlerObject::ProcessRobot(Lint pos, User * pUser)
{
	bool bRet = false;

	if (pos < 0 || 3 < pos)
	{
		LLOG_ERROR("HandlerObject::ProcessRobot ERROR  pos < 0 || 3 < pos");
		return bRet;
	}

	switch(m_desk->getDeskPlayState())
	{
	case DESK_PLAY_GET_CARD:
		{
			//�����ȥ
			if (m_curPos == pos && !m_handCard[pos].empty())
			{
				LMsgC2SUserPlay msg;
				msg.m_thinkInfo.m_type = THINK_OPERATOR_OUT;
				CardValue card;

				Lint temCardCount = m_handCard[pos].size() + m_pengCard[pos].size() + m_mgangCard[pos].size() + m_eatCard[pos].size();

				Lint nIndex = 0;
				card.m_color = m_handCard[pos][nIndex]->m_color;
				card.m_number = m_handCard[pos][nIndex]->m_number;
				msg.m_thinkInfo.m_card.push_back(card);
				m_desk->HanderUserPlayCard(pUser, &msg);
				bRet = true;
			}
			break;
		}
	case DESK_PLAY_THINK_CARD:
		{
			if (m_thinkInfo[pos].NeedThink())
			{
				ThinkVec& thinkData = m_thinkInfo[pos].m_thinkData;
				for (Lsize indexThink = 0; indexThink < thinkData.size(); ++indexThink)
				{
					if (thinkData[indexThink].m_type == THINK_OPERATOR_BOMB)
					{
						//�û����˿��Ժ���
						LMsgC2SUserOper msgUserOper;
						msgUserOper.m_think.m_type = THINK_OPERATOR_BOMB;
						std::vector<Card*>& mCard = thinkData[indexThink].m_card;
						for (Lsize indexCard = 0; indexCard < mCard.size(); indexCard++)
						{
							CardValue card;
							card.m_color = mCard[indexCard]->m_color;
							card.m_number =  mCard[indexCard]->m_number;
							msgUserOper.m_think.m_card.push_back(card) ;
						}
						m_desk->HanderUserOperCard(pUser, &msgUserOper);
						break;
					}
					else
					{
						LMsgC2SUserOper msgUserOper;
						msgUserOper.m_think.m_type = thinkData[indexThink].m_type;
						std::vector<Card*>& mCard = thinkData[indexThink].m_card;
						for (Lsize indexCard = 0; indexCard < mCard.size(); indexCard++)
						{
							CardValue card;
							card.m_color = mCard[indexCard]->m_color;
							card.m_number =  mCard[indexCard]->m_number;
							msgUserOper.m_think.m_card.push_back(card) ;
						}
						m_desk->HanderUserOperCard(pUser, &msgUserOper);
					}
				}
				bRet = true;
			}
			break;
		}
	default:
		break;
	}

	return bRet;
}

//�ͻ������ƺ�Ĳ��� �ͻ����������
void HandlerObject::HanderUserPlayCard(User* pUser,LMsgC2SUserPlay* msg)
{
	if (m_desk == NULL || pUser == NULL || msg == NULL)
	{
		LLOG_DEBUG("HandlerObject::HanderUserPlayCard NULL ERROR ");
		return;
	}

	Lint pos = m_desk->GetUserPos(pUser);
	if (pos == INVAILD_POS)
	{
		LLOG_DEBUG("HanderUserPlayCard pos error %s", pUser->m_userData.m_nike.c_str());
		return;
	}

	LMsgS2CUserPlay msgUserPlay;
	msgUserPlay.m_errorCode = 0;
	msgUserPlay.m_pos = m_curPos;
	msgUserPlay.m_card = msg->m_thinkInfo;
	msgUserPlay.m_Counter = m_outCardCounter;

	if (pos != m_curPos)
	{
		msgUserPlay.m_errorCode = 1;
		pUser->Send(msgUserPlay);
		LLOG_ERROR("HanderUserPlayCard not my pos %d:%d", pos, m_curPos);
		return;
	}

	if (msg->m_thinkInfo.m_type == THINK_OPERATOR_OUT)
	{
		if (m_thinkInfo[pos].NeedThink())
		{
			//��Ҫ˼����Ӧ���ǲ��ɳ��Ƶİɣ�
			//Ϊʲô�ڳ��Ƶ�ʱ������Ҫ˼���أ�
			//������ݴ������Ļ���Ӧ��˵��������ʲô����
			VideoDoing(99,pos,0,0);
		}
		if (msg->m_thinkInfo.m_card.size())
		{
			bool bOutCardCorrect = false;
			//�������ƣ�ȷ���������������е��ƣ��ſ��Խ��д���
			for (Lsize indexCard = 0; indexCard < m_handCard[pos].size(); ++indexCard)
			{
				if (m_handCard[pos][indexCard]->m_color == msg->m_thinkInfo.m_card[0].m_color && 
					m_handCard[pos][indexCard]->m_number == msg->m_thinkInfo.m_card[0].m_number)
				{
					m_curOutCard = m_handCard[pos][indexCard];
					gCardMgr.EraseCard(m_handCard[pos], m_curOutCard);

					Lint temCardCount = m_handCard[pos].size() + m_pengCard[pos].size() + m_mgangCard[pos].size() + m_eatCard[pos].size();
					
					//���Ƽ�����
					msgUserPlay.m_Counter = ++m_outCardCounter;

					m_desk->BoadCast(msgUserPlay);

					//LLOG_DEBUG("pos: %d, m_beforePos: %d, m_before2Pos: %d, m_beforeType: %d, m_before2Type:%d ", pos,  m_beforePos, m_before2Pos, m_beforeType, m_before2Type);
					m_before2Pos  = m_beforePos;
					m_before2Type = m_beforeType;

					m_beforePos  = pos;
					m_beforeType = THINK_OPERATOR_OUT;

					//�޸�һ���߼� �ڳ���ʱ�������Ѿ�������ҵ��ѳ��б���
					m_outCard[pos].push_back(m_curOutCard);

					//¼��
					std::vector<CardValue> cards;
					CardValue card;
					card.m_color = m_curOutCard->m_color;
					card.m_number = m_curOutCard->m_number;
					cards.push_back(card);
					m_video.AddOper(VIDEO_OPER_OUT_CARD, pos, cards);

					//�������˼��
					SetThinkIng();

					bOutCardCorrect = true;
					break;
				}
			}
			if (!bOutCardCorrect)
			{
				//�����в�������������, ��������
				LLOG_ERROR("ERROR HandlerObject::HanderUserPlayCard  THINK_OPERATOR_OUT  not in hand");
			}
		}
		else
		{
			//������Ϣ��ȴû���ƣ���������
			LLOG_ERROR("ERROR HandlerObject::HanderUserPlayCard  THINK_OPERATOR_OUT  no cards");
		}
		return;
	}

	//������Ҳ��������Ӧ���ص�˼��
	ThinkUnit* unit = NULL;	
	for(Lsize indexThink = 0; indexThink < m_thinkInfo[pos].m_thinkData.size(); ++indexThink)
	{
		if (msg->m_thinkInfo.m_type == m_thinkInfo[pos].m_thinkData[indexThink].m_type)
		{
			if (msg->m_thinkInfo.m_card.size() == m_thinkInfo[pos].m_thinkData[indexThink].m_card.size())
			{
				//���ơ������漰�����б���ȫ��ͬ
				bool find = true;
				for(Lsize j = 0 ; j < msg->m_thinkInfo.m_card.size() ; ++j)
				{
					if (msg->m_thinkInfo.m_card[j].m_color != m_thinkInfo[pos].m_thinkData[indexThink].m_card[j]->m_color ||
						msg->m_thinkInfo.m_card[j].m_number != m_thinkInfo[pos].m_thinkData[indexThink].m_card[j]->m_number)
					{
						find = false;
						break;
					}
				}

				if (find)
				{
					unit = &m_thinkInfo[pos].m_thinkData[indexThink];
					break;
				}
			}
		}
	}

	if (unit)
	{
		//����  
		if (unit->m_type == THINK_OPERATOR_BOMB)
		{
			//����������⻮��
			//if ( checkHuaGang(pos) )
			//{
				//m_bHuaGang = true;
			//}
			//else
			//{
				//�����Ϊfalse��һ�ڶ������������
				//m_bHuaGang = false;
			//}

			//����
			//LLOG_DEBUG("HandlerObject::HanderUserPlayCard m_beforePos %d m_beforeType %d m_before2Pos %d m_before2Type %d", m_beforePos, m_beforeType, m_before2Pos, m_before2Type);

			//¼��;
			VideoDoing(unit->m_type,pos,0,0);

			//�������ƴ������б��Ƴ������������
			if (m_curGetCard)
			{
				gCardMgr.EraseCard(m_handCard[pos], m_curGetCard);
				msgUserPlay.m_huCard.m_color = m_curGetCard->m_color;
				msgUserPlay.m_huCard.m_number = m_curGetCard->m_number;
			}
			msgUserPlay.m_hu = unit->m_hu;
			msgUserPlay.m_cardCount = m_handCard[pos].size();
			for (Lint indexHandCard = 0; indexHandCard < msgUserPlay.m_cardCount; ++indexHandCard)
			{
				CardValue mCard;
				mCard.m_color = m_handCard[pos][indexHandCard]->m_color;
				mCard.m_number = m_handCard[pos][indexHandCard]->m_number;
				msgUserPlay.m_cardValue.push_back(mCard);
			}
			m_desk->BoadCast(msgUserPlay);

			if ( m_thinkInfo[m_curPos].m_thinkData.size()>0 )
			{
				m_thinkRet[m_curPos] = m_thinkInfo[m_curPos].m_thinkData[0];
			}

			m_playerHuInfo[m_curPos] = WIN_SUB_ZIMO;
			CardVector winCards[DESK_USER_COUNT] ;
			if (m_curGetCard)
			{
				for (int i = 0; i < DESK_USER_COUNT; i++)
				{
					winCards[i].push_back(m_curGetCard);
				}
			}
			OnGameOver(WIN_ZIMO, m_playerHuInfo, INVAILD_POS, winCards);
		}
		//����
		else if (unit->m_type == THINK_OPERATOR_ABU)
		{
			if (unit->m_card.size()>0)
			{
				//¼��;
				VideoDoing(unit->m_type, pos, unit->m_card[0]->m_color, unit->m_card[0]->m_number);
				//
				gCardMgr.EraseCard(m_handCard[pos], unit->m_card[0], 4);
				m_desk->BoadCast(msgUserPlay);
				m_anGang[pos] += 1;
				//¼��
				std::vector<CardValue> cards;
				for (int i = 0; i < 4; i++)
				{
					CardValue card;
					card.m_color = unit->m_card[0]->m_color;
					card.m_number = unit->m_card[0]->m_number;
					cards.push_back(card);
					m_agangCard[pos].push_back(unit->m_card[0]);
				}
				m_video.AddOper(VIDEO_OPER_AN_BU, pos, cards);
				//���������һ����Ȼ��˼��
				m_before2Pos = m_beforePos;
				m_before2Type = m_beforeType;

				m_beforePos = pos;
				m_beforeType = THINK_OPERATOR_ABU;

				m_bGenFengOver = true;

				SetPlayIng(pos, true, false, true, true);
			} 
			else
			{
				LLOG_ERROR("ERROR  HandlerObject::HanderUserPlayCard THINK_OPERATOR_ABU  no cards ");
			}
		}
		//����
		else if (unit->m_type == THINK_OPERATOR_MBU)
		{
			if (unit->m_card.size()>0)
			{
				//¼��;
				VideoDoing(unit->m_type, pos, unit->m_card[0]->m_color, unit->m_card[0]->m_number);
				m_curOutCard = unit->m_card[0];
				gCardMgr.EraseCard(m_handCard[pos], unit->m_card[0], 1);

				//�������˼�� ������ܺ������
				m_before2Pos = m_beforePos;
				m_before2Type = m_beforeType;
				m_beforePos = pos;
				m_beforeType = THINK_OPERATOR_MBU;

				m_bGenFengOver = true;

				SetThinkIng();
			} 
			else
			{
				LLOG_ERROR("ERROR  HandlerObject::HanderUserPlayCard THINK_OPERATOR_MBU  no cards ");
			}
		}
		else
		{
			LLOG_DEBUG("HandlerObject::HanderUserPlayCard think type %d", unit->m_type);
		}
	}
	else
	{
		LLOG_DEBUG("HandlerObject::HanderUserPlayCard %s,%d", pUser->m_userData.m_nike.c_str(), msg->m_thinkInfo.m_type);
	}
}

//�ͻ��˷���˼���������
void HandlerObject::HanderUserOperCard(User* pUser,LMsgC2SUserOper* msg)
{
	Lint pos = m_desk->GetUserPos(pUser);
	if (pos == INVAILD_POS || !m_thinkInfo[pos].NeedThink())
	{
		LMsgS2CUserOper msgUserOper;
		msgUserOper.m_pos = m_curPos;
		msgUserOper.m_beforePos = m_beforePos;
		msgUserOper.m_think = msg->m_think;
		msgUserOper.m_errorCode = 1;
		pUser->Send(msgUserOper);
		LLOG_DEBUG("HanderUserEndSelect pos error pos: %d     curPos:%d", pos, m_curPos);
		return;
	}

	//����˼�����
	dealThinkResult(pos, msg->m_think);

	//¼��;
	Lint cardColor = !msg->m_think.m_card.empty() ? msg->m_think.m_card[0].m_color : 0;
	Lint cardNumber = !msg->m_think.m_card.empty() ? msg->m_think.m_card[0].m_number : 0;
	VideoDoing(msg->m_think.m_type, pos, cardColor, cardNumber);

	if (msg->m_think.m_type == THINK_OPERATOR_BOMB)
	{
		//��⻮��
		if ( checkHuaGang(pos) )
		{
			m_bHuaGang = true;
		}
		else
		{
			//�����Ϊfalse��һ�ڶ������������
			//m_bHuaGang = false;
		}

		//����
		//LLOG_DEBUG("HandlerObject::HanderUserOperCard m_beforePos %d m_beforeType %d m_before2Pos %d m_before2Type %d", m_beforePos, m_beforeType, m_before2Pos, m_before2Type);

		LMsgS2CUserOper msgUserOper;
		msgUserOper.m_pos = pos;
		msgUserOper.m_beforePos = m_beforePos;
		msgUserOper.m_errorCode = 0;
		msgUserOper.m_think = msg->m_think;
		msgUserOper.m_card.m_color = (m_curOutCard == NULL)? 1 : m_curOutCard->m_color;		//��ʱ�� �д���
		msgUserOper.m_card.m_number =(m_curOutCard == NULL)? 1 : m_curOutCard->m_number;		//��ʱ�� �д���
		//��������
		msgUserOper.m_hu =  m_thinkRet[pos].m_hu;
		msgUserOper.m_cardCount = m_handCard[pos].size();
		for (Lint i = 0; i < msgUserOper.m_cardCount; i ++)
		{
			CardValue mCard;
			mCard.m_color = m_handCard[pos][i]->m_color;
			mCard.m_number = m_handCard[pos][i]->m_number;
			msgUserOper.m_cardValue.push_back(mCard);
		}
		m_desk->BoadCast(msgUserOper);
	}

	//�����Լ�˼������
	m_thinkInfo[pos].Reset();

	if (!continueThink())
	{
		ThinkEnd();
	}
}

//�û�����
void HandlerObject::OnUserReconnect(User* pUser)
{
	if (pUser == NULL || m_desk == NULL)
	{
		return;
	}

	Lint pos = m_desk->GetUserPos(pUser);
	if (pos == INVAILD_POS)
	{
		LLOG_ERROR("HandlerObject::OnUserReconnect pos error %d", pUser->GetUserDataId());
		return;
	}

	//��Ϸ��DESK_SELECT_PAOZI
	if (m_desk->m_deskState == DESK_SELECT_PAOZI)
	{
		LMsgS2CUserSetPaoZi send;
		Lint pos = m_desk->GetUserPos(pUser);
		send.m_StatePaozi = m_desk->m_statePaozi[pos];  //�û�λ��������״̬
		send.m_time = send.m_StatePaozi == 1 ? 0 : 5;	//�Ѿ��ù����ӣ�ʱ������Ϊ0��������Ϊ5
		m_desk->BoadCastPaozi(send, pos);
		return;
	}

	Lint nCurPos = m_curPos;
	Lint nDeskPlayType = m_desk->getDeskPlayState();
	LMsgS2CDeskState reconn;
	reconn.m_state = m_desk->getDeskState();
	reconn.m_deskPlayType = nDeskPlayType;
	reconn.m_pos = nCurPos;
	reconn.m_time = 15;
	reconn.m_zhuang = m_zhuangPos;
	reconn.m_myPos = pos;
	reconn.m_playPara = m_desk->getPlayPara();
	reconn.m_gameType = m_desk->getGameType();

	if (nCurPos != pos)
	{
		reconn.m_flag = 0;     //���˲���
	}
	else
	{
		reconn.m_flag = 1;	   //�Ҳ���
	}

	reconn.m_dCount = m_deskCard.size();

	Lint nUserCount = m_desk->GetDeskUserCount();
	for(Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
	{
		reconn.m_cardCount[indexUser] = m_handCard[indexUser].size();
		reconn.m_oCount[indexUser] = m_outCard[indexUser].size();
		reconn.m_aCount[indexUser] = m_agangCard[indexUser].size();
		reconn.m_mCount[indexUser] = m_mgangCard[indexUser].size();
		reconn.m_pCount[indexUser] = m_pengCard[indexUser].size();
		reconn.m_eCount[indexUser] = m_eatCard[indexUser].size();
		reconn.m_shuaiCount[indexUser] = m_vCardsShuaiPai[indexUser].size();
		reconn.m_paozi[indexUser] = m_desk->m_paozi[indexUser];
		reconn.m_Quemen[indexUser] = (m_desk->m_deskState == DESK_SELECT_QUEMEN ? 0 : m_desk->m_quemen[indexUser]);
		reconn.m_score[indexUser] = m_desk->m_vip->m_score[indexUser];
		reconn.m_shuaiCount[indexUser] = m_shuaiCount[indexUser];
		reconn.m_hasShuai[indexUser] = m_hasShuai[indexUser];
		reconn.m_aCurScore[indexUser] = m_aCurScore[indexUser];

		for(Lsize indexOutCard = 0 ; indexOutCard < m_outCard[indexUser].size(); ++indexOutCard)
		{
			reconn.m_oCard[indexUser][indexOutCard].m_color = m_outCard[indexUser][indexOutCard]->m_color;
			reconn.m_oCard[indexUser][indexOutCard].m_number = m_outCard[indexUser][indexOutCard]->m_number;
		}

		for(Lsize indeAGCard = 0 ; indeAGCard < m_agangCard[indexUser].size(); ++indeAGCard)
		{
			reconn.m_aCard[indexUser][indeAGCard].m_color = m_agangCard[indexUser][indeAGCard]->m_color;
			reconn.m_aCard[indexUser][indeAGCard].m_number = m_agangCard[indexUser][indeAGCard]->m_number;
		}

		for(Lsize indexMGCard = 0 ; indexMGCard < m_mgangCard[indexUser].size(); ++indexMGCard)
		{
			reconn.m_mCard[indexUser][indexMGCard].m_color = m_mgangCard[indexUser][indexMGCard]->m_color;
			reconn.m_mCard[indexUser][indexMGCard].m_number = m_mgangCard[indexUser][indexMGCard]->m_number;
		}

		for(Lsize indexPengCard = 0 ; indexPengCard < m_pengCard[indexUser].size(); ++indexPengCard)
		{
			reconn.m_pCard[indexUser][indexPengCard].m_color = m_pengCard[indexUser][indexPengCard]->m_color;
			reconn.m_pCard[indexUser][indexPengCard].m_number = m_pengCard[indexUser][indexPengCard]->m_number;
		}

		for(Lsize indexEatCard = 0 ; indexEatCard < m_eatCard[indexUser].size(); ++indexEatCard)
		{
			reconn.m_eCard[indexUser][indexEatCard].m_color = m_eatCard[indexUser][indexEatCard]->m_color;
			reconn.m_eCard[indexUser][indexEatCard].m_number = m_eatCard[indexUser][indexEatCard]->m_number;
		}

		//˦����Ϣ
		//��������˦�ƣ����������Լ���˦����Ϣ
		//�������Լ�û��˦�ƣ��򲻻�������Լ���˦����Ϣ
		//�������ĳ��һ�δ���˦�ƣ��򲻻���������ҵ�˦����Ϣ
		//���������Ҷ������˦�ƣ�����и�����ҵ�˦����Ϣ
		//���Ը�ֵ��ʱ����Ҫ��һ���ж�
		for(Lsize iShuai = 0 ; iShuai < m_vCardsShuaiPai[indexUser].size(); ++iShuai)
		{
			reconn.m_shuaiCard[indexUser][iShuai].m_color = m_vCardsShuaiPai[indexUser][iShuai].m_color;
			reconn.m_shuaiCard[indexUser][iShuai].m_number = m_vCardsShuaiPai[indexUser][iShuai].m_number;

			//LLOG_ERROR("color: %d  number: %d", reconn.m_shuaiCard[indexUser][iShuai].m_color, reconn.m_shuaiCard[indexUser][iShuai].m_number);
		}
	}

	//�ҵ���,�ͻ���������֮ǰ���õ��������ó���������
	if (nDeskPlayType == DESK_PLAY_GET_CARD && m_needGetCard && pos == nCurPos)
	{
		CardVector tmp = m_handCard[pos];
		if (m_curGetCard)
		{
			reconn.m_cardCount[pos] -= 1;
			gCardMgr.EraseCard(tmp,m_curGetCard);
		}
		for(Lsize j = 0 ;j < tmp.size(); ++j)
		{
			reconn.m_cardValue[j].m_color = tmp[j]->m_color;
			reconn.m_cardValue[j].m_number = tmp[j]->m_number;
			//LLOG_ERROR("handcard:  color: %d  number: %d", reconn.m_cardValue[j].m_color, reconn.m_cardValue[j].m_number);
		}
	}
	else
	{
		for(Lsize j = 0 ;j < m_handCard[pos].size(); ++j)
		{
			reconn.m_cardValue[j].m_color = m_handCard[pos][j]->m_color;
			reconn.m_cardValue[j].m_number = m_handCard[pos][j]->m_number;
		}
	}

	//�ó��Ƶ���ң��෢һ���ƣ����ڴ��ȥ��
	if (m_needGetCard && nDeskPlayType == DESK_PLAY_THINK_CARD)
	{
		if (m_curOutCard && pos != nCurPos)
		{
			reconn.m_cardCount[nCurPos] ++;
		}
	}
	pUser->Send(reconn);

	//��˼��
	if (nDeskPlayType == DESK_PLAY_THINK_CARD )
	{
		if (m_thinkInfo[pos].NeedThink())
		{
			LMsgS2CThink msgThink;
			msgThink.m_time = 15;
			msgThink.m_flag = 1;
			msgThink.m_card.m_color = (m_curOutCard == NULL)? 1 : m_curOutCard->m_color;		//��ʱ�� �д��� m_curOutCard->m_color;
			msgThink.m_card.m_number = (m_curOutCard == NULL)? 1 : m_curOutCard->m_number;		//��ʱ�� �д���m_curOutCard->m_number;
			for (Lsize indexThink = 0; indexThink < m_thinkInfo[pos].m_thinkData.size(); ++indexThink)
			{		
				ThinkData info;
				info.m_type = m_thinkInfo[pos].m_thinkData[indexThink].m_type;
				for(Lsize n = 0 ; n < m_thinkInfo[pos].m_thinkData[indexThink].m_card.size(); ++n)
				{
					CardValue v;
					v.m_color = m_thinkInfo[pos].m_thinkData[indexThink].m_card[n]->m_color;
					v.m_number = m_thinkInfo[pos].m_thinkData[indexThink].m_card[n]->m_number;
					info.m_card.push_back(v);
				}
				msgThink.m_think.push_back(info);
			}
			pUser->Send(msgThink);
		}
	}

	OnUserReconnectBeforeOutCard(pUser);

	//�ҳ���
	if (nDeskPlayType == DESK_PLAY_GET_CARD && m_needGetCard && pos == nCurPos)
	{
		LMsgS2COutCard msgOutCard;
		msgOutCard.m_time = 15;
		msgOutCard.m_pos = pos;
		msgOutCard.m_deskCard = (Lint)m_deskCard.size();
		msgOutCard.m_flag = (m_curGetCard&&m_needGetCard)?0:1;
		msgOutCard.m_gang = m_gangPos[pos];
		msgOutCard.m_end = m_deskCard.size()==1?1:0;
		if (m_needGetCard && m_curGetCard)
		{
			msgOutCard.m_curCard.m_color = m_curGetCard->m_color;
			msgOutCard.m_curCard.m_number = m_curGetCard->m_number;
		}
		for (Lsize indexThink = 0; indexThink < m_thinkInfo[pos].m_thinkData.size(); ++indexThink)
		{		
			ThinkData info;
			info.m_type = m_thinkInfo[pos].m_thinkData[indexThink].m_type;
			for(Lsize n = 0 ; n < m_thinkInfo[pos].m_thinkData[indexThink].m_card.size(); ++n)
			{
				CardValue v;
				v.m_color = m_thinkInfo[pos].m_thinkData[indexThink].m_card[n]->m_color;
				v.m_number = m_thinkInfo[pos].m_thinkData[indexThink].m_card[n]->m_number;
				info.m_card.push_back(v);
			}
			msgOutCard.m_think.push_back(info);
		}

        //������ʾ���
        std::vector<Card> vecCards;
        if (checkCardTing(m_handCard[pos], &vecCards))
        {
            for (auto &card : vecCards)
            {
                CardValue cardValue(card.m_color, card.m_number);
                msgOutCard.m_outCards.push_back(cardValue);
            }
        }

		pUser->Send(msgOutCard);
	}
}

//���ֺ�����˼��
void HandlerObject::CheckStartPlayCard()
{
	LLOG_DEBUG("HandlerObject::CheckStartPlayCard begin");
	m_desk->setDeskState(DESK_PLAY);

	vector<Lint> vecPaozi;
	vector<Lint> vecQuemen;
	for(Lint indexUser = 0; indexUser < DESK_USER_COUNT; ++indexUser)
	{
		vecPaozi.push_back(m_desk->m_paozi[indexUser]);
		vecQuemen.push_back(m_desk->m_quemen[indexUser]);
	}
	m_video.SetPaozi(vecPaozi);
	m_video.SetQuemen(vecQuemen);

	//����ץ���ˣ�ֱ��˼��		//��BUG ˼��ʱ���������
	//SetPlayIng(m_curPos,false, false, true, true);

	SetPlayIng(m_curPos,true, false, true, true);
	//m_curGetCard = m_handCard[m_curPos].back();
	m_needGetCard = true;
}

//���ƺ���ҵ�˼��
void HandlerObject::SetPlayIng(Lint pos, bool needGetCard, bool gang, bool needThink, bool canhu)
{
	if (m_desk == NULL )
	{
		LLOG_DEBUG("HanderUserEndSelect NULL ERROR ");
		return;
	}
	
	//��ׯ
	if (m_deskCard.empty())
	{
		LLOG_INFO("Desk::SetPlayIng huangzhuang game over");
		OnGameOver(WIN_NONE, m_playerHuInfo, INVAILD_POS, NULL);
		return;
	}

	m_curPos = pos;

	if (pos < 0 || 3 < pos)
	{
		LLOG_ERROR("Desk::SetPlayIng pos error! pos = %d.", pos);
		return ;
	}

	//������˼����Ϣ
	m_thinkInfo[pos].m_thinkData.clear();

	m_desk->setDeskPlayState(DESK_PLAY_GET_CARD);
	m_needGetCard = false;
	if (needGetCard)
	{
		m_needGetCard = true;
		m_curGetCard = m_deskCard.back();
		m_deskCard.pop_back();

		//¼��
		std::vector<CardValue> cards;
		CardValue card;
		card.m_color = m_curGetCard->m_color;
		card.m_number = m_curGetCard->m_number;
		cards.push_back(card);
		m_video.AddOper(VIDEO_OPER_GET_CARD, pos, cards);
	}

	if (needThink)
	{
		thinkGetCard(pos, m_curGetCard, canhu);

		VideoThink(pos);
	}

	if (m_needGetCard)
	{
		m_handCard[pos].push_back(m_curGetCard);
		gCardMgr.SortCard(m_handCard[pos]);
	}

	Lint nUserCount = m_desk->GetDeskUserCount();
	for(Lint indexUser = 0 ; indexUser < nUserCount; ++indexUser)
	{
		if (m_desk->m_user[indexUser] != NULL)
		{
			LMsgS2COutCard msgOutCard;
			msgOutCard.m_time = 15;
			msgOutCard.m_pos = pos;
			msgOutCard.m_deskCard = (Lint)m_deskCard.size();
			msgOutCard.m_gang = m_gangPos[pos];
			msgOutCard.m_end = 0;
			msgOutCard.m_flag = 1;

			if (m_needGetCard)
			{
				msgOutCard.m_flag = 0;
			}

			if (pos == indexUser)
			{
				if (m_needGetCard)
				{
					msgOutCard.m_curCard.m_number = m_curGetCard->m_number;
					msgOutCard.m_curCard.m_color = m_curGetCard->m_color;
				}

				for (Lsize j = 0; j < m_thinkInfo[pos].m_thinkData.size(); ++j)
				{		

					ThinkData info;
					info.m_type = m_thinkInfo[pos].m_thinkData[j].m_type;

					for(Lsize n = 0 ; n < m_thinkInfo[pos].m_thinkData[j].m_card.size(); ++n)
					{
						CardValue v;
						v.m_color = m_thinkInfo[pos].m_thinkData[j].m_card[n]->m_color;
						v.m_number = m_thinkInfo[pos].m_thinkData[j].m_card[n]->m_number;
						info.m_card.push_back(v);
					}

					msgOutCard.m_think.push_back(info);
				}

                //������ʾ���
                std::vector<Card> vecCards;
                if (checkCardTing(m_handCard[pos], &vecCards))
                {
                    for (auto &card : vecCards)
                    {
                        CardValue cardValue(card.m_color, card.m_number);
                        msgOutCard.m_outCards.push_back(cardValue);
                    }
                }
			}

			m_desk->m_user[indexUser]->Send(msgOutCard);
		}
	}
    UpdateLastWaitThinkRetTime();
}


//���ƺ�������ҵ�˼��
void HandlerObject::SetThinkIng()
{
	//�������˼��
	Lint nUserCount = m_desk->GetDeskUserCount();
	for(Lint indexClear = 0; indexClear < nUserCount; ++indexClear)
	{
		m_thinkRet[indexClear].Clear();
		m_thinkInfo[indexClear].Reset();
	}

	//����������������+���ƣ�����Ҫ�ټ��������
	if (m_beforeType == THINK_OPERATOR_MBU)
	{
		//������ܺ�
		thinkMingGang(m_curPos, m_curOutCard);
	}
	else
	{
		//����������ƺ���������˼��
		thinkOutCard(m_curPos, m_curOutCard);
	}

	bool deskThink = false;

	for (Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
	{
		if (m_thinkInfo[indexUser].NeedThink())
		{
			deskThink = true;
			VideoThink(indexUser);
		}
	}

	if (deskThink)
	{
		m_desk->setDeskPlayState(DESK_PLAY_THINK_CARD);
		for (Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
		{
			LMsgS2CThink msgThink;
			msgThink.m_time = 15;
			msgThink.m_card.m_color = m_curOutCard->m_color;
			msgThink.m_card.m_number = m_curOutCard->m_number;

			if (m_thinkInfo[indexUser].NeedThink())
			{
				msgThink.m_flag = 1;
				for (Lsize indexThink = 0; indexThink < m_thinkInfo[indexUser].m_thinkData.size(); ++indexThink)
				{		
					ThinkData info;
					info.m_type = m_thinkInfo[indexUser].m_thinkData[indexThink].m_type;
					for(Lsize n = 0 ; n < m_thinkInfo[indexUser].m_thinkData[indexThink].m_card.size(); ++n)
					{
						CardValue v;
						v.m_color = m_thinkInfo[indexUser].m_thinkData[indexThink].m_card[n]->m_color;
						v.m_number = m_thinkInfo[indexUser].m_thinkData[indexThink].m_card[n]->m_number;
						info.m_card.push_back(v);
					}
					msgThink.m_think.push_back(info);
				}
			}
			else
			{
				msgThink.m_flag = 0;
			}

			m_desk->m_user[indexUser]->Send(msgThink);
		}
        UpdateLastWaitThinkRetTime();
	}
	else
	{
		ThinkEnd();
	}
}

//����˼������
void HandlerObject::ThinkEnd()
{
	Lint nUserCount = m_desk->GetDeskUserCount();
	for(int i = 0; i < nUserCount; i ++)
	{
		if (m_thinkInfo[i].NeedThink())
		{
			VideoDoing(99,i,0,0);
		}
		m_thinkInfo[i].Reset();
	}
	Lint huCount = 0;

	Lint pengPos = INVAILD_POS;
	Lint gangPos = INVAILD_POS;
	Lint buPos = INVAILD_POS;
	Lint chiPos = INVAILD_POS;
	for (Lint i = 0; i < nUserCount; ++i)
	{
		if (m_thinkRet[i].m_type == THINK_OPERATOR_BOMB)
		{
			m_playerHuInfo[i] = WIN_SUB_BOMB;
			m_playerBombInfo[i] = WIN_SUB_ABOMB;
			huCount++;
		}

		if (m_thinkRet[i].m_type == THINK_OPERATOR_MBU)
			buPos = i;

		if (m_thinkRet[i].m_type == THINK_OPERATOR_PENG)
			pengPos = i;

		if (m_thinkRet[i].m_type == THINK_OPERATOR_CHI)
			chiPos = i;
	}

	//����
	if (huCount != 0)
	{	
		//�������˺���  ÿ����Ҷ����ú�����Ϊ������һ�ڶ�������
		CardVector winCards[DESK_USER_COUNT] ;
		for (int i = 0; i < nUserCount; i++)
		{
			winCards[i].push_back(m_curOutCard);
		}
		OnGameOver(WIN_BOMB, m_playerHuInfo, m_beforePos, winCards);
		return;
	}

	//�� ���������������
	if (buPos != INVAILD_POS)
	{
		//���ܲ���������ִ��
		//m_beforeType = THINK_OPERATOR_MBU;

		m_bGenFengOver = true;

		LMsgS2CUserOper send;
		send.m_pos = buPos;
		send.m_beforePos = m_beforePos;
		send.m_errorCode = 0;
		send.m_think.m_type = m_thinkRet[buPos].m_type;
		for(Lsize i = 0 ; i < m_thinkRet[buPos].m_card.size(); ++i)
		{
			CardValue v;
			v.m_color = m_thinkRet[buPos].m_card[i]->m_color;
			v.m_number = m_thinkRet[buPos].m_card[i]->m_number;
			send.m_think.m_card.push_back(v);
		}
		send.m_card.m_color = m_curOutCard->m_color;
		send.m_card.m_number = m_curOutCard->m_number;
		m_desk->BoadCast(send);

		if (m_thinkRet[buPos].m_card.size()>0)
		{
			gCardMgr.EraseCard(m_handCard[buPos], m_thinkRet[buPos].m_card[0], 3);
		}
		else
		{
			LLOG_ERROR("ERROR: HandlerObject::ThinkEnd m_thinkRet[buPos].m_card.size()<=0");
		}

		//�ѶԷ����ϵ����һ�ų�����ȥ��
		gCardMgr.EraseCard(m_outCard[m_beforePos], m_curOutCard);

		//¼��
		std::vector<CardValue> cards;
		for (int i = 0; i < nUserCount; i ++)
		{
			CardValue card;
			card.m_color = m_curOutCard->m_color;
			card.m_number = m_curOutCard->m_number;
			cards.push_back(card);
			m_mgangCard[buPos].push_back(m_curOutCard);
		}
		m_video.AddOper(VIDEO_OPER_OTHER_BU, buPos, cards);

		m_dianGang[buPos] += 1;
		m_fangGang[m_beforePos] += 1;

		for (int i = 0; i < nUserCount; i ++)
		{
			m_thinkRet[i].Clear();
		}

		m_before2Pos  = m_beforePos;
		m_before2Type = m_beforeType;

		m_beforeType = THINK_OPERATOR_MBU;
		m_beforePos = buPos;

		SetPlayIng(buPos, true, true, true, true);
		return;
	}

	if (pengPos != INVAILD_POS)
	{
		m_before2Pos  = m_beforePos;
		m_before2Type = m_beforeType;

		//��������״̬Ϊ��
		m_beforeType = THINK_OPERATOR_PENG;

		m_bGenFengOver = true;

		LMsgS2CUserOper send;
		send.m_pos = pengPos;
		send.m_beforePos = m_beforePos;
		send.m_errorCode = 0;
		send.m_think.m_type = m_thinkRet[pengPos].m_type;
		for(Lsize i = 0 ; i < m_thinkRet[pengPos].m_card.size(); ++i)
		{
			CardValue v;
			v.m_color = m_thinkRet[pengPos].m_card[i]->m_color;
			v.m_number = m_thinkRet[pengPos].m_card[i]->m_number;
			send.m_think.m_card.push_back(v);
		}
		send.m_card.m_color = m_curOutCard->m_color;
		send.m_card.m_number = m_curOutCard->m_number;
		m_desk->BoadCast(send);
		gCardMgr.EraseCard(m_handCard[pengPos], m_curOutCard,2);

		//�ѶԷ����ϵ����һ�ų�����ȥ��
		gCardMgr.EraseCard(m_outCard[m_beforePos], m_curOutCard);

		//¼��
		std::vector<CardValue> cards;
		for (Lint i = 0; i < 3; i ++)
		{
			CardValue card;
			card.m_color = m_curOutCard->m_color;
			card.m_number = m_curOutCard->m_number;
			cards.push_back(card);
			m_pengCard[pengPos].push_back(m_curOutCard);
		}
		m_video.AddOper(VIDEO_OPER_PENG_CARD, pengPos, cards);

		for (int i = 0; i < nUserCount; i ++)
		{
			m_thinkRet[i].Clear();
		}
		//�����һ����
		m_curGetCard = NULL;
		SetPlayIng(pengPos, false, false, true, false);
		m_needGetCard = true;
		return;
	}

	//��
	if (chiPos != INVAILD_POS)
	{
		if (m_thinkRet[chiPos].m_card.size()>=2)
		{
			m_before2Pos = m_beforePos;
			m_before2Type = m_beforeType;

			//��������״̬Ϊ��
			m_beforeType = THINK_OPERATOR_CHI;

			LMsgS2CUserOper send;
			send.m_pos = chiPos;
			send.m_beforePos = m_beforePos;
			send.m_errorCode = 0;
			send.m_think.m_type = m_thinkRet[chiPos].m_type;
			for (Lsize i = 0; i < m_thinkRet[chiPos].m_card.size(); ++i)
			{
				CardValue v;
				v.m_color = m_thinkRet[chiPos].m_card[i]->m_color;
				v.m_number = m_thinkRet[chiPos].m_card[i]->m_number;
				send.m_think.m_card.push_back(v);
			}
			send.m_card.m_color = m_curOutCard->m_color;
			send.m_card.m_number = m_curOutCard->m_number;
			m_desk->BoadCast(send);
			gCardMgr.EraseCard(m_handCard[chiPos], m_thinkRet[chiPos].m_card);

			//�ѶԷ����ϵ����һ�ų�����ȥ��
			gCardMgr.EraseCard(m_outCard[m_beforePos], m_curOutCard);

			//¼��
			std::vector<CardValue> cards;
			//����
			CardValue card;
			card.m_color = m_thinkRet[chiPos].m_card[0]->m_color;
			card.m_number = m_thinkRet[chiPos].m_card[0]->m_number;
			cards.push_back(card);
			//�Ե��Ʒ��м�
			card.m_color = m_curOutCard->m_color;
			card.m_number = m_curOutCard->m_number;
			cards.push_back(card);
			//����
			card.m_color = m_thinkRet[chiPos].m_card[1]->m_color;
			card.m_number = m_thinkRet[chiPos].m_card[1]->m_number;
			cards.push_back(card);

			m_video.AddOper(VIDEO_OPER_EAT, chiPos, cards);

			m_eatCard[chiPos].push_back(m_thinkRet[chiPos].m_card[0]);
			m_eatCard[chiPos].push_back(m_curOutCard);
			m_eatCard[chiPos].push_back(m_thinkRet[chiPos].m_card[1]);

			Lint temCardCount = m_handCard[chiPos].size() + m_pengCard[chiPos].size() + m_mgangCard[chiPos].size() + m_eatCard[chiPos].size();

			for (int i = 0; i < nUserCount; i++)
			{
				m_thinkRet[i].Clear();
			}
			//��Ҵ�һ����
			m_curGetCard = NULL;
			SetPlayIng(chiPos, false, false, true, false);
			m_needGetCard = true;
		} 
		else
		{
			LLOG_ERROR("ERROR: HandlerObject::ThinkEnd m_thinkRet[chiPos].m_card.size()<2");
		}
		
		return;
	}

	//����û���˲�����û������������*
	if (m_beforeType == THINK_OPERATOR_MBU)
	{
		//¼��
		std::vector<CardValue> cards;
		for (int i = 0; i < 4; i ++)
		{
			CardValue card;
			card.m_color = m_curOutCard->m_color;
			card.m_number = m_curOutCard->m_number;
			cards.push_back(card);
		}

		m_video.AddOper(VIDEO_OPER_SELF_BU, m_beforePos, cards);

		m_mgangCard[m_beforePos].push_back(m_curOutCard);
		CardVector::iterator iter = m_pengCard[m_beforePos].begin();
		for(; iter != m_pengCard[m_beforePos].end();iter+=3)
		{
			//�Ӹ�
			if (*m_curOutCard == **iter)
			{
				m_mgangCard[m_beforePos].insert(m_mgangCard[m_beforePos].end(),iter,iter+3);
				m_pengCard[m_beforePos].erase(iter,iter+3);
				break;
			}
		}
		//���ﴦ�� ���� ��������Ϣ
		LMsgS2CUserPlay sendMsg;
		sendMsg.m_errorCode = 0;
		sendMsg.m_pos = m_beforePos;
		sendMsg.m_card.m_type = m_beforeType;
		CardValue card;
		card.m_color = m_curOutCard->m_color;
		card.m_number = m_curOutCard->m_number;
		sendMsg.m_card.m_card.push_back(card);

		sendMsg.m_Counter = m_outCardCounter;

		m_desk->BoadCast(sendMsg);

		m_buGang[m_beforePos] += 1;
		SetPlayIng(m_beforePos,true, true, true, true);
	}
	else
	{
		SetPlayIng(m_desk->GetNextPos(m_beforePos), true, false, true, true);
	}
}

//��ȡ��������
Lint HandlerObject::GetVIDEOHuType( std::vector<Lint>& huVector )
{
	Lint nRet = 0;
	for(Lsize index = 0; index < huVector.size(); ++index)
	{
		switch(huVector[index])
		{
		case HU_QIDUI:
			nRet |= VIDEO_OPER_HU_QIXIAODUI;
			break;
		case HU_HAO_QIDUI:
			nRet |= VIDEO_OPER_HU_HAO_QIDUI;
			break;
		case HU_QINGYISE:
			nRet |= VIDEO_OPER_HU_QINGYISE;
			break;
		case HU_QIANGGANGHU:
			nRet |= VIDEO_OPER_HU_QIANGGANGHU;
			break;
		case HU_GANG1:
			nRet |= VIDEO_OPER_HU_GANGHUA;
			break;
		case HU_DOUBLE_HAO_QIDUI:
			nRet |= VIDEO_OPER_HU_DOUBLE_HAO_QIDUI;
			break;
		case HU_DIANPAOHU:
			nRet |= VIDEO_OPER_HU_DIANPAOHU;
			break;
		case HU_SANHUNHUPAI:
			nRet |= VIDEO_OPER_HU_SANHUNHUPAI;
			break;
		case HU_BIANKADIAO:
			nRet |= VIDEO_OPER_HU_BIANKADIAO;
			break;
		case HU_TRIPLE_HAO_QIDUI:
			nRet |= VIDEO_OPER_HU_TRIPLE_HAO_QIDUI;
			break;
		case HU_ZHONGFABAI:
			nRet |= VIDEO_OPER_HU_ZHONGFABAI;
			break;
		case HU_258JIANG:
			nRet |= VIDEO_OPER_HU_258JIANG;
			break;
		case HU_TIANHU:
			nRet |= VIDEO_OPER_HU_TIANHU;
			break;
		case HU_HEISANFENG:
			nRet |= VIDEO_OPER_HU_HEISANFENG;
			break;
		case HU_13YAO:
			nRet |= VIDEO_OPER_HU_13YAO;
			break;
		case HU_MENQING:
			nRet |= VIDEO_OPER_HU_MENQING;
			break;
		}
	}

	if ( huVector.size() > 0 )
	{
		if ( huVector[0] == HU_ZIMOHU )
			nRet += VIDEO_OPER_HU_ZIMO;
		else
			nRet += VIDEO_OPER_HU_SHOUPAO;
	}

	return nRet;
}

//��ȡ����¼���¸�ʽ
void HandlerObject::GetNewVIDEOHuType(const std::vector<Lint>& huVector, std::vector<Lint>& videoHuVector)
{
	for (Lsize index = 0; index < huVector.size(); ++index)
	{
		switch (huVector[index])
		{
		case HU_XIAOHU:
			videoHuVector.push_back(VIDEO_OPER_HU_SHOUPAO);
			break;
		case HU_ZIMOHU:
			videoHuVector.push_back(VIDEO_OPER_HU_ZIMO);
			break;
		case HU_QIDUI:
			videoHuVector.push_back(VIDEO_OPER_HU_QIXIAODUI);
			break;
		case HU_HAO_QIDUI:
			videoHuVector.push_back(VIDEO_OPER_HU_HAO_QIDUI);
			break;
		case HU_QINGYISE:
			videoHuVector.push_back(VIDEO_OPER_HU_QINGYISE);
			break;
		case HU_QIANGGANGHU:
			videoHuVector.push_back(VIDEO_OPER_HU_QIANGGANGHU);
			break;
		case HU_GANG1:
			videoHuVector.push_back(VIDEO_OPER_HU_GANGHUA);
			break;
		case HU_DOUBLE_HAO_QIDUI:
			videoHuVector.push_back(VIDEO_OPER_HU_DOUBLE_HAO_QIDUI);
			break;
		case HU_DIANPAOHU:
			videoHuVector.push_back(VIDEO_OPER_HU_DIANPAOHU);
			break;
		case HU_SANHUNHUPAI:
			videoHuVector.push_back(VIDEO_OPER_HU_SANHUNHUPAI);
			break;
		case HU_BIANKADIAO:
			videoHuVector.push_back(VIDEO_OPER_HU_BIANKADIAO);
			break;
		case HU_TRIPLE_HAO_QIDUI:
			videoHuVector.push_back(VIDEO_OPER_HU_TRIPLE_HAO_QIDUI);
			break;
		case HU_ZHONGFABAI:
			videoHuVector.push_back(VIDEO_OPER_HU_ZHONGFABAI);
			break;
		case HU_258JIANG:
			videoHuVector.push_back(VIDEO_OPER_HU_258JIANG);
			break;
		case HU_TIANHU:
			videoHuVector.push_back(VIDEO_OPER_HU_TIANHU);
			break;
		case HU_HEISANFENG:
			videoHuVector.push_back(VIDEO_OPER_HU_HEISANFENG);
			break;
		case HU_13YAO:
			videoHuVector.push_back(VIDEO_OPER_HU_13YAO);
			break;
		case HU_MENQING:
			videoHuVector.push_back(VIDEO_OPER_HU_MENQING);
			break;
		case HU_DA_DUIZI:
			videoHuVector.push_back(VIDEO_OPER_HU_DADUIZI);
			break;
		case HU_BIANKA:
			videoHuVector.push_back(VIDEO_OPER_HU_BIANKA);
			break;
		case HU_DIAO:
			videoHuVector.push_back(VIDEO_OPER_HU_DIAO);
			break;
		case HU_DUIDAO:
			videoHuVector.push_back(VIDEO_OPER_HU_DUIDAO);
			break;
		}
	}
}

//��Ϸ����
void HandlerObject::OnGameOver(Lint result, Lint winType[], Lint bombpos, CardVector winCards[])
{
	if (m_desk == NULL || m_desk->m_vip == NULL)
	{
		LLOG_DEBUG("OnGameOver NULL ERROR ");
		return;
	}
    UpdateLastWaitThinkRetTime();
	Lint nUserCount = m_desk->GetDeskUserCount();

	//������ҵ÷�
	Lint gold[DESK_USER_COUNT] = {0};	//��ҷ���
	calcScore(bombpos, winType, gold);

	//Ӯ��λ��
	Lint winPos = winnerPos(winType);
	winPos = winPos == INVAILD_POS ? m_curPos : winPos;

	//�õ���λ
	if (WIN_BOMB == result)
	{
		winType[m_beforePos] = WIN_SUB_ABOMB;		
	}

	//������һ��ׯ��
	Lint zhuangPos = m_zhuangPos;
	m_zhuangPos = nextZhuangPos(m_zhuangPos, winType);

	//¼��
	if (WIN_ZIMO == result || WIN_BOMB == result)
	{
		std::vector<CardValue> cards;
		for (Lsize indexCard = 0; indexCard < winCards[winPos].size(); ++indexCard)
		{
			CardValue currCard;
			currCard.m_color = winCards[winPos][indexCard]->m_color;
			currCard.m_number = winCards[winPos][indexCard]->m_number;
			cards.push_back(currCard);
		}

		for(Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
		{
			Lint nVideoRet = GetVIDEOHuType(m_thinkRet[indexUser].m_hu);
			if (0 != nVideoRet)
			{
				m_video.AddOper(nVideoRet, indexUser, cards);
			}
		}
	}
	else
	{
		std::vector<CardValue> cards;
		m_video.AddOper(VIDEO_OPER_HUANGZHUANG, m_curPos, cards);
	}

	//����¼��
	m_video.m_Id = gVipLogMgr.GetVideoId();
	m_video.m_appID = m_desk->m_appId;
	m_video.m_playType = m_desk->getPlayType();
	LMsgL2LDBSaveVideo msgSaveVideo;
	msgSaveVideo.m_type = 0;
	msgSaveVideo.m_sql = m_video.GetInsertSql();
	gWork.SendMsgToDb(msgSaveVideo);

	//�û�����������
	Lint userMingGang[DESK_USER_COUNT] = {0};
	for(Lint indexMGang = 0; indexMGang < nUserCount; ++indexMGang)
	{
		userMingGang[indexMGang] += m_buGang[indexMGang];
		userMingGang[indexMGang] += m_dianGang[indexMGang];
	}

	//��VipLogItem�ڵĿ۳��ܷ������˴�
	VipLogItem* pVipLogItem = m_desk->GetVip();
	for(Lint i = 0; i < nUserCount; ++i)
	{
		pVipLogItem->m_score[i] += gold[i];
	}

	//������	
	m_desk->m_vip->AddLog(m_desk->m_user, gold, winType, zhuangPos, m_anGang, userMingGang, m_playerBombInfo, m_video.m_Id);



	//�㲥���
	LMsgS2CGameOver msgGameOver;

	msgGameOver.m_result = result;
	//��䱨������
	buildGameOver(winCards, gold, winType, msgGameOver);
	//�����淨��չ����
	patchGameOver(winType, msgGameOver);
	//�㲥����
	m_desk->BoadCast(msgGameOver);

	LLOG_DEBUG("HandlerObject::OnGameOver m_win %d  %d  %d  %d ", msgGameOver.m_win[0],  msgGameOver.m_win[1],  msgGameOver.m_win[2], msgGameOver.m_win[3]);

	m_desk->SetDeskWait();
    //�Ƿ����һ��
    msgGameOver.m_end = m_desk->m_vip->isEnd() ? 1 : 0;
    if (m_desk->m_vip->GetMatchID())
    {
        m_desk->m_vip->Report2MatchServer(msgGameOver);
    }

	m_desk->HanderGameOver();
}

//����˼��¼��
void HandlerObject::VideoThink(Lint pos)
{
	if (m_thinkInfo[pos].m_thinkData.size() >0)
	{
		std::vector<CardValue> cards;
		ThinkVec& thinkData = m_thinkInfo[pos].m_thinkData;
		for (auto iter = thinkData.begin(); iter != thinkData.end(); ++iter)
		{
			CardValue card;
			card.m_number = iter->m_type;

			if (0 < iter->m_card.size())
			{
				card.m_color  = iter->m_card[0]->m_color * 10 + iter->m_card[0]->m_number;
			}

			if (1 < iter->m_card.size())
			{
				card.m_color  = card.m_color * 1000 + iter->m_card[1]->m_color * 10+iter->m_card[1]->m_number;
			}

			cards.push_back(card);
		}
		m_video.AddOper(VIDEO_OPEN_THINK, pos, cards);
	}
}

//�������¼��
void HandlerObject::VideoDoing(Lint op, Lint pos, Lint card_color, Lint card_number)
{
	std::vector<CardValue> cards;
	CardValue card;
	card.m_number = op;
	card.m_color  = card_color*10+card_number;
	cards.push_back(card);
	m_video.AddOper(VIDEO_OPEN_DOING, pos, cards);
}

//����
void HandlerObject::Debug_GiveCard(Lstring& msg)
{
	std::vector<Lstring> des;
	L_ParseString(msg, des, " ");
	if (des.size() == 3)
	{
		if (des[0] == "#give")
		{
			for (auto itr=m_deskCard.begin(); itr!=m_deskCard.end(); itr++)
			{
				if ((*itr)->m_number == atoi(des[2].c_str()) && (*itr)->m_color == atoi(des[1].c_str()))
				{
					std::swap((*itr),m_deskCard.back());
					break;
				}
			}
		}
	}
}

//�������㲥������
void HandlerObject::SendSelectPaoZi()
{
	//�㲥��Ϣ
	LMsgS2CUserSetPaoZi send;
	send.m_time = 5;        //������Ĭ�ϵ���ʱ����Ϊ5��
	send.m_StatePaozi = 0;        //������Ĭ������״̬

	m_desk->BoadCast(send);

	m_desk->m_deskState = DESK_SELECT_PAOZI;
}


bool HandlerObject::initCards(CardVector& cards)
{
	//������Ͳ����
	for (Lint indexColor = 0; indexColor < 3; indexColor ++)
	{
		for (Lint indexNumber = 0; indexNumber < 9; indexNumber ++)
		{
			cards.push_back(gCardMgr.GetCard(indexColor + 1, indexNumber + 1));
			cards.push_back(gCardMgr.GetCard(indexColor + 1, indexNumber + 1));
			cards.push_back(gCardMgr.GetCard(indexColor + 1, indexNumber + 1));
			cards.push_back(gCardMgr.GetCard(indexColor + 1, indexNumber + 1));
		}
	}

	//���Ӷ����ϡ����������С�������
	for(Lint indexFeng = 0; indexFeng < 7; ++indexFeng)
	{
		cards.push_back(gCardMgr.GetCard(CARD_COLOR_FENG_JIAN, indexFeng + 1));
		cards.push_back(gCardMgr.GetCard(CARD_COLOR_FENG_JIAN, indexFeng + 1));
		cards.push_back(gCardMgr.GetCard(CARD_COLOR_FENG_JIAN, indexFeng + 1));
		cards.push_back(gCardMgr.GetCard(CARD_COLOR_FENG_JIAN, indexFeng + 1));
	}

	return true;
}

bool HandlerObject::checkStartGame()
{
	return true;
}

//���ƺ��������˼��
void HandlerObject::thinkOutCard(Lint outPos, Card* outCard)
{
	//��Ч�Լ��
	if (outPos < 0 || 3 < outPos || NULL == outCard)
	{
		return;
	}

	m_thinkRet[outPos].Clear();
	m_thinkInfo[outPos].Reset();

	Lint nUserCount = m_desk->GetDeskUserCount();
	for(Lint indexUser = 0 ; indexUser < nUserCount; ++indexUser)
	{
		if (indexUser != outPos)
		{
			m_thinkRet[indexUser].Clear();
			m_thinkInfo[indexUser].Reset();
			ThinkUnit unit;

			//����
			if (checkCanHu(indexUser, outCard, unit.m_hu))
			{
				unit.m_type = THINK_OPERATOR_BOMB;
				unit.m_card.push_back(outCard);
				m_thinkInfo[indexUser].m_thinkData.push_back(unit);
			}

			//����
			if (checkCanGang(indexUser, m_handCard[indexUser], outCard))
			{
				unit.Clear();
				unit.m_type = THINK_OPERATOR_MBU;
				unit.m_card.push_back(outCard);
				m_thinkInfo[indexUser].m_thinkData.push_back(unit);
			}

			//����
			if (checkCanPeng(indexUser, m_handCard[indexUser], outCard))
			{
				unit.Clear();
				unit.m_type = THINK_OPERATOR_PENG;
				unit.m_card.push_back(outCard);
				m_thinkInfo[indexUser].m_thinkData.push_back(unit);
			}
		}
	}
}

//���ƺ����˼��
void HandlerObject::thinkGetCard(Lint getPos, Card* getCard, bool canHu)
{
	ThinkUnit unit;

	//����
	if (checkCanHu(getPos, getCard, unit.m_hu))
	{
		unit.m_type = THINK_OPERATOR_BOMB;
		unit.m_card.push_back(getCard);
		m_thinkInfo[getPos].m_thinkData.push_back(unit);
	}

	//����
	CardVector gangCard;
	if (checkCanGang(getPos, m_handCard[getPos], gangCard))
	{
		for (CardVector::size_type indexGang = 0; indexGang < gangCard.size(); ++indexGang)
		{
			unit.Clear();
			unit.m_type = THINK_OPERATOR_ABU;
			unit.m_card.push_back(gangCard[indexGang]);
			m_thinkInfo[getPos].m_thinkData.push_back(unit);
		}
	}

	//����
	if (checkCanGang(getPos, m_handCard[getPos], getCard))
	{
		unit.Clear();
		unit.m_type = THINK_OPERATOR_ABU;
		unit.m_card.push_back(getCard);
		m_thinkInfo[getPos].m_thinkData.push_back(unit);
	}

	//����(�Ӹ�)
	if (checkCanGang(getPos, m_pengCard[getPos], getCard))
	{
		unit.Clear();
		unit.m_type = THINK_OPERATOR_MBU;
		unit.m_card.push_back(getCard);
		m_thinkInfo[getPos].m_thinkData.push_back(unit);
	}

	//���ƺ����Ƽ�� ��Ϊ����û�ܵ�����Ҫ���
	CardVector jiaGangCard;
	if( checkCanGang(getPos, m_handCard[getPos], m_pengCard[getPos], jiaGangCard) )
	{
		for (CardVector::size_type indexGang = 0; indexGang < jiaGangCard.size(); ++indexGang)
		{
			unit.Clear();
			unit.m_type = THINK_OPERATOR_MBU;
			unit.m_card.push_back(jiaGangCard[indexGang]);
			m_thinkInfo[getPos].m_thinkData.push_back(unit);
		}
	}
}

void HandlerObject::thinkMingGang(Lint gangPos, Card* gangCard)
{

}

//����˼�����
void HandlerObject::dealThinkResult(Lint userPos, const ThinkData& thinkResult)
{
	bool find = false;

	ThinkVec& thinkInfo = m_thinkInfo[userPos].m_thinkData;

	//�ӱ���˼���б����������˼�����
	for(Lsize indexThink = 0; indexThink < thinkInfo.size(); ++indexThink)
	{
		if (thinkInfo[indexThink].m_type == thinkResult.m_type &&
			thinkInfo[indexThink].m_card.size() == thinkResult.m_card.size())
		{
			//������б��Ƿ���ͬ
			bool check = true;
			for(Lsize indexCard = 0; indexCard < thinkResult.m_card.size(); ++indexCard)
			{
				if (thinkResult.m_card[indexCard].m_color != thinkInfo[indexThink].m_card[indexCard]->m_color || 
					thinkResult.m_card[indexCard].m_number != thinkInfo[indexThink].m_card[indexCard]->m_number)
				{
					check = false;
					break;
				}
			}

			//�ҵ�˼����Ŀ
			if (check)
			{
				m_thinkRet[userPos] = thinkInfo[indexThink];
				find = true;
				break;
			}
		}
	}//�ӱ���˼���б����������˼�����

	//û���ҵ�����˼�����Ϊ�գ�������
	if (!find)
	{
		m_thinkRet[userPos].m_type = THINK_OPERATOR_NULL;
	}
}

bool HandlerObject::continueThink()
{
	bool hu		= false;
	bool Peng	= false;
	//bool Chi	= false;
	bool Gang	= false;
	bool Bu		= false;
	bool hu_New		= false;
	bool Peng_New	= false;
	bool Chi_New	= false;
	bool Gang_New	= false;
	bool Bu_New		= false;

	Lint nUserCount = m_desk->GetDeskUserCount();
	for (Lint i = 0; i < nUserCount; ++i)
	{
		bool Chi	= false;
		//
		if (m_thinkRet[i].m_type == THINK_OPERATOR_BOMB)			hu		= true;
		else if (m_thinkRet[i].m_type == THINK_OPERATOR_PENG)		Peng	= true;
		else if (m_thinkRet[i].m_type == THINK_OPERATOR_CHI)		Chi		= true;
		else if (m_thinkRet[i].m_type == THINK_OPERATOR_MBU)		Bu		= true;

		//
		if (m_thinkInfo[i].NeedThink())
		{
			if (m_thinkInfo[i].HasHu())				hu_New		= true;
			else if (m_thinkInfo[i].HasPeng())		Peng_New	= true;
			else if (m_thinkInfo[i].HasChi())		Chi_New		= true;
			else if (m_thinkInfo[i].HasMBu())		Bu_New		= true;
		}
	}

	bool think = false;

	if (hu_New)	
	{
		think = true;
	}
	else
	{
		if (!hu)
		{
			if (Peng_New || Gang_New || Bu_New )
				think = true;
			else
			{
				if (!(Peng || Gang || Bu))
				{
					if (Chi_New)
						think = true;
				}
			}
		}
	}

	return think;
}

bool HandlerObject::calcScore(Lint lostPos, const Lint winType[], Lint userGold[])
{
	return false;
}

//����Ӯ��λ��

Lint HandlerObject::winnerPos(const Lint winType[])
{
	Lint winPos = INVAILD_POS;

	Lint nUserCount = m_desk->GetDeskUserCount();
	for (Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
	{
		//��Һ��� ��������
		if (WIN_SUB_ZIMO == winType[indexUser] || WIN_SUB_BOMB == winType[indexUser])
		{
			winPos = indexUser;
			break;
		}
	}

	return winPos;
}

/*
Lint HandlerObject::winnerPos(Lint zhuangPos, const Lint winType[])
{
	Lint winPos = INVAILD_POS;

	zhuangPos = (zhuangPos < 0 || 3 < zhuangPos ? 0 : zhuangPos);

	for (Lint indexUser = 0; indexUser < DESK_USER_COUNT; ++indexUser)
	{
		Lint correctPos = (indexUser + zhuangPos) % DESK_USER_COUNT;

		//��Һ��� ��������
		if (WIN_SUB_ZIMO == winType[correctPos] || WIN_SUB_BOMB == winType[correctPos])
		{
			winPos = correctPos;
			break;
		}
	}

	return winPos;
}
*/

//������һ��ׯ��λ��
//˭Ӯ˭��ׯ��һ�ڶ����������ׯ
//����ׯ�Ҽ�����ׯ
Lint HandlerObject::nextZhuangPos(Lint zhuangPos, Lint winType[])
{
	Lint NewZhuangPos = zhuangPos;
	Lint nBoomPos = 0;
	Lint nWinNum = 0;

	Lint nUserCount = m_desk->GetDeskUserCount();
	for(Lint i = 0; i < nUserCount; ++i)
	{
		if(winType[i] == WIN_SUB_BOMB || winType[i] == WIN_SUB_ZIMO)
		{
			NewZhuangPos = i;
			nWinNum++;
		}
		else if( winType[i] == WIN_SUB_ABOMB )
		{
			nBoomPos = i;
		}
	}

	if( nWinNum > 1 )
	{
		//һ�ڶ����°ѵ��ڵ���ׯ
		NewZhuangPos = nBoomPos;
	}

	return NewZhuangPos;
}


//��������Ϸ�ı���
//һ�ڶ���ʱ��ͬһ�ź����ƷŽ� winCards ���ٴΣ�
void HandlerObject::buildGameOver(const CardVector winCards[], const Lint userGold[], Lint winType[], LMsgS2CGameOver& over)
{
	Lint nUserCount = m_desk->GetDeskUserCount();

	//�û�����������
	Lint userMingGang[DESK_USER_COUNT] = {0};
	for(Lint indexMGang = 0 ; indexMGang < nUserCount; ++indexMGang)
	{
		userMingGang[indexMGang] += m_buGang[indexMGang];
		userMingGang[indexMGang] += m_dianGang[indexMGang];
	}

	over.m_playMode = m_desk->GetVip()->m_playMode;
	over.m_playPara = m_desk->getPlayPara();
	memcpy(over.m_score, userGold, sizeof(over.m_score));
	memcpy(over.m_agang, m_anGang, sizeof(over.m_agang));
	memcpy(over.m_mgang, userMingGang, sizeof(over.m_mgang));
	memcpy(over.m_dgang, m_fangGang, sizeof(over.m_dgang));
	memcpy(over.m_Paozi, m_desk->m_paozi, sizeof(over.m_Paozi));

	//������ϵ���
	for (Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
	{
		over.m_count[indexUser] = m_handCard[indexUser].size();

		//����
		for (Lint indexCard = 0; indexCard < over.m_count[indexUser]; ++indexCard)
		{
			over.m_card[indexUser][indexCard].m_color = m_handCard[indexUser][indexCard]->m_color;
			over.m_card[indexUser][indexCard].m_number = m_handCard[indexUser][indexCard]->m_number;
		}

		//��������
		if (m_thinkRet[indexUser].m_type == THINK_OPERATOR_BOMB)
		{
			std::vector<Lint> vHu = m_thinkRet[indexUser].m_hu;
			over.m_hu[indexUser].push_back(vHu);
		}
	}

	if ( winCards )
	{
		Lint nUserCount = m_desk->GetDeskUserCount();
		for (Lint indexUser = 0; indexUser < nUserCount; ++indexUser)
		{
			//��Һ��� ��������
			if (WIN_SUB_ZIMO == winType[indexUser] || WIN_SUB_BOMB == winType[indexUser])
			{
				Lint winPos = indexUser;

				for (Lsize indexCard = 0; indexCard < winCards[winPos].size(); ++indexCard)
				{
					CardValue curGetCard;
					curGetCard.m_color = winCards[winPos][indexCard]->m_color;
					curGetCard.m_number = winCards[winPos][indexCard]->m_number;
					over.m_hucards[winPos].push_back(curGetCard);
				}
			}
		}
	}

	//�Ƿ����һ��
	over.m_end = m_desk->m_vip->isEnd() ? 1 : 0;

	//����Ӯ������
	Lint bombCount = 0;
	for (Lint indexBomb = 0; indexBomb < nUserCount; ++indexBomb)
	{
		if(winType[indexBomb] == WIN_SUB_ZIMO || winType[indexBomb] == WIN_SUB_BOMB)
		{
			++bombCount;
		}
	}

	//Ϊ�����߼��� һ�Ҽ���
	if (1 < bombCount)
	{
		for(Lint indexWinType = 0; indexWinType < nUserCount; ++indexWinType)
		{
			if( winType[indexWinType] == WIN_SUB_ABOMB )
			{
				if( 2 == bombCount )
				{
					winType[indexWinType] = WIN_SUB_TWO;
				}
				else if( 3 == bombCount )
				{
					winType[indexWinType] = WIN_SUB_THERE;
				}
				break;
			}
		}
	}
	memcpy(over.m_win, winType, sizeof(over.m_win));
}

void HandlerObject::patchGameOver(const Lint winType[], LMsgS2CGameOver& msgOver)
{

}


//������
bool HandlerObject::checkCanHu(Lint userPos, Card* singleCard, std::vector<Lint>& huType)
{
	bool canHu = false;

	if (NULL != singleCard)
	{
		CardVector tempCard(m_handCard[userPos]);
		tempCard.push_back(singleCard);
		gCardMgr.SortCard(tempCard);

		if (matchHu_ShunKe(tempCard, 0))
		{
			huType.push_back(m_curPos == userPos ? HU_ZIMOHU : HU_XIAOHU);
			canHu = true;
		}
	}

	return canHu;
}


//������
bool HandlerObject::checkCanChi(const CardVector& cards, Card* singleCard, CardVector& eatCard) const
{
	bool canChi = false;

	//����Ͱ�����ƿ��Գ�
	if (NULL != singleCard && singleCard->m_color != CARD_COLOR_FENG_JIAN)
	{
		Card* colorCards[5] = {NULL, NULL, singleCard, NULL, NULL};

		//����ָ����ǰ����2���ڵ���
		CardVector::size_type cardCount = cards.size();
		for (CardVector::size_type index = 0; index < cardCount; ++index)
		{
			if (cards[index]->m_color == singleCard->m_color &&
				abs(cards[index]->m_number - singleCard->m_number) <= 2)
			{
				colorCards[cards[index]->m_number - singleCard->m_number + 2] = cards[index];
			}
		}

		//���� Current Next Single
		if (NULL != colorCards[0] && NULL != colorCards[1])
		{
			eatCard.push_back(colorCards[0]);
			eatCard.push_back(colorCards[1]);
			canChi = true;
		}

		//���� Current Single Next
		if (NULL != colorCards[1] && NULL != colorCards[3])
		{
			eatCard.push_back(colorCards[1]);
			eatCard.push_back(colorCards[3]);
			canChi = true;
		}

		//���� Single Current Next
		if (NULL != colorCards[3] && NULL != colorCards[4])
		{
			eatCard.push_back(colorCards[3]);
			eatCard.push_back(colorCards[4]);
			canChi = true;
		}
	}

	return canChi;
}

//�������
bool HandlerObject::checkCanPeng(Lint userPos, const CardVector& cards, Card* singleCard) const
{
	bool canPeng = false;

	if (NULL != singleCard)
	{
		CardVector::size_type indexCard = 0;
		CardVector::size_type cardCount = cards.size();
		for (indexCard = 0; indexCard + 1 < cardCount && !canPeng; ++indexCard)
		{
			canPeng = (*singleCard == *cards[indexCard] && *singleCard == *cards[indexCard + 1]);
		}
	}

	return canPeng;
}

//������
bool HandlerObject::checkCanGang(Lint userPos, const CardVector& cards, Card* singleCard) const
{
	bool canGang = false;

	if (NULL != singleCard)
	{
		CardVector::size_type indexCard = 0;
		CardVector::size_type cardCount = cards.size();
		for (indexCard = 0; indexCard + 2 < cardCount && !canGang; ++indexCard)
		{
			canGang = (*singleCard == *cards[indexCard] && *singleCard == *cards[indexCard + 2]);
		}
	}

	return canGang;
}

//��ָ���Ƽ����ڼ���
bool HandlerObject::checkCanGang(Lint userPos, const CardVector& cards, CardVector& gangCard) const
{
	bool canGang = false;

	CardVector::size_type cardCount = cards.size();
	for (CardVector::size_type indexCard = 0; indexCard + 3 < cardCount;)
	{
		if (*cards[indexCard] == *cards[indexCard + 3])
		{
			gangCard.push_back(cards[indexCard]);
			canGang = true;
			indexCard += 4;
		}
		else
		{
			indexCard++;
		}
	}

	return canGang;
}

//��ָ���Ƽ��Ϻͼ����ڼ���
bool HandlerObject::checkCanGang(Lint userPos, const CardVector& src_cards, const CardVector& desc_cards, CardVector& gangCard) const
{
	bool canGang = false;

	CardVector::size_type srcCardCount = src_cards.size();
	for (CardVector::size_type srcIndexCard = 0; srcIndexCard < srcCardCount; ++srcIndexCard)
	{
		if(checkCanGang(userPos, desc_cards, src_cards[srcIndexCard]))
		{
			gangCard.push_back(src_cards[srcIndexCard]);

			canGang = true;
		}
	}

	return canGang;
}

//ʹ�����ƥ��˳�ӡ�����
bool HandlerObject::matchHu_ShunKe(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	if( cards.empty() && (2 == laiZiCount || 5 == laiZiCount) )
	{
		//������Ϊ��ֱ�Ӻ��� ��Ϊ����ֻʣ��������������
		return true;
	}

	bool bRet = false;

	Luchar szCards[52] = {0};	// ��00Ͱ00��00��00��00��00��00��00��00��

	//������֯����
	for (CardVector::size_type index = 0; index < cards.size(); ++index)
	{
		if (cards[index]->m_color < CARD_COLOR_FENG_JIAN)
		{
			szCards[(cards[index]->m_color - 1) * 11 + cards[index]->m_number - 1] += 1;
		}
		else
		{
			szCards[(cards[index]->m_color - 1) * 11 + (cards[index]->m_number - 1) * 3] += 1;
		}
	}

	//��ʱ���� ʹ�������ȫƥ���������γ�˳�ӻ����
	std::function<bool(Luchar*, Lint, Lint, std::set<Luchar*>*)> matchLaiZi = 
		[&](Luchar* cards, Lint count, Lint laiZiCount, std::set<Luchar*>* pTingMatch)->bool
	{
		bool result = false;

		//ƥ�����
		if (0 < count && 0 < cards[0] && 3 <= cards[0] + laiZiCount)
		{
			Luchar bkCardCount	= cards[0];
			laiZiCount -= std::max(3 - cards[0], 0);
			cards[0]	= std::max(cards[0] - 3, 0);

			if (matchLaiZi(cards, count, laiZiCount, pTingMatch))
			{
				result = true;
				if (NULL != pTingMatch && bkCardCount < 3)
				{
					pTingMatch->insert(cards);
				}
			}

			cards[0]	= bkCardCount;
			laiZiCount	+= std::max(3 - cards[0], 0);
		}

		//ƥ��˳��
		if (2 < count && (!result || NULL != pTingMatch))
		{
			//����������λ����������������������
			if (2 <= (Lint)(0 < cards[0]) + (Lint)(0 < cards[1]) + (Lint)(0 < cards[2]))
			{
				if ((0 < cards[0] && 0 < cards[1] && 0 < cards[2]) || 0 < laiZiCount)
				{
					Luchar bkFirstCount		= cards[0];
					Luchar bkSecondCount	= cards[1];
					Luchar bkThirdCount		= cards[2];
					laiZiCount -= cards[0] == 0 ? 1 : 0;
					laiZiCount -= cards[1] == 0 ? 1 : 0;
					laiZiCount -= cards[2] == 0 ? 1 : 0;
					cards[0] = std::max(cards[0] - 1, 0);
					cards[1] = std::max(cards[1] - 1, 0);
					cards[2] = std::max(cards[2] - 1, 0);

					if (matchLaiZi(cards, count, laiZiCount, pTingMatch))
					{
						result = true;
						if (NULL != pTingMatch && (bkFirstCount == 0 || bkSecondCount == 0 || bkThirdCount == 0))
						{
							pTingMatch->insert(bkFirstCount == 0 ? cards : (bkSecondCount == 0 ? (cards + 1) : (cards + 2)));
						}
					}

					cards[0] = bkFirstCount;
					cards[1] = bkSecondCount;
					cards[2] = bkThirdCount;
					laiZiCount += cards[0] == 0 ? 1 : 0;
					laiZiCount += cards[1] == 0 ? 1 : 0;
					laiZiCount += cards[2] == 0 ? 1 : 0;
				}
			}
		}//ƥ��˳��

		//����λ��
		if (0 < count && 0 == cards[0] && (!result || NULL != pTingMatch))
		{
			if (matchLaiZi(cards + 1, count - 1, laiZiCount, pTingMatch))
			{
				result = true;
			}
		}

		//������Ҫ
		if (count <= 0)
		{
			result = true;
		}

		return result;
	}; //��ʱ���� matchLaiZi()

	std::set<Luchar*> tingCards;
	std::set<Luchar*>* pTingMatch = NULL != pMatch ? &tingCards : NULL;
	Lint cardCount = sizeof(szCards) / sizeof(szCards[0]);

	//����Ƿ��������
	if ((cards.size() + laiZiCount) % 3 == 2)	//���ǽ���
	{
		for (Lint index = 0; index < cardCount && (!bRet || NULL != pTingMatch); ++index)
		{
			//�������Ƶ����
			if (0 < szCards[index] && 0 < laiZiCount)
			{
				szCards[index] -= 1;
				laiZiCount -= 1;
				if (matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch))
				{
					bRet = true;
					if (NULL != pTingMatch)
					{
						pTingMatch->insert(szCards + index);
					}
				}
				szCards[index] += 1;
				laiZiCount += 1;
			}
			//�Ѿ����ڽ��Ƶ����
			if ((!bRet || NULL != pMatch) && 2 <= szCards[index])
			{
				szCards[index] -= 2;
				bRet = matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch) || bRet;
				szCards[index] += 2;
			}
		}
	}
	else if ((cards.size() + laiZiCount) % 3 == 0)	//�����ǽ���
	{
		bRet = matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch);
	}


	//������ת��Ϊ����������
	if (bRet && NULL != pMatch)
	{
		Lint cardColor	= 0;
		Lint cardNumber	= 0;
		Lint jianPaiStart = (CARD_COLOR_FENG_JIAN - 1) * 11;
		std::set<Luchar*>::iterator iterTing = tingCards.begin();
		for (; iterTing != tingCards.end(); ++iterTing)
		{
			Lint cardIndex = *iterTing - szCards;
			if (jianPaiStart <= cardIndex)
			{
				pMatch->push_back(Card(CARD_COLOR_FENG_JIAN, (cardIndex - jianPaiStart) / 3 + 1));
			}
			else
			{
				cardColor = cardIndex / 11 + 1;
				cardNumber = (cardIndex - (cardColor - 1) * 11) + 1;
				if (1 <= cardNumber && cardNumber <= 9)
				{
					pMatch->push_back(Card(cardColor, cardNumber));
				}
			}
		}
	}

	return bRet;
}

//ʹ�����ƥ����С��
bool HandlerObject::matchHu_QiDui(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	bool bRet = false;

	//ȷ����14����
	if (cards.size() + laiZiCount == 14)
	{
		std::vector<Card> tingCard;	//����
		for (CardVector::size_type index = 0; index < cards.size();)
		{
			if (index + 1 < cards.size() && *cards[index] == *cards[index + 1])
			{
				index += 2;
			}
			else
			{
				tingCard.push_back(*cards[index]);
				index++;
			}
		}

		bRet = ((Lint)tingCard.size() <= laiZiCount);

		//�������ƥ�����
		if (bRet && NULL != pMatch && !tingCard.empty())
		{
			pMatch->assign(tingCard.begin(), tingCard.end());
		}
	}

	return bRet;
}

/*
//ƥ��ʮ���ۣ���������ӣ�
bool HandlerObject::matchHu_13Yao(const CardVector& cards) const
{
	bool bRet = false;

	std::set<Card*> mutualCards;
	Lint matchedCount = 0;

	//ȷ����14����
	if (cards.size() == 14)
	{
		CardVector::size_type handCount = cards.size();
		for (CardVector::size_type indexHand = 0; indexHand < handCount && bRet; ++indexHand)
		{
			if (cards[indexHand]->m_color == CARD_COLOR_FENG_JIAN ||
				cards[indexHand]->m_number == 1 || cards[indexHand]->m_number == 9)
			{
				mutualCards.insert(cards[indexHand]);
				matchedCount++;
			}
			else
			{
				return false;
			}
		}

		if (mutualCards.size()==13)
		{
			bRet = true;
		}
	}

	return bRet;
}
*/


//ƥ��ʮ���ۣ���������ӣ�����
bool HandlerObject::matchTing_13Yao(const CardVector& cards, std::vector<Lint>& vCardNC) const
{
	bool bRet = false;

	std::set<Card*> mutualCards;  //�ų��ظ��� �����еġ�ʮ�����ơ�
	Lint matchedCount = 0;        //�ų��ظ��� �����С�ʮ�����ơ�������

	//ȷ����14����
	if (cards.size() == 13)
	{
		//�� cards �еġ�ʮ�����ơ����� mutualCards �У� ��ͬ�Ʋ��ظ�����
		//������ڷǡ�ʮ�����ơ��򲻿�����ʮ���۵ķ�ʽ����
		for (CardVector::size_type indexHand = 0; indexHand < cards.size(); ++indexHand)
		{
			if (cards[indexHand]->m_color == CARD_COLOR_FENG_JIAN ||
				cards[indexHand]->m_number == 1 || cards[indexHand]->m_number == 9)
			{
				mutualCards.insert(cards[indexHand]);
				matchedCount++;
			}
			else
			{
				return false;
			}
		}

		//13���Ʒֱ��ǡ�ʮ�����ơ�֮һ�����ظ������Ժ�13�š�ʮ�����ơ�
		if (mutualCards.size()==13 && matchedCount>=13)
		{
			for (std::set<Card *>::iterator it = mutualCards.begin(); it != mutualCards.end(); it++) 
			{
				vCardNC.push_back((*it)->GetNCIndex());
			}
			bRet = true;
		}

		//13�š�ʮ�����ơ�ֻ��һ���ظ���Ҳֻ��һ�š�ʮ�����ơ������������У����Ų����ڵġ�ʮ�����ơ����ǿɺ���
		if (mutualCards.size()==12 && matchedCount>=13)
		{
			for (Luint i=0; i<13; i++)
			{
				int flag = 0;
				for (std::set<Card *>::iterator it = mutualCards.begin(); it != mutualCards.end(); it++) 
				{
					if( (*it)->GetNCIndex() == Card::m_a13YaoNC[i] )
					{
						flag = 1;
						break;
					}
				}
				if (flag==0)
				{
					vCardNC.push_back(Card::m_a13YaoNC[i] );
				}
			}
			bRet = true;
		}
	}

	return bRet;
}

//ʹ�����ƥ����С�� ����ƥ�������˫�����ͳ������߶�
//Ŀǰֻ��������ˮ�� ˫�����ͳ������߶�
//����ֵΪ��
//  HU_QIDUI              �߶�    �� 7������  0��4����ͬ
//  HU_HAO_QIDUI          �����߶� �� 7������  1��4����ͬ
//  HU_DOUBLE_HAO_QIDUI   ˫�����߶ԣ� 7������  2��4����ͬ
//  HU_TRIPLE_HAO_QIDUI   �������߶ԣ� 7������  3��4����ͬ
Lint HandlerObject::matchHu_SpecialQiDui(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch /*= NULL*/) const
{
	Lint bRet = 0;

	//ȷ����14����
	if (cards.size() + laiZiCount == 14)
	{
		std::map<Lint, Lint> matchNumMap;

		std::vector<Card> tingCard;	//����
		for (CardVector::size_type index = 0; index < cards.size();)
		{
			matchNumMap[cards[index]->GetNCIndex()] += 2;

			if (index + 1 < cards.size() && *cards[index] == *cards[index + 1])
			{
				index += 2;
			}
			else
			{
				tingCard.push_back(*cards[index]);

				index++;
			}
		}

		Lint nLessLaiZi = laiZiCount - (Lint)tingCard.size();
		if(nLessLaiZi >= 0)
		{
			Lint nAnGangNum = 0;

			//�ܺ�7��ʱ���һ���Ƿ�Ϊ����7�Ի򳬺���7��

			//ʣ��������>=2��ʱһ���Ǻ���7��?
			if( nLessLaiZi >= 2 )
				nAnGangNum++;

			std::map<Lint, Lint>::iterator IT = matchNumMap.begin();
			while( IT != matchNumMap.end() )
			{
				if( IT->second == 4 )
					nAnGangNum++;

				++IT;
			}

			switch( nAnGangNum )
			{
			case 0:
				bRet = HU_QIDUI;
				break;
			case 1:
				bRet = HU_HAO_QIDUI;
				break;
			case 2:
				bRet = HU_DOUBLE_HAO_QIDUI;
				break;
			case 3:
				bRet = HU_TRIPLE_HAO_QIDUI;
				break;
			}
		}

		//�������ƥ�����
		if (bRet && NULL != pMatch && !tingCard.empty())
		{
			pMatch->assign(tingCard.begin(), tingCard.end());

			//ֻҪ��7��һ������������ ��ΪҪ�����һɫ��������һ���������
		}
	}

	return bRet;
}

//ʹ�����ƥ�������С��
bool HandlerObject::matchHu_HaoQi(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	bool bRet = false;

	//ȷ����14����
	if (cards.size() + laiZiCount == 14)
	{
		Lint daDuiZiCount = 0;	//��������

		//�����
		std::vector<CardVector::size_type> singleCard;	//����
		for (CardVector::size_type index = 0; index < cards.size();)
		{
			if (index + 3 < cards.size() && *cards[index] == *cards[index + 3])
			{
				daDuiZiCount++;
				index += 4;
			}
			else if(index + 2 < cards.size() && *cards[index] == *cards[index + 2])
			{
				daDuiZiCount++;
				index += 3;
			}
			else if (index + 1 < cards.size() && *cards[index] == *cards[index + 1])
			{
				index += 2;
			}
			else
			{
				singleCard.push_back(index);
				index++;
			}
		}

		//����Ƿ����ɺ�����С��
		if ((Lint)singleCard.size() <= laiZiCount)
		{
			bRet = 0 < daDuiZiCount || (Lint)singleCard.size() + 2 <= laiZiCount;
		}

		//�������ƥ�����
		if (bRet && NULL != pMatch && !singleCard.empty())
		{
			std::vector<CardVector::size_type>::iterator iter = singleCard.begin();
			for (iter = singleCard.begin(); iter != singleCard.end(); ++iter)
			{
				pMatch->push_back(*cards[*iter]);
			}
		}
	}

	return bRet;
}

//ʹ�����ƥ�������С��
bool HandlerObject::matchHu_ChaoHaoQi(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	bool bRet = false;

	//ȷ����14����
	if (cards.size() + laiZiCount == 14)
	{
		Lint daDuiZiCount = 0;	//��������

		//�����
		std::vector<CardVector::size_type> singleCard;	//����
		for (CardVector::size_type index = 0; index < cards.size();)
		{
			if (index + 3 < cards.size() && *cards[index] == *cards[index + 3])
			{
				daDuiZiCount++;
				index += 4;
			}
			else if (index + 1 < cards.size() && *cards[index] == *cards[index + 1])
			{
				index += 2;
			}
			else
			{
				singleCard.push_back(index);
				index++;
			}
		}

		//����Ƿ����ɺ�����С��
		if ((Lint)singleCard.size() <= laiZiCount)
		{
			bRet = 2 <= (daDuiZiCount + (laiZiCount - (Lint)singleCard.size()) / 2);
		}

		//�������ƥ�����
		if (bRet && NULL != pMatch && !singleCard.empty())
		{
			std::vector<CardVector::size_type>::iterator iter = singleCard.begin();
			for (iter = singleCard.begin(); iter != singleCard.end(); ++iter)
			{
				pMatch->push_back(*cards[*iter]);
			}
		}
	}

	return bRet;
}

//ʹ�����ƥ������
bool HandlerObject::matchHu_DaDuiZi(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	CardVector::size_type cardCount = cards.size();
	CardVector::size_type indexCard = 0;
	Lint nDuiNum = 0;

	std::vector<Card> tingCards;

	//ѭ��������
	while (indexCard < cardCount)
	{
		//������ɴ����
		if (indexCard + 2 < cardCount && *cards[indexCard] == *cards[indexCard + 2])
		{
			indexCard += 3;
		}
		//����һ����ͨ����
		else if (indexCard + 1 < cardCount && *cards[indexCard] == *cards[indexCard + 1])
		{
			if (1 < laiZiCount)
			{
				indexCard += 2;
				laiZiCount -= 1;
				tingCards.push_back(*cards[indexCard]);
			}
			else if( 0 == nDuiNum )
			{
				//�п����ǽ���
				nDuiNum += 1;
				indexCard += 2;
			}
			else
			{
				break;
			}
		}
		//����
		else
		{
			if (2 < laiZiCount)
			{
				indexCard += 1;
				laiZiCount -= 2;
				tingCards.push_back(*cards[indexCard]);
			}
			else
			{
				break;
			}
		}
	}//ѭ��������

	bool bRet = false;

	if (cardCount <= indexCard)
	{
	   bRet = true;

	   if (NULL != pMatch)
	   {
		   pMatch->insert(pMatch->end(), tingCards.begin(), tingCards.end());
	   }
	}

	return bRet;
}

//���ȫ��������
bool HandlerObject::CheckTingQuanBuKao(const CardVector& handCards, std::vector<Card>* pTing /*= NULL*/)
{
	Lint currentRemainder	= 0;	//��ǰ��3ȡ������
	Lint fengCardCount		= 0;	//��������

	std::set<Lint>		existRemainder;	//�Ѿ����ڵĶ�3ȡ�������
	std::vector<bool>	colorNumberUsed(9, true);	//��Ͱ��9���Ƿ��ʹ�õı�־�б�
	std::vector<bool>	fengNumberUsed(7, true);	//����7���Ƿ��ʹ�õ��б�
	std::vector<Card>	colorTingCards;

	bool dealContinue = handCards.size() == 13;	//������13������

	//ѭ�����п�����
	CardVector::size_type cardCount = handCards.size();
	for (CardVector::size_type indexCard = 0; indexCard < cardCount && dealContinue; ++indexCard)
	{
		if (indexCard + 1 < cardCount && *handCards[indexCard] == *handCards[indexCard + 1])
		{
			dealContinue = false;
		}

		//����
		if (handCards[indexCard]->m_color == CARD_COLOR_FENG_JIAN)
		{
			fengNumberUsed[handCards[indexCard]->m_number - 1] = false;
			++fengCardCount;
		}
		else
		{
			//�ı仨ɫ��ĵ�һ���ƴ���
			if (0 == indexCard || handCards[indexCard - 1]->m_color != handCards[indexCard]->m_color)
			{
				currentRemainder = handCards[indexCard]->m_number % 3;
				if (existRemainder.find(currentRemainder) == existRemainder.end())
				{
					existRemainder.insert(currentRemainder);
					for (Lsize indexNumber = 0; indexNumber < colorNumberUsed.size(); ++indexNumber)
					{
						colorNumberUsed[indexNumber] = true;
					}
				}
				else
				{
					dealContinue = false;
				}
			}

			//��3ȡ�ౣ�ֲ���
			if ((handCards[indexCard]->m_number % 3) == currentRemainder)
			{
				colorNumberUsed[handCards[indexCard]->m_number - 1] = false;

				//����ɫ���ı�򵽴����һ�ţ��򽫱���ɫ��3ȡ����ͬ��δʹ�õ��Ʒ�������б�
				if (indexCard + 1 == cardCount || handCards[indexCard]->m_color != handCards[indexCard + 1]->m_color)
				{
					for (Lsize indexNumber = 0; indexNumber < colorNumberUsed.size(); ++indexNumber)
					{
						if (colorNumberUsed[indexNumber] && (indexNumber + 1) % 3 == currentRemainder)
						{
							colorTingCards.push_back(Card(handCards[indexCard]->m_color, indexNumber + 1));
						}
					}
				}
			}
			else
			{
				dealContinue = false;
			}
		}
	}//ѭ�����п�����

	bool bRet = false;

	if (dealContinue)
	{
		if (fengCardCount == 7 || fengCardCount == 5)
		{
			bRet = true;
			if (NULL != pTing)
			{
				pTing->assign(colorTingCards.begin(), colorTingCards.end());
			}
		}
		else if (fengCardCount == 6 || fengCardCount == 4)
		{
			bRet = true;
			if (NULL != pTing)
			{
				std::vector<bool>::size_type index = 0;
				for (index = 0; index < fengNumberUsed.size(); ++index)
				{
					if (fengNumberUsed[index])
					{
						pTing->push_back(Card(CARD_COLOR_FENG_JIAN, index + 1));
					}
				}
			}
		}
	}

	return bRet;
}

//������ܺ�
bool HandlerObject::checkQiangGangHu(Lint userPos)
{
	return (m_beforeType == THINK_OPERATOR_MBU && userPos != m_curPos);
}

//�����Ͽ���
bool HandlerObject::checkGangShangKaiHua(Lint userPos)
{
	return ((m_beforeType == THINK_OPERATOR_MBU || m_beforeType == THINK_OPERATOR_ABU) && userPos == m_curPos); 
}

//���һ����
bool HandlerObject::checkYiTiaoLong(const CardVector& cards, Lint nLaiZiCount)
{
	bool bCheckLongRet = false;
	//ȷ��������Ҫ >= 9 + 2 ��Ϊ���Բ�����
	if (cards.size() + nLaiZiCount >= 9 + 2 )
	{
		Lint nColor = 0;
		Lint nNumber = 0;
		Lint nLongCardNum = 0;
		Lint nTmpLaiZiCount = nLaiZiCount;
		CardVector tmpVecCards;
		CardVector tmpVecLongCards;

		//�����
		for (CardVector::size_type index = 0; index < cards.size(); ++index)
		{
			//��������ʣ���Ƴ���5��һ��������һ������
			if( tmpVecCards.size() > 5 )
				return false;

			if( true == bCheckLongRet || CARD_COLOR_FENG_JIAN == cards[index]->m_color )
			{
				//�Ѿ��ҵ����� ʣ�µ�����������vector���
				//������ֱ�ӷŴ����vector
				tmpVecCards.push_back( cards[index] );
			}
			else if( 0 == nColor && 0 == nNumber )
			{
				//����number��1��ʼ
				if( 1 == cards[index]->m_number )
				{
					nColor = cards[index]->m_color;
					nNumber = 1;
					tmpVecLongCards.push_back(cards[index]);
					nLongCardNum += 1;
				}
				else if( nTmpLaiZiCount )
				{
					nTmpLaiZiCount -= 1;

					nColor = cards[index]->m_color;
					nNumber = 1;
					index -= 1;
					nLongCardNum += 1;
				}
				else
				{
					tmpVecCards.push_back( cards[index] );
				}
			}
			else if( nColor == cards[index]->m_color )
			{
				if( nNumber == cards[index]->m_number - 1 )
				{
					//��һ��number
					nNumber += 1;
					tmpVecLongCards.push_back(cards[index]);
					nLongCardNum += 1;
				}
				else if( nNumber != cards[index]->m_number && nTmpLaiZiCount )
				{
					nTmpLaiZiCount -= 1;
					nNumber += 1;
					index -= 1;
					nLongCardNum += 1;
				}
				else
				{
					//�������
					tmpVecCards.push_back( cards[index] );
				}

				if( 9 == nLongCardNum )
				{
					//�Ѿ��������
					nColor = 0;
					nNumber = 0;
					nLongCardNum = 0;
					bCheckLongRet = true;

					tmpVecLongCards.clear();
				}
			}
			else
			{
				//��֮ǰ���ܵ���������д�����������
				tmpVecCards.insert(tmpVecCards.end(), tmpVecLongCards.begin(), tmpVecLongCards.end());
				tmpVecLongCards.clear();
				nLongCardNum = 0;

				//��ɫ�ı����
				nColor = 0;
				nNumber = 0;
				index -= 1;
				nTmpLaiZiCount = nLaiZiCount;
			}
		}

		if(true == bCheckLongRet && (tmpVecCards.size() + nTmpLaiZiCount) > 0)
		{
			//����������ټ��ʣ����
			 bCheckLongRet = matchHu_ShunKe( tmpVecCards, nTmpLaiZiCount, NULL );
		}
	}

	return bCheckLongRet;
}

bool HandlerObject::matchHu_ShiSanYao(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch /* = NULL */) const
{
	static std::map<Card, Lint> mapCard2Index;
	static std::map<Lint, Card> mapIndex2Card;
	if (mapCard2Index.empty())
	{
		mapCard2Index[Card(CARD_COLOR_WAN, 1)] = 0;
		mapCard2Index[Card(CARD_COLOR_WAN, 9)] = 1;
		mapCard2Index[Card(CARD_COLOR_TUO, 1)] = 2;
		mapCard2Index[Card(CARD_COLOR_TUO, 9)] = 3;
		mapCard2Index[Card(CARD_COLOR_SUO, 1)] = 4;
		mapCard2Index[Card(CARD_COLOR_SUO, 9)] = 5;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 1)] = 6;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 2)] = 7;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 3)] = 8;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 4)] = 9;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 5)] = 10;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 6)] = 11;
		mapCard2Index[Card(CARD_COLOR_FENG_JIAN, 7)] = 12;
	}
	if (mapIndex2Card.empty())
	{
		mapIndex2Card[0] = Card(CARD_COLOR_WAN, 1);
		mapIndex2Card[1] = Card(CARD_COLOR_WAN, 9);
		mapIndex2Card[2] = Card(CARD_COLOR_TUO, 1);
		mapIndex2Card[3] = Card(CARD_COLOR_TUO, 9);
		mapIndex2Card[4] = Card(CARD_COLOR_SUO, 1);
		mapIndex2Card[5] = Card(CARD_COLOR_SUO, 9);
		mapIndex2Card[6] = Card(CARD_COLOR_FENG_JIAN, 1);
		mapIndex2Card[7] = Card(CARD_COLOR_FENG_JIAN, 2);
		mapIndex2Card[8] = Card(CARD_COLOR_FENG_JIAN, 3);
		mapIndex2Card[9] = Card(CARD_COLOR_FENG_JIAN, 4);
		mapIndex2Card[10] = Card(CARD_COLOR_FENG_JIAN, 5);
		mapIndex2Card[11] = Card(CARD_COLOR_FENG_JIAN, 6);
		mapIndex2Card[12] = Card(CARD_COLOR_FENG_JIAN, 7);
	}

	Lint cardVal = 0;
	for (Lsize i = 0; i < cards.size(); ++i)
	{
		Card card = *cards[i];
		std::map<Card, Lint>::iterator iter = mapCard2Index.find(card);
		if (iter != mapCard2Index.end())
		{
			Lint nIndex = iter->second;
			if ((cardVal & (1 << nIndex)) == 0)
			{
				cardVal |= (1 << nIndex);
			}
			else
			{
				cardVal |= 1 << 13;
			}
		}
	}

	bool ret = true;
	for (Lsize nIndex = 0; nIndex < 14; ++nIndex)
	{
		if ((cardVal & (1 << nIndex)) == 0)
		{
			if (laiZiCount == 0)
			{
				ret = false;
				break;
			}

			laiZiCount--;
			if (pMatch)
			{
				if (nIndex < 13)
				{
					pMatch->push_back(mapIndex2Card[nIndex]);
				}
				else
				{
					pMatch->push_back(Card(CARD_COLOR_WAN, 1));//������һ���ƶ�����
				}
			}
		}
	}

	return ret;
}


//��⻮��
//�����ʾ��֮�������ٳ��� m_before2Type ���Ǹ���  ����
bool HandlerObject::checkHuaGang(Lint userPos)
{
	//LLOG_DEBUG("userPos: %d, m_beforePos: %d, m_before2Pos: %d, m_beforeType: %d, m_before2Type:%d ", userPos, m_beforePos, m_before2Pos, m_beforeType, m_before2Type);
	if (m_beforePos == m_before2Pos && 
		m_beforePos != userPos &&
		m_beforeType == THINK_OPERATOR_OUT &&
		(m_before2Type == THINK_OPERATOR_ABU || m_before2Type == THINK_OPERATOR_MBU) )
	{
		return true;
	}
	else
	{
		return false;
	}
}


//����һ���ƺ�����
bool HandlerObject::checkCardTing(const CardVector& handCards, std::vector<Card>* pOutCards)
{
    if (pOutCards == NULL)
    {
        return false;
    }

    auto cards(handCards);
    int size = cards.size();
    for (int i = 0; i < size; ++i)
    {
        auto card = cards[i];
        if (card != cards.back())
        {
            std::swap(card, cards[size - 1]);
        }
        cards.pop_back();
        
        //˼·�����������У������ó�һ���ƣ������������ƣ�Ȼ����������ȥ�����Ƿ���ơ�
        //���ܺ�������������ڡ�
        if (matchHu_ShunKe(cards, 1))
        {
            Card outCard(card->m_color, card->m_number);
            if (std::find(pOutCards->begin(), pOutCards->end(), outCard) == pOutCards->end())
            {
                pOutCards->push_back(outCard);
            }
        }

        cards.push_back(card);
        if (card == cards.back())
        {
            std::swap(cards[i], cards[size - 1]);
        }
    }

    return !pOutCards->empty();
}


//ƥ��ʮ���ۣ���������ӣ�����
bool HandlerObject::matchHu_13Yao(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	//��¼���ظ���13����
	std::set<Card*> setCards;

	//ȷ����14����
	if (cards.size() + laiZiCount == 14)
	{
		for (CardVector::size_type indexHand = 0; indexHand < cards.size(); ++indexHand)
		{
			if (cards[indexHand]->m_color == CARD_COLOR_FENG_JIAN ||
				cards[indexHand]->m_number == 1 || cards[indexHand]->m_number == 9)
			{
				setCards.insert(cards[indexHand]);
			}
			else
			{
				return false;
			}
		}

		if (setCards.size() + laiZiCount >= 13)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	return false;
}
 
void HandlerObject::Tick(Desk& __, time_t curTimeInSeconds)
{
    if (!m_desk || !m_desk->m_vip)
    {
        LLOG_ERROR("m_desk is NULL || m_desk->m_vip is NULL");
        return;
    }
    if (m_desk->m_vip->m_curMatchId == 0)
    {
        return;
    }
    if (m_desk->getDeskState() == DESK_FREE)
    {
        return;
    }
    m_desk->m_DeskRemainPlayTime--;
    if ((curTimeInSeconds - m_desk->m_DeskStartPlayTime) > m_desk->m_vip->m_nForceFinishTime * 1000)
    {
        m_desk->m_DeskStartPlayTime = gWork.GetCurTime().MSecs();
        OnGameOver(WIN_NONE, m_playerHuInfo, INVAILD_POS, NULL);
        return;
    }
    if (m_desk->getDeskState() != DESK_PLAY)
    {
        if (curTimeInSeconds - m_desk->m_LastWaitThinkRetTime > WAITTIME_TO_PLAY && m_desk->m_vip->m_curCircle < m_desk->m_vip->m_maxCircle)
        {
            m_desk->SetAllReady();
            m_desk->CheckGameStart();
        }
        return;
    }
    if (curTimeInSeconds - m_desk->m_LastWaitThinkRetTime > m_desk->m_vip->m_InTuoGuanCanChuPaiTime)
    {
        for (int i = 0; i < DESK_USER_COUNT; i++)
        {
            Lint pos = (m_curPos + i) % DESK_USER_COUNT;
            User* puser = m_desk->GetPosUser(pos);
            if (puser == NULL) continue;
            if (puser->GetTuoGuan())
            {
                if (ProcessTuoGuan(pos, puser))
                {
                    return;
                }
            }
        }
    }
    if (curTimeInSeconds - m_desk->m_LastWaitThinkRetTime > m_desk->m_vip->m_IntoTuoGuanRemainTime)
    {
        for (int i = 0; i < DESK_USER_COUNT; i++)
        {
            Lint pos = (m_curPos + i) % DESK_USER_COUNT;
            User* puser = m_desk->GetPosUser(pos);
            if (puser == NULL) continue; 
            if (ProcessTuoGuan(pos, puser))
                return;
        }
    }
}

bool HandlerObject::ProcessTuoGuan(Lint pos, User * pUser, bool bAI)
{
    if (pos < 0 || pos > 3)
        return false;
	switch (m_desk->getDeskPlayState())
	{
	case DESK_PLAY_GET_CARD:
	{
		if (m_curPos != pos)
		{
			return false;
		}
		if (!pUser->GetTuoGuan())
		{
			pUser->SetTuoGuan(true);
			LMsgS2C_TuoGuanInfo msg;
			msg.m_nPos = pos;
			msg.m_nType = pUser->GetTuoGuan();
			m_desk->BoadCast(msg);
			++m_nTrusteeshipCount[pos];
		}
		if (bAI)
		{
			if (m_thinkInfo[pos].HasHu())
			{
				for (int i = 0; i < m_thinkInfo[m_curPos].m_thinkData.size(); i++)
				{
					if (m_thinkInfo[m_curPos].m_thinkData[i].m_type == THINK_OPERATOR_BOMB)
					{
						LMsgC2SUserPlay msg;
						msg.m_thinkInfo.m_type = THINK_OPERATOR_BOMB;
						std::vector<Card*>& mCard = m_thinkInfo[pos].m_thinkData[i].m_card;
						for (int j = 0; j < mCard.size(); j++)
						{
							CardValue card;
							card.m_color = mCard[j]->m_color;
							card.m_number = mCard[j]->m_number;
							msg.m_thinkInfo.m_card.push_back(card);
						}
						m_desk->HanderUserPlayCard(pUser, &msg);
						return true;
					}
				}
				return false;
			}
			else if (m_thinkInfo[pos].NeedThink())
			{
				LMsgC2SUserPlay msg;
				msg.m_thinkInfo.m_type = m_thinkInfo[pos].m_thinkData[0].m_type;
				std::vector<Card*>& mCard = m_thinkInfo[pos].m_thinkData[0].m_card;
				for (int j = 0; j < mCard.size(); j++)
				{
					CardValue card;
					card.m_color = mCard[j]->m_color;
					card.m_number = mCard[j]->m_number;
					msg.m_thinkInfo.m_card.push_back(card);
				}
				m_desk->HanderUserPlayCard(pUser, &msg);
				return true;
			}
			LMsgC2SUserPlay msg;
			msg.m_thinkInfo.m_type = THINK_OPERATOR_OUT;
			if (!m_handCard[m_curPos].empty())
			{
				Card* pCard = m_handCard[m_curPos].back();
				if (pCard)
				{
					CardValue card;
					card.m_color = pCard->m_color;
					card.m_number = pCard->m_number;
					msg.m_thinkInfo.m_card.push_back(card);
				}
			}
			m_desk->HanderUserPlayCard(pUser, &msg);
			return true;
		}
		else
		{
			if (m_thinkInfo[pos].HasHu())
			{
				for (int i = 0; i < m_thinkInfo[m_curPos].m_thinkData.size(); i++)
				{
					if (m_thinkInfo[m_curPos].m_thinkData[i].m_type == THINK_OPERATOR_BOMB)
					{
						LMsgC2SUserPlay msg;
						msg.m_thinkInfo.m_type = THINK_OPERATOR_BOMB;
						std::vector<Card*>& mCard = m_thinkInfo[pos].m_thinkData[i].m_card;
						for (int j = 0; j < mCard.size(); j++)
						{
							CardValue card;
							card.m_color = mCard[j]->m_color;
							card.m_number = mCard[j]->m_number;
							msg.m_thinkInfo.m_card.push_back(card);
						}
						m_desk->HanderUserPlayCard(pUser, &msg);
						return true;
					}
				}
				return false;
			}
			LMsgC2SUserPlay msg;
			msg.m_thinkInfo.m_type = THINK_OPERATOR_OUT;
			CardValue card;
			if (GetTuoGuanOutCard(pos, card))
			{
				msg.m_thinkInfo.m_card.push_back(card);
			}
			m_desk->HanderUserPlayCard(pUser, &msg);
		}
		return true;
	}
	break;
	case DESK_PLAY_THINK_CARD:
	{
		if (!m_thinkInfo[pos].NeedThink()) return false;
		if (!pUser->GetTuoGuan())
		{
			pUser->SetTuoGuan(true);
			LMsgS2C_TuoGuanInfo msg;
			msg.m_nPos = pos;
			msg.m_nType = pUser->GetTuoGuan();
			m_desk->BoadCast(msg);
			++m_nTrusteeshipCount[pos];
		}
		if (bAI)
		{
			if (m_thinkInfo[pos].HasHu())
			{
				for (int i = 0; i < m_thinkInfo[pos].m_thinkData.size(); i++)
				{
					if (m_thinkInfo[pos].m_thinkData[i].m_type == THINK_OPERATOR_BOMB)
					{
						LMsgC2SUserOper msg;
						msg.m_think.m_type = THINK_OPERATOR_BOMB;
						std::vector<Card*>& mCard = m_thinkInfo[pos].m_thinkData[i].m_card;
						for (int j = 0; j < mCard.size(); j++)
						{
							CardValue card;
							card.m_color = mCard[j]->m_color;
							card.m_number = mCard[j]->m_number;
							msg.m_think.m_card.push_back(card);
						}
						m_desk->HanderUserOperCard(pUser, &msg);
						return true;
					}
				}
				return false;
			}
			else if (m_thinkInfo[pos].NeedThink())
			{
				LMsgC2SUserOper msg;
				msg.m_think.m_type = m_thinkInfo[pos].m_thinkData[0].m_type;
				std::vector<Card*>& mCard = m_thinkInfo[pos].m_thinkData[0].m_card;
				for (int j = 0; j < mCard.size(); j++)
				{
					CardValue card;
					card.m_color = mCard[j]->m_color;
					card.m_number = mCard[j]->m_number;
					msg.m_think.m_card.push_back(card);
				}
				m_desk->HanderUserOperCard(pUser, &msg);
				return true;
			}
		}
		else if (m_thinkInfo[pos].NeedThink())
		{
			LMsgC2SUserOper msg;
			msg.m_think.m_type = THINK_OPERATOR_NULL;
			m_desk->HanderUserOperCard(pUser, &msg);
			return true;
		}
	}
	break;
	default:
	{
		LLOG_DEBUG("robote NULL ERROR ");
	}
	}
    return false;
}

void HandlerObject::UpdateLastWaitThinkRetTime()
{
    m_desk->m_LastWaitThinkRetTime = gWork.GetCurTime().MSecs();
}

bool HandlerObject::GetTuoGuanOutCard(Lint pos, CardValue& out)
{
	Card* pOutCard = NULL;

	if (m_curGetCard && m_needGetCard)
	{
		pOutCard = m_curGetCard;
	}
	else
	{
		if (! m_handCard[pos].empty())
		{
			pOutCard = m_handCard[pos].back();
		}
	}

	if (pOutCard)
	{
		out.m_color = pOutCard->m_color;
		out.m_number = pOutCard->m_number;
	}

	return pOutCard != NULL;
}
