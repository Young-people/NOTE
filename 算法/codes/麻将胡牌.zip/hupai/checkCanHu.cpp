
struct Card
{
	Lint m_number;	//牌的号码1-9
	Lint m_color;   //牌的花色1-3 1-万，2-筒，3-条

	//-----------------------------------------------
	const static  Lint m_aYaoIndex[3];       //幺牌   一万   一筒    一条
	const static  Lint m_a13YaoNC[13];       //十三幺的13张牌的NC值   

	Card()
	{
		m_number = 0;
		m_color = 0;
	}

	Card(Lint clr, Lint num)
	{
		m_number = num;
		m_color = clr;
	}

	void setCard(Lint clr, Lint num)
	{
		m_number = num;
		m_color = clr;
	}

	Lint GetNCIndex() const
	{
		return (m_color * 10 + m_number);
	}

	bool operator< (const Card& other) const
	{
		return this->GetNCIndex() < other.GetNCIndex();
	}

	bool operator> (const Card& other) const
	{
		return this->GetNCIndex() > other.GetNCIndex();
	}

	bool operator== (const Card& other) const
	{
		return m_color == other.m_color && m_number == other.m_number;
	}
	bool operator!= (const Card& other) const
	{
		return m_color != other.m_color || m_number != other.m_number;
	}


	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Lint GetNCIndex(Lint Index)
	{
		Lint NCIndex = 0;

		switch(Index)
		{
		case IndexDong:  //东
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 1;
				break;
			}
		case IndexNan:  //南
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 2;
				break;
			}
		case IndexXi:  //西
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 3;
				break;
			}
		case IndexBei:  //北
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 4;
				break;
			}
		case IndexZhong:  //中
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 5;
				break;
			}
		case IndexFa:  //发
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 6;
				break;
			}
		case IndexBai:  //白
			{
				NCIndex = CARD_COLOR_FENG_JIAN*10 + 7;
				break;
			}
		default:
			{
				if ( Index<=8 && Index>=0 )
				{
					NCIndex = CARD_COLOR_WAN*10 + Index+1;
				}
				else if ( Index<=19 && Index>=11 )
				{
					NCIndex = CARD_COLOR_TUO*10 + Index-10;
				}
				else if ( Index<=30 && Index>=22 )
				{
					NCIndex = CARD_COLOR_SUO*10 + Index-21;
				}
				break;
			}
		}

		return NCIndex;
	}


	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Lint GetColor(Lint Index)
	{
		Lint nColor = 0;

		switch(Index)
		{
		case IndexDong:  //东
		case IndexNan:  //南
		case IndexXi:  //西
		case IndexBei:  //北
		case IndexZhong:  //中
		case IndexFa:  //发
		case IndexBai:  //白
			{
				nColor = CARD_COLOR_FENG_JIAN;
				break;
			}
		default:
			{
				if ( Index<=8 && Index>=0 )
				{
					nColor = CARD_COLOR_WAN;
				}
				else if ( Index<=19 && Index>=11 )
				{
					nColor = CARD_COLOR_TUO;
				}
				else if ( Index<=30 && Index>=22 )
				{
					nColor = CARD_COLOR_SUO;
				}
				break;
			}
		}

		return nColor;
	}


	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Lint GetNumber(Lint Index)
	{
		Lint nNumber = 0;

		switch (Index)
		{
		case IndexDong:  //东
		case IndexNan:  //南
		case IndexXi:  //西
		case IndexBei:  //北
		case IndexZhong:  //中
		case IndexFa:  //发
		case IndexBai:  //白
		{
			nNumber = (Index - 30) / 3;
			break;
		}
		default:
		{
			if (Index <= 8 && Index >= 0)
			{
				nNumber = Index + 1;
			}
			else if (Index <= 19 && Index >= 11)
			{
				nNumber = Index - 10;
			}
			else if (Index <= 30 && Index >= 22)
			{
				nNumber = Index - 21;
			}
			break;
		}
		}

		return nNumber;
	}


	//通过索引号获得card
	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static Card GetCardByIndex(Lint index) 
	{
		Card  card;

		if (index <= Index9Tiao)       //“万00筒00条”
		{
			if (index <= Index9Wan && index >= Index1Wan)
			{
				card.m_color = CARD_COLOR_WAN;
				card.m_number = index + 1;
			}
			else if (index <= Index9Tong && index >= Index1Tong)
			{
				card.m_color = CARD_COLOR_TUO;
				card.m_number = index - 10;
			}
			else if (index <= Index9Tiao && index >= Index1Tiao)
			{
				card.m_color = CARD_COLOR_SUO;
				card.m_number = index - 21;
			}
		}
		else
		{
			card.m_color = CARD_COLOR_FENG_JIAN;

			switch (index)
			{
			case IndexDong:  //东
			{
				card.m_number = 1;
				break;
			}
			case IndexNan:  //南
			{
				card.m_number = 2;
				break;
			}
			case IndexXi:  //西
			{
				card.m_number = 3;
				break;
			}
			case IndexBei:  //北
			{
				card.m_number = 4;
				break;
			}
			case IndexZhong:  //中
			{
				card.m_number = 5;
				break;
			}
			case IndexFa:  //发
			{
				card.m_number = 6;
				break;
			}
			case IndexBai:  //白
			{
				card.m_number = 7;
				break;
			}
			}
		}

		return card;
	}

	//通过索引号判断是否是258牌
	//参数 
	//	Index “万00筒00条00东00南00西00北00中00发00白”数组的下标
	static bool is258ByIndex(Lint index)
	{
		switch (index)
		{
		case Index2Wan:
		case Index2Tong:
		case Index2Tiao:
		case Index5Wan:
		case Index5Tong:
		case Index5Tiao:
		case Index8Wan:
		case Index8Tong:
		case Index8Tiao:
			return true;
		default:
			return false;
		}
	}

};
typedef std::vector<Card*> CardVector;


//检测胡牌
bool HandlerHuaShui::checkCanHu(Lint userPos, Card* singleCard, std::vector<Lint>& huType)
{
	if (userPos < 0 || 3 < userPos || NULL == singleCard)
	{
		return false;
	}

	//测试
	//LLOG_DEBUG("m_beforePos %d m_beforeType %d m_before2Pos %d m_before2Type %d", m_beforePos, m_beforeType, m_before2Pos, m_before2Type);

	bool isHuPai = false;
	
	//癞子红中数量
	Lint laiZiCount = 0;

	CardVector handCards(m_handCard[userPos]);
	handCards.push_back(singleCard);

	//使用红中癞子
	if (m_useZhongLaiZi)
	{
		Card* zhongCard = gCardMgr.GetCard(CARD_COLOR_FENG_JIAN, 5);	//红中牌

		//查找所有的红中
		CardVector::iterator iterEnd = std::remove_if(handCards.begin(), handCards.end(), 
			[&](Card* card){return *card == *zhongCard;});

		if (iterEnd != handCards.end())
		{
			laiZiCount = handCards.end() - iterEnd;
			handCards.resize(iterEnd - handCards.begin());
		}

		//别人打的红中牌不算癞子
		if (*singleCard == *zhongCard && m_curPos != userPos)
		{
			laiZiCount -= 1;
			handCards.push_back(zhongCard);
		}
	}//使用红中癞子

	//牌数据排序
	gCardMgr.SortCard(handCards);

	//检测胡牌，七小对
	if (/*!isHuPai &&*/ matchHu_QiDui(handCards, laiZiCount))
	{
		isHuPai = true;
		if (matchHu_HaoQi(handCards, laiZiCount))	//检测豪华七小对
		{
			huType.push_back(HU_HAO_QIDUI);
		}
		else
		{
			huType.push_back(HU_QIDUI);
		}
	}

	//检测胡牌，顺子、刻子
	if (!isHuPai && matchHu_ShunKe(handCards, laiZiCount))
	{
		huType.push_back(m_curPos == userPos ? HU_ZIMOHU : HU_XIAOHU);
		isHuPai = true;
	}

	//确保胡牌列表内包含自摸或平胡的基本胡法
	if (isHuPai && !huType.empty() && huType[0] != HU_ZIMOHU && huType[0] != HU_XIAOHU)
	{
		huType.insert(huType.begin(), m_curPos == userPos ? HU_ZIMOHU : HU_XIAOHU);
	}

	//检测抢杠胡
	if (isHuPai && checkQiangGangHu(userPos))
	{
		huType.push_back(HU_QIANGGANGHU);

		//test
		//for (Lint i=0; i<huType.size(); i++)
		//{
		//	LLOG_DEBUG("huType[%d] %d", i, huType[i]);
		//}
	}

	//检测杠上开花
	if (isHuPai && checkGangShangKaiHua(userPos))
	{
		huType.push_back(HU_GANG1);
	}

	//检测清一色
	if (isHuPai && m_useSameColor && checkSameColor(userPos, singleCard, handCards))
	{
		huType.push_back(HU_QINGYISE);
	}

	//排序一下
	if (!huType.empty())
	{
		std::sort(huType.begin(), huType.end());
	}

	return isHuPai;
}

//使用癞子匹配七小对
bool matchHu_QiDui(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch = NULL) const;

//使用癞子匹配七小对
bool HandlerObject::matchHu_QiDui(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	bool bRet = false;

	//确保是14张牌
	if (cards.size() + laiZiCount == 14)
	{
		std::vector<Card> tingCard;	//单牌
		for (CardVector::size_type index = 0; index < cards.size();)
		{
			if (index + 1 < cards.size() && *cards[index] == *cards[index + 1])
			{
				index += 2;
			}
			else
			{
				tingCard.push_back(*cards[index]);
				index++;
			}
		}

		bRet = ((Lint)tingCard.size() <= laiZiCount);

		//保存癞子匹配的牌
		if (bRet && NULL != pMatch && !tingCard.empty())
		{
			pMatch->assign(tingCard.begin(), tingCard.end());
		}
	}

	return bRet;
}

//使用癞子匹配豪华七小对
bool matchHu_HaoQi(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch = NULL) const;

//使用癞子匹配豪华七小对
bool HandlerObject::matchHu_HaoQi(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	bool bRet = false;

	//确保是14张牌
	if (cards.size() + laiZiCount == 14)
	{
		Lint daDuiZiCount = 0;	//杠牌数量

		//检测牌
		std::vector<CardVector::size_type> singleCard;	//单牌
		for (CardVector::size_type index = 0; index < cards.size();)
		{
			if (index + 3 < cards.size() && *cards[index] == *cards[index + 3])
			{
				daDuiZiCount++;
				index += 4;
			}
			else if(index + 2 < cards.size() && *cards[index] == *cards[index + 2])
			{
				daDuiZiCount++;
				index += 3;
			}
			else if (index + 1 < cards.size() && *cards[index] == *cards[index + 1])
			{
				index += 2;
			}
			else
			{
				singleCard.push_back(index);
				index++;
			}
		}

		//检测是否可组成豪华七小对
		if ((Lint)singleCard.size() <= laiZiCount)
		{
			bRet = 0 < daDuiZiCount || (Lint)singleCard.size() + 2 <= laiZiCount;
		}

		//保存癞子匹配的牌
		if (bRet && NULL != pMatch && !singleCard.empty())
		{
			std::vector<CardVector::size_type>::iterator iter = singleCard.begin();
			for (iter = singleCard.begin(); iter != singleCard.end(); ++iter)
			{
				pMatch->push_back(*cards[*iter]);
			}
		}
	}

	return bRet;
}

//使用癞子匹配顺子、刻子
bool matchHu_ShunKe(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch = NULL) const;

//使用癞子匹配顺子、刻子
bool HandlerHuaShui::matchHu_ShunKe(const CardVector& cards, Lint laiZiCount, std::vector<Card>* pMatch) const
{
	if( cards.empty() && (2 == laiZiCount || 5 == laiZiCount) )
	{
		//手里牌为空直接胡吧 因为手里只剩下赖子牌做将了
		return true;
	}

	bool bRet = false;

	Luchar szCards[52] = {0};	// 万00桶00条00东00南00西00北00中00发00白

	//重新组织数据
	for (CardVector::size_type index = 0; index < cards.size(); ++index)
	{
		if (cards[index]->m_color < CARD_COLOR_FENG_JIAN)
		{
			szCards[(cards[index]->m_color - 1) * 11 + cards[index]->m_number - 1] += 1;
		}
		else
		{
			szCards[(cards[index]->m_color - 1) * 11 + (cards[index]->m_number - 1) * 3] += 1;
		}
	}

	//临时函数 使用癞子完全匹配牌形以形成顺子或刻子
	std::function<bool(Luchar*, Lint, Lint, std::set<Luchar*>*)> matchLaiZi = 
		[&](Luchar* cards, Lint count, Lint laiZiCount, std::set<Luchar*>* pTingMatch)->bool
	{
		bool result = false;

		//匹配刻子
		if (0 < count && 0 < cards[0] && 3 <= cards[0] + laiZiCount)
		{
			Luchar bkCardCount	= cards[0];
			laiZiCount -= std::max(3 - cards[0], 0);
			cards[0]	= std::max(cards[0] - 3, 0);

			if (matchLaiZi(cards, count, laiZiCount, pTingMatch))
			{
				result = true;
				if (NULL != pTingMatch && bkCardCount < 3)
				{
					pTingMatch->insert(cards);
				}
			}

			cards[0]	= bkCardCount;
			laiZiCount	+= std::max(3 - cards[0], 0);
		}

		//匹配顺子
		if (2 < count && (!result || NULL != pTingMatch))
		{
			//连续的三个位置上至少两个存在牌数据
			if (2 <= (Lint)(0 < cards[0]) + (Lint)(0 < cards[1]) + (Lint)(0 < cards[2]))
			{
				if ((0 < cards[0] && 0 < cards[1] && 0 < cards[2]) || 0 < laiZiCount)
				{
					Luchar bkFirstCount		= cards[0];
					Luchar bkSecondCount	= cards[1];
					Luchar bkThirdCount		= cards[2];
					laiZiCount -= cards[0] == 0 ? 1 : 0;
					laiZiCount -= cards[1] == 0 ? 1 : 0;
					laiZiCount -= cards[2] == 0 ? 1 : 0;
					cards[0] = std::max(cards[0] - 1, 0);
					cards[1] = std::max(cards[1] - 1, 0);
					cards[2] = std::max(cards[2] - 1, 0);

					if (matchLaiZi(cards, count, laiZiCount, pTingMatch))
					{
						result = true;
						if (NULL != pTingMatch && (bkFirstCount == 0 || bkSecondCount == 0 || bkThirdCount == 0))
						{
							pTingMatch->insert(bkFirstCount == 0 ? cards : (bkSecondCount == 0 ? (cards + 1) : (cards + 2)));
						}
					}

					cards[0] = bkFirstCount;
					cards[1] = bkSecondCount;
					cards[2] = bkThirdCount;
					laiZiCount += cards[0] == 0 ? 1 : 0;
					laiZiCount += cards[1] == 0 ? 1 : 0;
					laiZiCount += cards[2] == 0 ? 1 : 0;
				}
			}
		}//匹配顺子

		//后移位置
		if (0 < count && 0 == cards[0] && (!result || NULL != pTingMatch))
		{
			if (matchLaiZi(cards + 1, count - 1, laiZiCount, pTingMatch))
			{
				result = true;
			}
		}

		//满足需要
		if (count <= 0)
		{
			result = true;
		}

		return result;
	}; //临时函数 matchLaiZi()

	std::set<Luchar*> tingCards;
	std::set<Luchar*>* pTingMatch = NULL != pMatch ? &tingCards : NULL;
	Lint cardCount = sizeof(szCards) / sizeof(szCards[0]);

	//检测是否满足胡牌
	if ((cards.size() + laiZiCount) % 3 == 2)	//考虑将牌
	{
		for (Lint index = 0; index < cardCount && (!bRet || NULL != pTingMatch); ++index)
		{
			//单胡将牌的情况
			if (0 < szCards[index] && 0 < laiZiCount)
			{
				switch(index)
				{
				case 1:
				case 4:
				case 7:
				case 12:
				case 15:
				case 18:
				case 23:
				case 26:
				case 29:
					{
						szCards[index] -= 1;
						laiZiCount -= 1;
						if (matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch))
						{
							bRet = true;
							if (NULL != pTingMatch)
							{
								pTingMatch->insert(szCards + index);
							}
						}
						szCards[index] += 1;
						laiZiCount += 1;
						break;
					}
				default:
					{
						if (!m_use258Jiang)
						{
							szCards[index] -= 1;
							laiZiCount -= 1;
							if (matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch))
							{
								bRet = true;
								if (NULL != pTingMatch)
								{
									pTingMatch->insert(szCards + index);
								}
							}
							szCards[index] += 1;
							laiZiCount += 1;
						}
						break;
					}
				}

			}
			//已经存在将牌的情况
			if ((!bRet || NULL != pMatch) && 2 <= szCards[index])
			{
				switch(index)
				{
				case 1:
				case 4:
				case 7:
				case 12:
				case 15:
				case 18:
				case 23:
				case 26:
				case 29:
					{
						szCards[index] -= 2;
						bRet = matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch) || bRet;
						szCards[index] += 2;
						break;
					}
				default:
					{
						if (!m_use258Jiang)
						{
							szCards[index] -= 2;
							bRet = matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch) || bRet;
							szCards[index] += 2;
						}
						break;
					}
				}
			}
			if ((!bRet || NULL != pMatch) && 2 <= laiZiCount && m_use258Jiang)  //258将，红中癞子作将，可以胡
			{
				laiZiCount -= 2;
				bRet = matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch) || bRet;
				laiZiCount += 2;
			}
		}
	}
	else if ((cards.size() + laiZiCount) % 3 == 0)	//不考虑将牌
	{
		bRet = matchLaiZi(szCards, cardCount, laiZiCount, pTingMatch);
	}


	//将数组转换为常规牌数据
	if (bRet && NULL != pMatch)
	{
		Lint cardColor	= 0;
		Lint cardNumber	= 0;
		Lint jianPaiStart = (CARD_COLOR_FENG_JIAN - 1) * 11;
		std::set<Luchar*>::iterator iterTing = tingCards.begin();
		for (; iterTing != tingCards.end(); ++iterTing)
		{
			Lint cardIndex = *iterTing - szCards;
			if (jianPaiStart <= cardIndex)
			{
				pMatch->push_back(Card(CARD_COLOR_FENG_JIAN, (cardIndex - jianPaiStart) / 3 + 1));
			}
			else
			{
				cardColor = cardIndex / 11 + 1;
				cardNumber = (cardIndex - (cardColor - 1) * 11) + 1;
				if (1 <= cardNumber && cardNumber <= 9)
				{
					pMatch->push_back(Card(cardColor, cardNumber));
				}
			}
		}
	}

	return bRet;
}

//检测抢杠胡
bool checkQiangGangHu(Lint userPos);

//检测抢杠胡
bool HandlerObject::checkQiangGangHu(Lint userPos)
{
	return (m_beforeType == THINK_OPERATOR_MBU && userPos != m_curPos);
}

//检测杠上开花
bool checkGangShangKaiHua(Lint userPos);

//检测杠上开花
bool HandlerObject::checkGangShangKaiHua(Lint userPos)
{
	return ((m_beforeType == THINK_OPERATOR_MBU || m_beforeType == THINK_OPERATOR_ABU) && userPos == m_curPos); 
}

//检测清一色
bool checkSameColor(Lint userPos, Card* card, CardVector& handCard);

//检测清一色
bool HandlerHuaShui::checkSameColor(Lint userPos, Card* card, CardVector& handCard)
{
	//碰胡时，碰到的牌在 card 中
	//    碰的三张牌都在 handCard 中

	//判定清一色，不需要判定 card 
	//   因为不管 card 是什么花色，手牌中必定存在与之相同的花色
	//所以，如果手牌不为空，就从手牌中取一张牌，与每一张手牌、碰牌、吃牌、明杠牌、暗杠牌进行比较，花色相同就是清一色，存在花色不同就不是清一色
	//   如果手牌为空，就从碰牌、吃牌、明杠牌、暗杠牌中找一个非空的集合取一张牌进行比较。

	//手牌、碰牌、杠牌中的红中，就是普通红中，不是红中癞子，花色算“风箭牌”，不可以作替代牌花色

	//Card* zhongCard = gCardMgr.GetCard(CARD_COLOR_FENG_JIAN, 5);	//红中牌

	//Card* pTmpCard = NULL;   //临时牌
	//如果所有牌与临时牌花色相同，那么就是清一色
	//调用此函数时， handCard 中已剔除红中癞子牌， 但是自摸到的红中癞子依然在 card 中
	//不当癞子的红中依然还在 handCard 中
	//点炮胡的红中在 card 中   不能当癞子使用
	//如果 card 是红中，那么要不要区分是不是癞子牌
	//  不能把红中癞子当作普通红中，因为如果这样做，那么本来应该清一色的就不算清一色了。
	//  如果把普通红中当作红中癞子，手牌中一定还有普通红中牌。肯定不同清一色。
	//所以，如果 card 是红中，那么就当作红中癞子判断

	if (userPos < 0 || 3 < userPos || NULL == card)
	{
		return false;
	}

	//将所有手牌、碰牌、吃牌、暗杠牌、明杠牌都装入 vCards 中， 
	//如果 vCards 中的牌为清一色， 那么胡牌就是清一色
	//如果 vCards 不是清一色， 那么胡牌就不是清一色
	//红中癞子不在手牌中，所以不需要考虑红中癞子
	CardVector vCards;  

	//手中牌
	CardVector::size_type handCount = handCard.size();
	for (CardVector::size_type indexHand = 0; indexHand < handCount; ++indexHand)
	{
		vCards.push_back(handCard[indexHand]);
	}

	//test 打印 vCards 各张牌
	//LLOG_ERROR("HandlerHuaShui::checkSameColor   vCards:----------------- 1 ");
	//for (CardVector::size_type i = 0; i < vCards.size(); ++i)
	//{
	//	LLOG_ERROR("i:%d;  color:%d:   number:%d", i, vCards[i]->m_color, vCards[i]->m_number);
	//}

	//碰牌
	CardVector::size_type pengCount = m_pengCard[userPos].size();
	for (CardVector::size_type indexPeng = 0; indexPeng < pengCount; ++indexPeng)
	{
		vCards.push_back(m_pengCard[userPos][indexPeng]);
	}

	//test 打印 vCards 各张牌
	//LLOG_ERROR("HandlerHuaShui::checkSameColor   vCards:----------------- 2 ");
	//for (CardVector::size_type i = 0; i < vCards.size(); ++i)
	//{
	//	LLOG_ERROR("i:%d;  color:%d:   number:%d", i, vCards[i]->m_color, vCards[i]->m_number);
	//}

	//吃牌
	CardVector::size_type eatCount = m_eatCard[userPos].size();
	for (CardVector::size_type indexEat = 0; indexEat < eatCount; ++indexEat)
	{
		vCards.push_back(m_eatCard[userPos][indexEat]);
	}

	//test 打印 vCards 各张牌
	//LLOG_ERROR("HandlerHuaShui::checkSameColor   vCards:----------------- 3 ");
	//for (CardVector::size_type i = 0; i < vCards.size(); ++i)
	//{
	//	LLOG_ERROR("i:%d;  color:%d:   number:%d", i, vCards[i]->m_color, vCards[i]->m_number);
	//}

	//暗杠
	CardVector::size_type agangCount = m_agangCard[userPos].size();
	for (CardVector::size_type indexAGang = 0; indexAGang < agangCount; ++indexAGang)
	{
		vCards.push_back(m_agangCard[userPos][indexAGang]);
	}

	//test 打印 vCards 各张牌
	//LLOG_ERROR("HandlerHuaShui::checkSameColor   vCards:----------------- 4 ");
	//for (CardVector::size_type i = 0; i < vCards.size(); ++i)
	//{
	//	LLOG_ERROR("i:%d;  color:%d:   number:%d", i, vCards[i]->m_color, vCards[i]->m_number);
	//}

	//明杠
	CardVector::size_type mgangCount = m_mgangCard[userPos].size();
	for (CardVector::size_type indexMGang = 0; indexMGang < mgangCount; ++indexMGang)
	{
		vCards.push_back(m_mgangCard[userPos][indexMGang]);
	}

	//test 打印 vCards 各张牌
	//LLOG_ERROR("HandlerHuaShui::checkSameColor   vCards:----------------- 5 ");
	//for (CardVector::size_type i = 0; i < vCards.size(); ++i)
	//{
	//	LLOG_ERROR("i:%d;  color:%d:   number:%d", i, vCards[i]->m_color, vCards[i]->m_number);
	//}

	bool bRet = true;    //初始化为清一色

	CardVector::size_type cardsCount = vCards.size();
	if ( cardsCount > 0 )
	{
		//取得第一张牌，与 vCards 中的每一个元素的花色进行比较
		Card* pFirstCard = vCards[0];

		if ( pFirstCard != NULL )
		{
			for (CardVector::size_type indexCard = 0; indexCard < cardsCount; ++indexCard)
			{
				if ( vCards[indexCard]->m_color != pFirstCard->m_color )
				{
					bRet = false;
					break;
				}
			}
		}
	}

	return bRet;
}

	
